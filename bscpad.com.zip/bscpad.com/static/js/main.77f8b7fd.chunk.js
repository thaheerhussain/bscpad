(this["webpackJsonpbsc-pad-frontend"] = this["webpackJsonpbsc-pad-frontend"] || []).push([
    [0], {
        1081: function(e, t, a) {
            "use strict";
            a.r(t);
            var n, r = a(0),
                o = a.n(r),
                i = a(51),
                l = a.n(i),
                s = a(17),
                c = (a(474), a(47)),
                u = {
                    GET_PROJECTS: "/api/projects",
                    GET_PROJECT_DETAILS: "/api/projects/:id",
                    GET_STAKING_ENABLE: "/api/staking",
                    GET_CALENDAR: "/api/calendar",
                    GET_KYC: "/api/kycs"
                },
                m = "Approve Success",
                d = "Failed to Approve Tokens",
                p = "Successfully Joined Pool",
                h = "Failed to Join Pool",
                b = "Sync kyc to TRONPAD Success",
                f = "Failed  to Sync kyc to TRONPAD ",
                y = "Wrong network! You need connect to Binance Smart Chain network!",
                E = "/",
                g = "/projects",
                v = "/project/:contract",
                w = "/terms-of-use",
                T = "/privacy-policy",
                S = "/cookie-policy",
                N = "/staking-policy",
                k = "/clickwrap-acceptance",
                C = "/calendar",
                A = "/staking",
                O = {
                    BRONZE: {
                        level: "Bronze",
                        amountStakingRequire: "1000",
                        stakingLengthRequire: "3 hours before Allocation Round opens",
                        tweetRequire: "Like, Comment & Retweet",
                        guaranteedAllocation: "Yes",
                        ticket: "1",
                        uri: "https://bscpad.medium.com/bscpad-tiered-ido-model-89b630f6372e",
                        type: "lottery"
                    },
                    SILVER: {
                        level: "Silver",
                        amountStakingRequire: "2500",
                        stakingLengthRequire: "3 hours before Allocation Round opens",
                        tweetRequire: "Like, Comment & Retweet",
                        guaranteedAllocation: "Yes",
                        ticket: "3",
                        uri: "https://bscpad.medium.com/bscpad-tiered-ido-model-89b630f6372e",
                        type: "lottery"
                    },
                    GOLD: {
                        level: "Gold",
                        amountStakingRequire: "5000",
                        stakingLengthRequire: "3 hours before Allocation Round opens",
                        tweetRequire: "Like, Comment & Retweet",
                        guaranteedAllocation: "Yes",
                        ticket: "7",
                        uri: "https://bscpad.medium.com/bscpad-tiered-ido-model-89b630f6372e",
                        type: "lottery"
                    },
                    PLATINUM: {
                        level: "Platinum",
                        amountStakingRequire: "10000",
                        stakingLengthRequire: "3 hours before Allocation Round opens",
                        tweetRequire: "None",
                        guaranteedAllocation: "Yes",
                        poolWeight: "10",
                        uri: "https://bscpad.medium.com/bscpad-tiered-ido-model-89b630f6372e",
                        type: "guaranteed"
                    },
                    DIAMOND: {
                        level: "Diamond",
                        amountStakingRequire: "25000",
                        stakingLengthRequire: "3 hours before Allocation Round opens",
                        tweetRequire: "None",
                        guaranteedAllocation: "Yes",
                        poolWeight: "30",
                        uri: "https://bscpad.medium.com/bscpad-tiered-ido-model-89b630f6372e",
                        type: "guaranteed"
                    },
                    BLUE_DIAMOND: {
                        level: "Blue Diamond",
                        amountStakingRequire: "75000",
                        stakingLengthRequire: "3 hours before Allocation Round opens",
                        tweetRequire: "None",
                        guaranteedAllocation: "Yes",
                        poolWeight: "60 + Private Allocations",
                        uri: "https://bscpad.medium.com/bscpad-tiered-ido-model-89b630f6372e",
                        type: "guaranteed"
                    }
                },
                P = {
                    LESTER_LIM: {
                        name: "LESTER LIM",
                        image: "images/LESTER_LIM.jpeg",
                        position: "Founder at X21 Digital",
                        modal: "#team-popup-2",
                        telegram: null,
                        twitter: null,
                        linked: null
                    },
                    IAN_FRIEND: {
                        name: "IAN FRIEND",
                        image: "images/Ian_Friend.jpeg",
                        position: "Co-Founder and COO at Ferrum Network",
                        modal: "#team-popup-3",
                        telegram: null,
                        twitter: null,
                        linked: null
                    },
                    DANISH_CHAUDHRY: {
                        name: "DANISH CHAUDHRY",
                        image: "images/Danish_Chaudhry.jpg",
                        position: "CEO at Bitcoin.com Exchange \u2013 Entrepreneur, Startup Advisor, Mentor and Investor",
                        modal: "#team-popup-4",
                        telegram: null,
                        twitter: null,
                        linked: null
                    },
                    EXNETWORK_CAPITAL: {
                        name: "EXNETWORK CAPITAL",
                        image: "images/exntc.png",
                        position: "Exnetwork Capital is an investment firm focused on funding and incubating blockchain projects.",
                        modal: "#team-popup-5",
                        telegram: null,
                        twitter: null,
                        linked: null
                    },
                    TIM_FROST: {
                        name: "TIM FROST",
                        image: "images/TIM_FROST.jpg",
                        position: "CEO and Co-founder \r of YIELD App",
                        modal: "#team-popup-6",
                        telegram: null,
                        twitter: null,
                        linked: null
                    }
                },
                I = {
                    image: "images/SilkLegal_main_horizontal.png",
                    description: "Silk Legal is a boutique law firm specializing in FinTech and Cryptocurrency.  We combine a deep understanding of blockchain technology with an expert knowledge of international regulations to analyze issues, risks and opportunities. Silk Legal is a proud member of Global Digital Finance, the leading global association of digital asset companies advocating for and accelerating the adoption of best practices for digital assets."
                },
                x = a(40),
                D = (n = {
                    LANGUAGE_CHANGE: "LANGUAGE_CHANGE",
                    REQUEST_SUBMIT: "REQUEST_SUBMIT",
                    REQUEST_DONE: "REQUEST_DONE",
                    ALERT_SUCCESS: "ALERT_SUCCESS",
                    ALERT_FAILS: "ALERT_FAILS",
                    ALERT_WARNING: "ALERT_WARNING",
                    ALERT_CLEAR: "ALERT_CLEAR",
                    ALERT_LINK: "ALERT_LINK",
                    ALERT_LINK_CLEAR: "ALERT_LINK_CLEAR",
                    CONNECT_WALLET_SUCCESS: "CONNECT_WALLET_SUCCESS",
                    LOG_OUT_WALLET_SUCCESS: "LOG_OUT_WALLET_SUCCESS",
                    ENABLE_WALLET_SUCCESS: "ENABLE_WALLET_SUCCESS",
                    SET_SHOW_MODAL_HELP: "SET_SHOW_MODAL_HELP",
                    GET_PROJECTS_SUCCESS: "GET_PROJECTS_SUCCESS",
                    GET_LIST_CONTRACTS_INFO: "GET_LIST_CONTRACTS_INFO",
                    GET_PROJECT_SELECTED: "GET_PROJECT_SELECTED",
                    SUBMIT_GET_PROJECTS: "SUBMIT_GET_PROJECTS",
                    SUBMIT_PROJECT_SELECTED: "SUBMIT_PROJECT_SELECTED",
                    GET_PROJECT_SELECTED_SUCCESS: "GET_PROJECT_SELECTED_SUCCESS",
                    SET_CURRENT_CONTRACT_SELECTED: "SET_CURRENT_CONTRACT_SELECTED",
                    SET_LIST_CONTRACT_SELECTED: "SET_LIST_CONTRACT_SELECTED",
                    SET_JOB_PROJECT_SELECTED: "SET_JOB_PROJECT_SELECTED",
                    SET_JOB_GET_WALLET_INFO: "SET_JOB_GET_WALLET_INFO",
                    SET_JOB_COUNT_DOWN_OPEN: "SET_JOB_COUNT_DOWN_OPEN",
                    SET_JOB_COUNT_DOWN_CLOSE: "SET_JOB_COUNT_DOWN_CLOSE",
                    SET_JOB_COUNT_DOWN_ROUND: "SET_JOB_COUNT_DOWN_ROUND",
                    SET_JOB_COUNT_DOWN_FCFS_TIME: "SET_JOB_COUNT_DOWN_FCFS_TIME",
                    SET_JOB_GET_KYC: "SET_JOB_GET_KYC",
                    SET_JOB_GET_PROJECTS: "SET_JOB_GET_PROJECTS",
                    CLEAR_INTERVAL_PROJECTS_JOB: "CLEAR_INTERVAL_PROJECTS_JOB",
                    GET_INFO_WALLET: "GET_INFO_WALLET",
                    GET_KYC_INFO: "GET_KYC_INFO",
                    GET_KYC_3RD: "GET_KYC_3RD",
                    CLEAR_KYC_STATE: "CLEAR_KYC_STATE",
                    SET_JOB_GET_BALANCE: "SET_JOB_GET_BALANCE",
                    GET_STAKING_INFO: "GET_STAKING_INFO",
                    SET_JOB_GET_STAKING_INFO: "SET_GET_STAKING_INFO",
                    GET_STAKING_WALLET_INFO: "GET_STAKING_WALLET_INFO",
                    SET_JOB_GET_STAKING_WALLET_INFO: "SET_GET_STAKING_WALLET_INFO",
                    SET_JOB_COUNTDOWN_STAKE_TIME: "SET_JOB_COUNTDOWN_STAKE_TIME",
                    SUBMIT_GET_BALANCE: "SUBMIT_GET_BALANCE",
                    GET_BSCPAD_BALANCE: "GET_BSCPAD_BALANCE",
                    GET_BNB_BALANCE: "GET_BNB_BALANCE"
                }, Object(x.a)(n, "SET_JOB_GET_BALANCE", "SET_JOB_GET_BALANCE"), Object(x.a)(n, "CLEAR_STAKING_JOB", "CLEAR_STAKING_JOB"), Object(x.a)(n, "SET_STAKING_ENABLE", "SET_STAKING_ENABLE"), Object(x.a)(n, "SET_JOB_GET_STAKING_STATUS", "SET_JOB_GET_STAKING_STATUS"), Object(x.a)(n, "SET_BLOCK_LATEST", "SET_BLOCK_LATEST"), n),
                _ = a(1),
                j = a.n(_),
                B = a(24),
                R = a(119),
                L = a.n(R),
                W = a(43);

            function U() {
                return !(!L.a.ethereum || !L.a.ethereum.isMetaMask)
            }

            function F() {
                return !(!L.a.ethereum || !L.a.ethereum.isTrust)
            }

            function M(e) {
                return Object(W.BigNumber)(e).multipliedBy(Math.pow(10, 18)).integerValue()
            }
            var Y = "injected",
                G = "bsc",
                H = "WalletConnect",
                K = parseInt(("56", "56")),
                q = "https://bsc-dataseed1.defibit.io/",
                z = [{
                    title: "Metamask",
                    icon: "/images/metamask.svg",
                    connectorId: Y,
                    enable: U()
                }, {
                    title: "TrustWallet",
                    icon: "/images/trust.svg",
                    connectorId: Y,
                    enable: F()
                }, {
                    title: "Binance Chain Wallet",
                    icon: "/images/bscwallet.svg",
                    connectorId: G,
                    enable: !!L.a.BinanceChain
                }],
                J = {
                    APPROVING: "APPROVING",
                    APPROVED: "APPROVED",
                    APPROVE_FAILS: "APPROVE_FAILS",
                    CLAIM_FAIL: "CLAIM_FAIL",
                    CLAIM_SUCCESS: "CLAIM_SUCCESS",
                    BUY_SUCCESS: "BUY_SUCCESS",
                    BUY_FAIL: "BUY_FAIL",
                    STAKING_DEPOSIT_FAIL: "STAKING_DEPOSIT_FAIL",
                    STAKING_DEPOSIT_SUBMIT: "STAKING_DEPOSIT_SUBMIT",
                    STAKING_DEPOSIT_SUCCESS: "STAKING_DEPOSIT_SUCCESS",
                    STAKING_INITIATE_WITHDRAWAL_SUBMIT: "STAKING_INITIATE_WITHDRAWAL_SUBMIT",
                    STAKING_INITIATE_WITHDRAWAL_FAIL: "STAKING_INITIATE_WITHDRAWAL_FAIL",
                    STAKING_INITIATE_WITHDRAWAL_SUCCESS: "STAKING_INITIATE_WITHDRAWAL_SUCCESS",
                    STAKING_EXECUTE_WITHDRAWAL_SUBMIT: "STAKING_EXECUTE_WITHDRAWAL_SUBMIT",
                    STAKING_EXECUTE_WITHDRAWAL_FAIL: "STAKING_EXECUTE_WITHDRAWAL_FAIL",
                    STAKING_EXECUTE_WITHDRAWAL_SUCCESS: "STAKING_EXECUTE_WITHDRAWAL_SUCCESS",
                    STAKING_EXECUTE_WITHDRAW_REWARDS_SUBMIT: "STAKING_EXECUTE_WITHDRAW_REWARDS_SUBMIT",
                    STAKING_EXECUTE_WITHDRAW_REWARDS_FAIL: "STAKING_EXECUTE_WITHDRAW_REWARDS_FAIL",
                    STAKING_EXECUTE_WITHDRAW_REWARDS_SUCCESS: "STAKING_EXECUTE_WITHDRAW_REWARDS_SUCCESS",
                    STAKING_REWARDS_SUBMIT: "STAKING_REWARDS_SUBMIT",
                    STAKING_REWARDS_FAIL: "STAKING_REWARDS_FAIL",
                    STAKING_REWARDS_SUCCESS: "STAKING_REWARDS_SUCCESS",
                    SET_KYC_SUCCESS: "SET_KYC_SUCCESS",
                    SET_KYC_FAIL: "SET_KYC_FAIL"
                },
                V = a(22),
                X = a(408),
                Q = a.n(X),
                $ = a(1107);

            function Z(e) {
                var t = e.legalPartner,
                    a = Object($.a)().t;
                return o.a.createElement("div", {
                    className: "mt-5"
                }, o.a.createElement("div", {
                    className: "col-lg-12"
                }, o.a.createElement("div", {
                    className: "section-head"
                }, o.a.createElement("h2", {
                    className: "title title-xl text-center",
                    "data-aos": "fade-up",
                    "data-aos-delay": "100",
                    title: "PARTNER",
                    style: {
                        textTransform: "uppercase"
                    }
                }, a("Legal Partner")))), o.a.createElement("div", {
                    className: "text-center mb-5"
                }, o.a.createElement("div", {
                    className: "row justify-content-center mt-4"
                }, o.a.createElement("div", {
                    className: "pb-5 col-lg-12"
                }, o.a.createElement("div", {
                    className: "pp-card-legal-partner"
                }, o.a.createElement("img", {
                    className: "mx-auto",
                    src: "".concat(t.image),
                    alt: "Silk Legal",
                    width: "300"
                }), o.a.createElement("div", {
                    className: "mt-4"
                }, a(t.description)))))))
            }

            function ee(e) {
                e.advisors;
                var t = e.legalPartner,
                    a = Object($.a)().t;
                return o.a.createElement(o.a.Fragment, null, o.a.createElement("div", {
                    className: "pp-home-advisors-content pp-section-body"
                }, o.a.createElement("div", {
                    className: "container"
                }, o.a.createElement("div", {
                    className: "text-center mb-5"
                }, o.a.createElement("div", {
                    className: "col-lg-12"
                }, o.a.createElement("div", {
                    className: "section-head"
                }, o.a.createElement("h2", {
                    className: "title title-xl",
                    "data-aos": "fade-up",
                    "data-aos-delay": "100",
                    title: "PARTNER"
                }, a("INCUBATOR AND INVESTMENT PARTNER")))), o.a.createElement("div", {
                    className: "col-lg-12 mb-5 mt-4"
                }, o.a.createElement("div", {
                    className: "pb-5 col-lg-12"
                }, o.a.createElement("div", {
                    className: "pp-card-legal-partner"
                }, o.a.createElement("img", {
                    className: "dark-show mx-auto",
                    src: "images/bluezilla-dark.png",
                    alt: "partner",
                    height: "75"
                }), o.a.createElement("img", {
                    className: "light-show mx-auto",
                    src: "images/bluezilla.png",
                    alt: "partner",
                    height: "75"
                }), o.a.createElement("div", {
                    className: "mt-4"
                }, o.a.createElement("p", null, a("We specialize in taking your innovative and new idea from concept to completion through our market leading advisory, investment, development, influencer marketing and legal support services.")), o.a.createElement("p", null, a("We are the only VC with in house developers, designers, marketers, influencers, traders, legal and launch pads.")), o.a.createElement("p", null, a("We help by not only bringing capital and partners, but every aspect of your project from tokenomics to post launch marking.")), o.a.createElement("div", {
                    className: "pt-3"
                }, o.a.createElement("a", {
                    href: "https://bluezilla.vc/",
                    target: "_blank",
                    className: "btn btn-outline-primary"
                }, "Learn more"))))))), o.a.createElement(Z, {
                    legalPartner: t
                }))))
            }
            var te = function(e) {
                Object($.a)().t;
                return o.a.createElement("div", {
                    className: "pp-home-advisors pp-section py-3",
                    id: "advisor"
                }, o.a.createElement(ee, {
                    advisors: P,
                    legalPartner: I
                }))
            };

            function ae(e) {
                var t = e.tiered,
                    a = Object($.a)().t;
                return o.a.createElement(o.a.Fragment, null, "lottery" === t.type && o.a.createElement("div", {
                    className: "col-md-4",
                    "data-aos": "fade-up",
                    "data-aos-delay": "100"
                }, o.a.createElement("div", {
                    className: "pricing-table text-center"
                }, o.a.createElement("div", {
                    className: "row"
                }, o.a.createElement("div", {
                    className: "col-12"
                }, o.a.createElement("p", {
                    className: "bold price-header"
                }, o.a.createElement("b", {
                    className: "text-warning"
                }, a(t.level)))), o.a.createElement("hr", null), o.a.createElement("div", {
                    className: "col-12"
                }, o.a.createElement("p", {
                    className: "light thin mb-0"
                }, a("Staking Requirement"))), o.a.createElement("div", {
                    className: "col-12"
                }, o.a.createElement("p", {
                    className: "bold price"
                }, o.a.createElement("span", null, t.amountStakingRequire))), o.a.createElement("div", {
                    className: "col-12"
                }, o.a.createElement("p", {
                    className: "light thin mb-0"
                }, a("Staking Length Required"))), o.a.createElement("div", {
                    className: "col-12"
                }, o.a.createElement("p", {
                    className: "value price"
                }, o.a.createElement("span", null, a(t.stakingLengthRequire)))), o.a.createElement("div", {
                    className: "col-12"
                }, o.a.createElement("p", {
                    className: "light thin mb-0"
                }, a("Whitelist Requirement Twitter"))), o.a.createElement("div", {
                    className: "col-12"
                }, o.a.createElement("p", {
                    className: "value price"
                }, o.a.createElement("span", null, a(t.tweetRequire)))), o.a.createElement("div", {
                    className: "col-12"
                }, o.a.createElement("p", {
                    className: "light thin mb-0"
                }, a("Lottery Tickets\xa0"))), o.a.createElement("div", {
                    className: "col-12"
                }, o.a.createElement("p", {
                    className: "value price"
                }, o.a.createElement("span", null, a(t.ticket)))), o.a.createElement("hr", null)))), "guaranteed" === t.type && o.a.createElement("div", {
                    className: "col-md-4",
                    "data-aos": "fade-up",
                    "data-aos-delay": "100"
                }, o.a.createElement("div", {
                    className: "pricing-table text-center"
                }, o.a.createElement("div", {
                    className: "row"
                }, o.a.createElement("div", {
                    className: "col-12"
                }, o.a.createElement("p", {
                    className: "bold price-header"
                }, o.a.createElement("b", {
                    className: "text-warning"
                }, a(t.level)))), o.a.createElement("hr", null), o.a.createElement("div", {
                    className: "col-12"
                }, o.a.createElement("p", {
                    className: "light thin mb-0"
                }, a("Staking Requirement"))), o.a.createElement("div", {
                    className: "col-12"
                }, o.a.createElement("p", {
                    className: "bold price"
                }, o.a.createElement("span", null, t.amountStakingRequire))), o.a.createElement("div", {
                    className: "col-12"
                }, o.a.createElement("p", {
                    className: "light thin mb-0"
                }, a("Staking Length Required"))), o.a.createElement("div", {
                    className: "col-12"
                }, o.a.createElement("p", {
                    className: "value price"
                }, o.a.createElement("span", null, a(t.stakingLengthRequire)))), o.a.createElement("div", {
                    className: "col-12"
                }, o.a.createElement("p", {
                    className: "light thin mb-0"
                }, a("Whitelist Requirement Twitter"))), o.a.createElement("div", {
                    className: "col-12"
                }, o.a.createElement("p", {
                    className: "value price"
                }, o.a.createElement("span", null, a(t.tweetRequire)))), o.a.createElement("div", {
                    className: "col-12"
                }, o.a.createElement("p", {
                    className: "light thin mb-0"
                }, a("Guaranteed Allocation"))), o.a.createElement("div", {
                    className: "col-12"
                }, o.a.createElement("p", {
                    className: "value price"
                }, o.a.createElement("span", null, a(t.guaranteedAllocation)))), o.a.createElement("div", {
                    className: "col-12"
                }, o.a.createElement("p", {
                    className: "light thin mb-0"
                }, a("Pool Weight"))), o.a.createElement("div", {
                    className: "col-12"
                }, o.a.createElement("p", {
                    className: "value price"
                }, o.a.createElement("span", null, a(t.poolWeight)))), o.a.createElement("hr", null)))))
            }

            function ne(e) {
                var t = e.TIERED,
                    a = Object($.a)().t;
                return o.a.createElement(o.a.Fragment, null, o.a.createElement("div", {
                    className: "pp-home-how-it-work-content pp-section-body"
                }, o.a.createElement("div", {
                    className: "container"
                }, o.a.createElement("div", {
                    className: "text-center mb-5"
                }, o.a.createElement("h3", {
                    className: "text-uppercase",
                    "data-aos": "fade-up",
                    "data-aos-delay": "300"
                }, o.a.createElement("b", null, a("Round 1 - Allocation Round")))), o.a.createElement("div", {
                    className: "row mb-3"
                }, o.a.createElement(ae, {
                    tiered: t.BRONZE
                }), o.a.createElement(ae, {
                    tiered: t.SILVER
                }), o.a.createElement(ae, {
                    tiered: t.GOLD
                }), o.a.createElement(ae, {
                    tiered: t.PLATINUM
                }), o.a.createElement(ae, {
                    tiered: t.DIAMOND
                }), o.a.createElement(ae, {
                    tiered: t.BLUE_DIAMOND
                })), o.a.createElement("p", {
                    className: "text-center"
                }, a("In the first round, called the \u201cAllocation Round\u201d, users can purchase the amount allotted to them based on their tier.")), o.a.createElement("div", {
                    className: "text-center mb-5 mt-5"
                }, o.a.createElement("h3", {
                    className: "text-uppercase"
                }, o.a.createElement("b", null, a("Round 2 - FCFS ROUND")))), o.a.createElement("div", {
                    className: "row mb-5 align-items-center"
                }, o.a.createElement("div", {
                    className: "col-md-6",
                    "data-aos": "fade-up",
                    "data-aos-delay": "100"
                }, o.a.createElement("img", {
                    src: "/images/gfx-e.png",
                    className: "w-100"
                })), o.a.createElement("div", {
                    className: "col-md-6",
                    "data-aos": "fade-up",
                    "data-aos-delay": "200"
                }, o.a.createElement("p", {
                    dangerouslySetInnerHTML: {
                        __html: a("In round 2, the unsold tokens from the first round are made available on a FCFS basis, only to guaranteed tiers (Platinum and above). These members can purchase an additional amount that is determined by a tier-based formula. This round is open until all tokens are sold, typically lasting for only a few minutes. After all the tokens are sold, the IDO is concluded.")
                    }
                }), o.a.createElement("p", {
                    className: "mt-3"
                }, o.a.createElement("b", {
                    className: "how-it-work-heading"
                }, a("We will be collecting both data and feedback on the IDO structure in order to optimize the system over time as well as taking into consideration community feedback and potential DAO proposals."))), o.a.createElement("p", null, a("Our system is a predictable and provably fair system giving our users the proper incentives to accumulate and hold tokens and support each and every project launched.  Over time, we will tweak weights, add new tiers and change other parameters as necessary to keep the system functional, competitive and rewarding for all community members.")), o.a.createElement("p", null, a("$BSCPAD is the next evolution of blockchain launchpads solving the fundamental flaws that plague existing launchpads. This platform benefits all holders of the token and allows for fair launches giving traders of all sizes the opportunity to invest in the best upcoming Binance Smart Chain projects.")))))))
            }
            var re = function(e) {
                    var t = Object($.a)().t;
                    return o.a.createElement(o.a.Fragment, null, o.a.createElement("div", {
                        className: "pp-home-how-it-work pp-section pt-3 pb-5",
                        id: "how-it-work"
                    }, o.a.createElement("div", {
                        className: "container"
                    }, o.a.createElement("div", {
                        className: "row justify-content-center text-center"
                    }, o.a.createElement("div", {
                        className: "col-lg-8"
                    }, o.a.createElement("div", {
                        className: "section-head"
                    }, o.a.createElement("h2", {
                        className: "title title-xl",
                        "data-aos": "fade-up",
                        "data-aos-delay": "100",
                        title: t("Tiered System")
                    }, t("THE BSCPAD TIERED SYSTEM")), o.a.createElement("p", {
                        "data-aos": "fade-up",
                        "data-aos-delay": "200",
                        className: "mt-3"
                    }, t("BSCPad will showcase a fixed tier system based on the number of tokens staked. Lottery Tiers will share 20% of total raise and rest 80% of the raise is assigned for guaranteed allocation tiers based on the pool weights assigned.")))))), o.a.createElement(ne, {
                        TIERED: O
                    })))
                },
                oe = function(e) {
                    var t = Object($.a)().t;
                    return o.a.createElement(o.a.Fragment, null, o.a.createElement("div", {
                        className: "pp-homepage"
                    }, o.a.createElement("div", {
                        className: "pp-home-banner"
                    }, o.a.createElement("div", {
                        className: "container"
                    }, o.a.createElement("h1", {
                        className: "text-center text-uppercase",
                        "data-aos": "fade-up",
                        "data-aos-delay": "100"
                    }, t("BSCPAD is the first decentralized IDO platform for the Binance Smart Chain Network.")), o.a.createElement("div", {
                        className: "row justify-content-center"
                    }, o.a.createElement("div", {
                        className: "col-md-8"
                    }, o.a.createElement("p", {
                        "data-aos": "fade-up",
                        "data-aos-delay": "200"
                    }, t("BSCPad will empower crypto currency projects with the ability to distribute tokens and raise liquidity.")))), o.a.createElement("div", {
                        className: "mt-4"
                    }, o.a.createElement(V.a, {
                        "data-aos": "fade-up",
                        "data-aos-delay": "300",
                        className: "btn btn-primary mb-3 btn-lg me-3",
                        to: g
                    }, t("View all Projects")), o.a.createElement("a", {
                        target: "_blank",
                        className: "btn btn-primary btn-pancake btn-lg btn-buy-on mb-3 me-3",
                        href: "https://pancakeswap.finance/swap?outputCurrency=0x5A3010d4d8D3B5fB49f8B6E57FB9E48063f16700"
                    }, o.a.createElement("b", {
                        style: {
                            whiteSpace: "nowrap"
                        },
                        className: "d-flex align-items-center justify-content-center"
                    }, t("Buy on"), "\xa0", o.a.createElement("img", {
                        src: "/images/pancake-swap.png",
                        height: "20"
                    }), "\xa0Pancake Swap")), o.a.createElement("a", {
                        "data-aos": "fade-up",
                        "data-aos-delay": "400",
                        className: "btn btn-success btn-lg mb-3 me-3",
                        href: "https://forms.gle/rLU29wn6RwPDWKLm7",
                        target: "_blank"
                    }, t("Apply for IDO")), o.a.createElement("a", {
                        "data-aos": "fade-up",
                        "data-aos-delay": "400",
                        className: "btn btn-mexc btn-lg mb-3 me-3",
                        href: "https://www.mexc.com/exchange/BSCPAD_USDT",
                        target: "_blank"
                    }, o.a.createElement("img", {
                        src: "/images/mexc.svg",
                        height: "20"
                    }), "\xa0", o.a.createElement("span", null, t("Buy on MEXC"))), o.a.createElement("a", {
                        "data-aos": "fade-up",
                        "data-aos-delay": "400",
                        className: "btn btn-gateio btn-lg mb-3",
                        href: "https://www.gate.io/trade/BSCPAD_USDT?ch=ann19843",
                        target: "_blank"
                    }, o.a.createElement("img", {
                        src: "/images/gateio.svg",
                        height: "20"
                    }), "\xa0", o.a.createElement("span", null, t("Buy on Gate.io"))), o.a.createElement("a", {
                        "data-aos": "fade-up",
                        "data-aos-delay": "400",
                        className: "btn btn-fiat2bnb btn-lg mb-3",
                        href: "https://fiat2bnb.com/?integration=9&embed=0",
                        target: "_blank"
                    }, o.a.createElement("img", {
                        src: "/images/fiat2bnb.png",
                        height: "20"
                    }), "\xa0", o.a.createElement("span", null, t("Buy with Fiat")))), o.a.createElement("div", {
                        className: "mt-5 text-center"
                    }, o.a.createElement("a", {
                        className: "btn btn-outline-primary btn-sm",
                        href: "https://t.me/bscpad",
                        target: "_blank"
                    }, o.a.createElement("i", {
                        className: "fas fa-paper-plane me-1"
                    }), o.a.createElement("span", null, t("Join us on Telegram"))), o.a.createElement("a", {
                        className: "btn btn-outline-primary btn-sm mx-3",
                        href: "https://bscpad.medium.com/",
                        target: "_blank"
                    }, o.a.createElement("i", {
                        className: "fab fa-medium-m me-1"
                    }), o.a.createElement("span", null, t("Follow our Medium"))), o.a.createElement("a", {
                        className: "btn btn-outline-primary btn-sm",
                        href: "https://twitter.com/bscpad",
                        target: "_blank"
                    }, o.a.createElement("i", {
                        className: "fab fa-twitter me-1"
                    }), o.a.createElement("span", null, t("Follow our Twitter")))))), o.a.createElement("div", {
                        className: "pp-home-partners"
                    }, o.a.createElement("div", {
                        className: "container"
                    }, o.a.createElement("div", {
                        className: "pp-home-partners-content d-flex align-items-center justify-content-center"
                    }, o.a.createElement("h6", {
                        className: "mb-0 text-end"
                    }, t("Our Partners")), o.a.createElement("a", {
                        className: "me-4 mb-2 mb-lg-0",
                        target: "_blank",
                        href: "https://chain.link/",
                        style: {
                            color: "#2a5ada"
                        }
                    }, o.a.createElement("img", {
                        height: "48",
                        src: "images/chainlink.svg",
                        alt: "partner"
                    })), o.a.createElement("a", {
                        target: "_blank",
                        href: "https://tronpad.network/"
                    }, o.a.createElement("img", {
                        className: "dark-show",
                        height: "48",
                        src: "images/TronPad_white.png",
                        alt: "partner"
                    }), o.a.createElement("img", {
                        className: "light-show",
                        height: "48",
                        src: "images/TronPad_black.png",
                        alt: "partner"
                    })), o.a.createElement("a", {
                        target: "_blank",
                        href: "https://bluezilla.vc/"
                    }, o.a.createElement("img", {
                        className: "dark-show",
                        height: "48",
                        src: "images/bluezilla-dark.png",
                        alt: "partner"
                    }), o.a.createElement("img", {
                        className: "light-show",
                        height: "48",
                        src: "images/bluezilla.png",
                        alt: "partner"
                    }))))), o.a.createElement("div", {
                        className: "pp-home-about pp-section",
                        id: "about"
                    }, o.a.createElement("div", {
                        className: "container"
                    }, o.a.createElement("div", {
                        className: "row justify-content-center text-center"
                    }, o.a.createElement("div", {
                        className: "col-lg-6"
                    }, o.a.createElement("div", {
                        className: "section-head"
                    }, o.a.createElement("h2", {
                        className: "title title-xl",
                        "data-aos": "fade-up",
                        "data-aos-delay": "100",
                        title: t("What and Why")
                    }, t("ABOUT US")))))), o.a.createElement("div", {
                        className: "pp-home-about-content pp-section-body mt-4"
                    }, o.a.createElement("div", {
                        className: "container"
                    }, o.a.createElement("div", {
                        className: "row align-items-center"
                    }, o.a.createElement("div", {
                        className: "col-md-6",
                        "data-aos": "fade-up",
                        "data-aos-delay": "200"
                    }, o.a.createElement("h6", null, t("WHAT IS BSCPAD?")), o.a.createElement("h2", null, t("The BSC Launch Pad is the first decentralized IDO platform for the Binance Smart Chain Network.")), o.a.createElement("p", {
                        className: "lead-s2"
                    }, t("BSCPad will empower crypto currency projects with the ability to distribute tokens and raise liquidity.")), o.a.createElement("h6", {
                        className: "mt-4"
                    }, t("WHY CHOOSE US?")), o.a.createElement("h2", null, t("BSCPad has found a solution to incentivize and reward all token stakers in a way that is inclusive and with a low barrier to entry.")), o.a.createElement("p", {
                        dangerouslySetInnerHTML: {
                            __html: t("The fundamental flaws of existing launchpads is that acquiring enough tokens to participate in the ecosystem is prohibitive, and even if you do stake the tokens, you are not guaranteed an allocation spot. They are based on a first come first serve basis where automated bots can fill the whitelist spots in a matter of seconds. BSCPad is creating fair decentralized launches, you can choose between a lottery tier or a guaranteed allocation tier and if you win the lottery you get a guaranteed allocation in the first round (Allocation round).")
                        }
                    }), o.a.createElement("p", {
                        dangerouslySetInnerHTML: {
                            __html: t("The hallmark of the BSCPad is a two-round system that makes every tier level guaranteed an allocation. There is no first come first serve or bots; only fair distributed rewards for all participants.")
                        }
                    })), o.a.createElement("div", {
                        className: "col-md-6"
                    }, o.a.createElement("div", {
                        className: "nk-block-img nk-block-ca",
                        "data-aos": "fade-up",
                        "data-aos-delay": "200",
                        style: {
                            position: "relative"
                        }
                    }, o.a.createElement("div", {
                        className: "nk-circle-animation nk-df-center fast"
                    }), o.a.createElement("img", {
                        className: "shadow rounded w-100 dark-show",
                        src: "images/sc-medium-a.png",
                        alt: ""
                    }), o.a.createElement("img", {
                        className: "shadow rounded w-100 light-show",
                        src: "images/sc-medium-w.png",
                        alt: ""
                    }))))))), o.a.createElement(re, null), o.a.createElement(te, null), o.a.createElement("div", {
                        className: "pp-home-contact pp-section py-5",
                        id: "contact"
                    }, o.a.createElement("div", {
                        className: "container"
                    }, o.a.createElement("div", {
                        className: "row justify-content-center text-center"
                    }, o.a.createElement("div", {
                        className: "col-lg-6"
                    }, o.a.createElement("div", {
                        className: "section-head"
                    }, o.a.createElement("h2", {
                        className: "title title-xl",
                        "data-aos": "fade-up",
                        "data-aos-delay": "100",
                        title: t("CONTACT US")
                    }, t("CONTACT")))))), o.a.createElement("div", {
                        className: "pp-home-contact-content pp-section-body mt-5"
                    }, o.a.createElement("div", {
                        className: "container"
                    }, o.a.createElement("div", {
                        className: "row justify-content-center align-items-center gutter-vr-50px"
                    }, o.a.createElement("div", {
                        className: "col-lg-5 text-center order-lg-first"
                    }, o.a.createElement("div", {
                        className: "nk-block-contact nk-block-contact-s1",
                        "data-aos": "fade-up",
                        "data-aos-delay": "100"
                    }, o.a.createElement("ul", {
                        className: "contact-list ps-1"
                    }, o.a.createElement("li", {
                        "data-aos": "fade-up",
                        "data-aos-delay": "300"
                    }, o.a.createElement("em", {
                        className: "contact-icon fas fa-headset"
                    }), o.a.createElement("div", {
                        className: "contact-text"
                    }, o.a.createElement("a", {
                        href: "https://bluezilla.jitbit.com/helpdesk/",
                        target: "_blank"
                    }, o.a.createElement("span", null, "Contact Support")))), o.a.createElement("li", {
                        "data-aos": "fade-up",
                        "data-aos-delay": "400"
                    }, o.a.createElement("em", {
                        className: "contact-icon fas fa-paper-plane"
                    }), o.a.createElement("div", {
                        className: "contact-text"
                    }, o.a.createElement("a", {
                        href: "https://t.me/bscpad",
                        target: "_blank"
                    }, " ", o.a.createElement("span", null, t("Join us on Telegram"))))), o.a.createElement("li", {
                        "data-aos": "fade-up",
                        "data-aos-delay": "400"
                    }, o.a.createElement("em", {
                        className: "contact-icon fab fa-twitter"
                    }), o.a.createElement("div", {
                        className: "contact-text"
                    }, o.a.createElement("a", {
                        href: "https://twitter.com/bscpad",
                        target: "_blank"
                    }, " ", o.a.createElement("span", null, t("Follow our Twitter"))))), o.a.createElement("li", {
                        "data-aos": "fade-up",
                        "data-aos-delay": "500"
                    }, o.a.createElement("em", {
                        className: "contact-icon fas fa-globe"
                    }), o.a.createElement("div", {
                        className: "contact-text"
                    }, o.a.createElement("span", null, "www.bscpad.com")))), o.a.createElement("div", {
                        className: "nk-circle-animation nk-df-center white small"
                    })))))))), o.a.createElement("div", {
                        className: "modal fade",
                        id: "team-popup-2",
                        tabIndex: "-1",
                        "aria-labelledby": "team-popup-2Label",
                        "aria-hidden": "true",
                        "data-bs-backdrop": "static",
                        "data-bs-keyboard": "false"
                    }, o.a.createElement("div", {
                        className: "modal-dialog modal-lg modal-dialog-centered pp-modal-team"
                    }, o.a.createElement("div", {
                        className: "modal-content"
                    }, o.a.createElement("button", {
                        type: "button",
                        className: "btn-close",
                        "data-bs-dismiss": "modal",
                        "aria-label": "Close"
                    }), o.a.createElement("div", {
                        className: "modal-body"
                    }, o.a.createElement("div", {
                        className: "row mb-3"
                    }, o.a.createElement("div", {
                        className: "col-md-6 text-center"
                    }, o.a.createElement("div", {
                        className: "mb-3 pe-md-3"
                    }, o.a.createElement("img", {
                        src: "images/LESTER_LIM.jpeg",
                        alt: "team",
                        className: "no-bdrs w-100 borras"
                    })), o.a.createElement("p", {
                        className: "mb-1"
                    }, o.a.createElement("img", {
                        src: "images/x21.png",
                        alt: "team",
                        className: "no-bdrs",
                        height: "40"
                    })), o.a.createElement("p", null, o.a.createElement("a", {
                        target: "_blank",
                        href: "https://x21digital.com"
                    }, "https://x21digital.com"))), o.a.createElement("div", {
                        className: "col-md-6"
                    }, o.a.createElement("h3", null, "LESTER LIM"), o.a.createElement("p", {
                        style: {
                            opacity: .6
                        }
                    }, t("Founder at X21 Digital")), o.a.createElement("p", null), o.a.createElement("hr", null), o.a.createElement("p", null, t("Lester is the founder of X21 Digital. He incubates and supports promising projects via his marketing experience & vast connections within the blockchain ecosystem. His latest incubation projects include Blank Wallet, DAOventures and Vortex Defi.")), o.a.createElement("p", null, t("He focuses on strategic directions, token metrics, and connecting the dots as a Strategic Advisor to other projects by bringing in the RIGHT connections and resources to shortcut their success.")))), o.a.createElement("p", null, t("Also Strategic Advisor to PolkaFoundry, Oddz, Project Inverse, MahaDao & Finxflo.")), o.a.createElement("p", {
                        className: "mb-0"
                    }, t("The BSCPAD team and Lester both share a common love of Blockchain Technology \u2013 and are excited to leverage his vast connections to bring mass exposure to BSCPAD. We are excited to be a part of the exclusive X21 Digital portfolio and join the other prestigious projects who have benefited from Lester\u2019s guidance.")))))), o.a.createElement("div", {
                        className: "modal fade",
                        id: "team-popup-3",
                        tabIndex: "-1",
                        "aria-labelledby": "team-popup-3Label",
                        "aria-hidden": "true",
                        "data-bs-backdrop": "static",
                        "data-bs-keyboard": "false"
                    }, o.a.createElement("div", {
                        className: "modal-dialog modal-lg modal-dialog-centered pp-modal-team"
                    }, o.a.createElement("div", {
                        className: "modal-content"
                    }, o.a.createElement("button", {
                        type: "button",
                        className: "btn-close",
                        "data-bs-dismiss": "modal",
                        "aria-label": "Close"
                    }), o.a.createElement("div", {
                        className: "modal-body"
                    }, o.a.createElement("div", {
                        className: "row mb-3"
                    }, o.a.createElement("div", {
                        className: "col-md-6 text-center"
                    }, o.a.createElement("div", {
                        className: "mb-3 pe-md-3"
                    }, o.a.createElement("img", {
                        src: "images/Ian_Friend.jpeg",
                        alt: "team",
                        className: "no-bdrs w-100 borras"
                    })), o.a.createElement("p", {
                        className: "mb-1"
                    }, o.a.createElement("img", {
                        src: "images/partner-1.png",
                        alt: "team",
                        className: "no-bdrs",
                        height: "40"
                    })), o.a.createElement("p", null, o.a.createElement("a", {
                        target: "_blank",
                        href: "https://ferrum.network/"
                    }, "https://ferrum.network/"))), o.a.createElement("div", {
                        className: "col-md-6"
                    }, o.a.createElement("h3", null, "IAN FRIEND"), o.a.createElement("p", {
                        style: {
                            opacity: .6
                        }
                    }, t("Co-Founder and COO at Ferrum Network")), o.a.createElement("p", null), o.a.createElement("hr", null), o.a.createElement("p", null, t("Ian Friend is the Co-Founder and COO at Ferrum Network.")))))))), o.a.createElement("div", {
                        className: "modal fade",
                        id: "team-popup-4",
                        tabIndex: "-1",
                        "aria-labelledby": "team-popup-3Label",
                        "aria-hidden": "true",
                        "data-bs-backdrop": "static",
                        "data-bs-keyboard": "false"
                    }, o.a.createElement("div", {
                        className: "modal-dialog modal-lg modal-dialog-centered pp-modal-team"
                    }, o.a.createElement("div", {
                        className: "modal-content"
                    }, o.a.createElement("button", {
                        type: "button",
                        className: "btn-close",
                        "data-bs-dismiss": "modal",
                        "aria-label": "Close"
                    }), o.a.createElement("div", {
                        className: "modal-body"
                    }, o.a.createElement("div", {
                        className: "row mb-3"
                    }, o.a.createElement("div", {
                        className: "col-md-6 text-center"
                    }, o.a.createElement("div", {
                        className: "mb-3 pe-md-3"
                    }, o.a.createElement("img", {
                        src: "images/Danish_Chaudhry.jpg",
                        alt: "team",
                        className: "no-bdrs w-100 borras"
                    })), o.a.createElement("p", {
                        className: "mb-1"
                    }, o.a.createElement("img", {
                        src: "images/exchange.png",
                        alt: "team",
                        className: "no-bdrs",
                        style: {
                            maxWidth: "250px",
                            maxHeight: "40px"
                        }
                    })), o.a.createElement("p", null, o.a.createElement("a", {
                        target: "_blank",
                        href: "https://exchange.bitcoin.com/"
                    }, "https://exchange.bitcoin.com/"))), o.a.createElement("div", {
                        className: "col-md-6"
                    }, o.a.createElement("h3", null, "DANISH CHAUDHRY"), o.a.createElement("p", {
                        style: {
                            opacity: .6
                        }
                    }, t("CEO at Bitcoin.com Exchange \u2013 Entrepreneur, Startup Advisor, Mentor and Investor")), o.a.createElement("p", null), o.a.createElement("hr", null), o.a.createElement("p", null, t("Danish Chaudhry is the CEO of Bitcoin.com Exchange, an up and coming exchange that focuses on bringing the most promising projects to market. He is an active investor and advisor, having backed some of the most prominent projects out there from an early stage such as matic (now polygon), marlin, cere, moonbeam, sifchain, flow, graph and the list goes on.")), o.a.createElement("p", null, t("Danish has been in the blockchain space since the early days. He has a background in finance where he was a PM at Blackrock for a number of years, having founded and successfully exited two startups, he's built fintech and insurtech incubators at his previous VC that have produced startups valued at over $2bn.")))))))), o.a.createElement("div", {
                        className: "modal fade",
                        id: "team-popup-5",
                        tabIndex: "-1",
                        "aria-labelledby": "team-popup-3Label",
                        "aria-hidden": "true",
                        "data-bs-backdrop": "static",
                        "data-bs-keyboard": "false"
                    }, o.a.createElement("div", {
                        className: "modal-dialog modal-lg modal-dialog-centered pp-modal-team"
                    }, o.a.createElement("div", {
                        className: "modal-content"
                    }, o.a.createElement("button", {
                        type: "button",
                        className: "btn-close",
                        "data-bs-dismiss": "modal",
                        "aria-label": "Close"
                    }), o.a.createElement("div", {
                        className: "modal-body"
                    }, o.a.createElement("div", {
                        className: "row mb-3"
                    }, o.a.createElement("div", {
                        className: "col-md-6 text-center"
                    }, o.a.createElement("div", {
                        className: "mb-3 pe-md-3"
                    }, o.a.createElement("img", {
                        src: "images/exntc.png",
                        alt: "team",
                        className: "no-bdrs w-100 borras"
                    })), o.a.createElement("p", {
                        className: "mb-1"
                    }, o.a.createElement("img", {
                        src: "images/exnetwork_capital.jpg",
                        alt: "team",
                        className: "no-bdrs",
                        height: "40"
                    })), o.a.createElement("p", null, o.a.createElement("a", {
                        target: "_blank",
                        href: "https://exnetworkcapital.com"
                    }, "https://exnetworkcapital.com"))), o.a.createElement("div", {
                        className: "col-md-6"
                    }, o.a.createElement("h3", null, "EXNETWORK CAPITALY"), o.a.createElement("p", {
                        style: {
                            opacity: .6
                        }
                    }, t("Exnetwork Capital is an investment firm focused on funding and incubating blockchain projects. It is composed of a DAO of different investors all helping out to ensure the portfolio companies' success.")), o.a.createElement("p", null), o.a.createElement("hr", null), o.a.createElement("p", null, t("Exnetwork Capital's incubator program will help mentor BSCPAD and provide support from their network of entrepreneurs who will help take the BSC Launch Pad to new levels. Exnetwork primarily focuses on the decentralized market and can assist with many areas such as token design, fundraising, and marketing. New projects entering the launchpad will be able to glean much knowledge from the Exnetwork Capital team.")), o.a.createElement("p", null, t("We are aligned in supporting the creation and launching of new projects. We aim to help these new BSC projects to succeed and garner the same attention, hype and love as their erc counterparts.")))))))), o.a.createElement("div", {
                        className: "modal fade",
                        id: "team-popup-6",
                        tabIndex: "-1",
                        "aria-labelledby": "team-popup-6Label",
                        "aria-hidden": "true",
                        "data-bs-backdrop": "static",
                        "data-bs-keyboard": "false"
                    }, o.a.createElement("div", {
                        className: "modal-dialog modal-lg modal-dialog-centered pp-modal-team"
                    }, o.a.createElement("div", {
                        className: "modal-content"
                    }, o.a.createElement("button", {
                        type: "button",
                        className: "btn-close",
                        "data-bs-dismiss": "modal",
                        "aria-label": "Close"
                    }), o.a.createElement("div", {
                        className: "modal-body"
                    }, o.a.createElement("div", {
                        className: "row mb-3"
                    }, o.a.createElement("div", {
                        className: "col-md-6 text-center"
                    }, o.a.createElement("div", {
                        className: "mb-3 pe-md-3"
                    }, o.a.createElement("img", {
                        src: "images/TIM_FROST.jpg",
                        alt: "team",
                        className: "no-bdrs w-100 borras"
                    })), o.a.createElement("p", {
                        className: "mb-1"
                    }, o.a.createElement("img", {
                        src: "images/yield.png",
                        alt: "team",
                        className: "no-bdrs",
                        height: "40"
                    })), o.a.createElement("p", null, o.a.createElement("a", {
                        target: "_blank",
                        href: "https://www.yield.app"
                    }, "https://www.yield.app"))), o.a.createElement("div", {
                        className: "col-md-6"
                    }, o.a.createElement("h3", null, "TIM FROST"), o.a.createElement("p", {
                        style: {
                            opacity: .6
                        }
                    }, t("Tim Frost is CEO and co-founder of YIELD App which is one of the fastest growing fintech companies in the crypto space. He has extensive experience in FinTech, marketing, business development, and operations. YIELD App is the third digital finance platform Tim has brought to the market. He was a founding member of the Wirex team and supported operations, business development, and marketing for the first 18 months. Tim also helped bring EQI Bank to the global market as a digital challenger to conventional banking, with an average client AUM of $250,000. Tim's experience in blockchain technology includes early involvement with numerous successful projects including QTUM, NEO, Paxful, Polymath, Selfkey and Everex. Tim has been building crypto and fintech companies since 2014.")), o.a.createElement("p", null), o.a.createElement("hr", null), o.a.createElement("p", null, t("Adding Tim Frost as a strategic partner and advisor reinforces our commitment to aggressive growth for BSCPAD. Tim will help lead our efforts with his vast experience in FinTech, marketing, business development, and operations. We will be utilizing his expertise in these areas to help lead to even higher customer adoption and expansion into new industry verticals with BSCPAD.")))))))), o.a.createElement("div", {
                        className: "modal fade",
                        id: "team-popup-8",
                        tabIndex: "-1",
                        "aria-labelledby": "team-popup-8Label",
                        "aria-hidden": "true",
                        "data-bs-backdrop": "static",
                        "data-bs-keyboard": "false"
                    }, o.a.createElement("div", {
                        className: "modal-dialog modal-lg modal-dialog-centered pp-modal-team"
                    }, o.a.createElement("div", {
                        className: "modal-content"
                    }, o.a.createElement("button", {
                        type: "button",
                        className: "btn-close",
                        "data-bs-dismiss": "modal",
                        "aria-label": "Close"
                    }), o.a.createElement("div", {
                        className: "modal-body"
                    }, o.a.createElement("div", {
                        className: "row mb-3"
                    }, o.a.createElement("div", {
                        className: "col-md-6 text-center"
                    }, o.a.createElement("div", {
                        className: "mb-3 pe-md-3"
                    }, o.a.createElement("img", {
                        src: "images/innovion.png",
                        alt: "team",
                        className: "no-bdrs w-100 borras"
                    })), o.a.createElement("p", {
                        className: "mb-1"
                    }, o.a.createElement("img", {
                        src: "images/innovion.svg",
                        alt: "team",
                        className: "no-bdrs",
                        height: "40"
                    })), o.a.createElement("p", null, o.a.createElement("a", {
                        target: "_blank",
                        href: "https://innovion.co"
                    }, "https://innovion.co"))), o.a.createElement("div", {
                        className: "col-md-6"
                    }, o.a.createElement("h3", null, "INNOVION"), o.a.createElement("p", {
                        style: {
                            opacity: .6
                        }
                    }, t("Innovion has built a prestigious reputation with a unique approach to guerilla marketing, collaborating with over 200 blockchain projects.")), o.a.createElement("p", null, o.a.createElement("a", {
                        className: "me-3",
                        target: "_blank",
                        href: "https://www.linkedin.com/company/innovionofficial/"
                    }, o.a.createElement("em", {
                        className: "fab fa-linkedin-in"
                    }))), o.a.createElement("hr", null), o.a.createElement("p", null, t("Innovion will strengthen our Public reach and further grow our client base.")))))))), o.a.createElement(Q.a, {
                        params: {
                            particles: {
                                number: {
                                    value: 80,
                                    density: {
                                        enable: !0,
                                        value_area: 2e3
                                    }
                                },
                                color: {
                                    value: "#ffffff"
                                },
                                shape: {
                                    type: "circle",
                                    stroke: {
                                        width: 0,
                                        color: "#000000"
                                    },
                                    polygon: {
                                        nb_sides: 5
                                    }
                                },
                                opacity: {
                                    value: .5,
                                    random: !1,
                                    anim: {
                                        enable: !1,
                                        speed: 1,
                                        opacity_min: .1,
                                        sync: !1
                                    }
                                },
                                size: {
                                    value: 3,
                                    random: !0,
                                    anim: {
                                        enable: !1,
                                        speed: 40,
                                        size_min: .1,
                                        sync: !1
                                    }
                                },
                                line_linked: {
                                    enable: !0,
                                    distance: 150,
                                    color: "#ffffff",
                                    opacity: .4,
                                    width: 1
                                },
                                move: {
                                    enable: !0,
                                    speed: 6,
                                    direction: "none",
                                    random: !1,
                                    straight: !1,
                                    out_mode: "out",
                                    bounce: !1,
                                    attract: {
                                        enable: !1,
                                        rotateX: 600,
                                        rotateY: 1200
                                    }
                                }
                            },
                            interactivity: {
                                detect_on: "canvas",
                                events: {
                                    onhover: {
                                        enable: !0,
                                        mode: "repulse"
                                    },
                                    onclick: {
                                        enable: !0,
                                        mode: "push"
                                    },
                                    resize: !0
                                },
                                modes: {
                                    grab: {
                                        distance: 400,
                                        line_linked: {
                                            opacity: 1
                                        }
                                    },
                                    bubble: {
                                        distance: 400,
                                        size: 40,
                                        duration: 2,
                                        opacity: 8,
                                        speed: 3
                                    },
                                    repulse: {
                                        distance: 200,
                                        duration: .4
                                    },
                                    push: {
                                        particles_nb: 4
                                    },
                                    remove: {
                                        particles_nb: 2
                                    }
                                }
                            },
                            retina_detect: !0
                        }
                    }))
                },
                ie = function(e) {
                    return o.a.createElement(o.a.Fragment, null, o.a.createElement("div", {
                        className: "container py-5"
                    }, o.a.createElement("div", {
                        className: "d-flex align-items-start tab-term"
                    }, o.a.createElement("div", {
                        className: "nav nav-pills-policy flex-column nav-pills me-4",
                        id: "v-pills-tab",
                        role: "tablist",
                        "aria-orientation": "vertical"
                    }, o.a.createElement(V.a, {
                        to: w,
                        className: "nav-link text-start",
                        id: "v-pills-terms-tab"
                    }, "Terms of Use "), o.a.createElement(V.a, {
                        to: T,
                        className: "nav-link text-start active",
                        id: "v-pills-privacy-policy-tab"
                    }, "Privacy Policy"), o.a.createElement(V.a, {
                        to: S,
                        className: "nav-link text-start",
                        id: "v-pills-cookies-policy-tab"
                    }, "Cookies Policy"), o.a.createElement(V.a, {
                        to: N,
                        className: "nav-link text-start",
                        id: "v-pills-staking-policy-tab"
                    }, "Staking Policy"), o.a.createElement(V.a, {
                        to: k,
                        className: "nav-link text-start",
                        id: "v-pills-clickwrap-acceptance-tab"
                    }, "Clickwrap Acceptance")), o.a.createElement("div", {
                        className: "tab-content",
                        id: "v-pills-policy-tabContent"
                    }, o.a.createElement("div", {
                        className: "tab-pane fade show active",
                        id: "v-pills-privacy-policy",
                        role: "tabpanel",
                        "aria-labelledby": "v-pills-privacy-policy-tab"
                    }, o.a.createElement(o.a.Fragment, null, o.a.createElement("p", {
                        className: "mb-2",
                        style: {
                            textAlign: "center"
                        }
                    }, o.a.createElement("b", null, "BSCP DIGITAL LIMITED")), o.a.createElement("p", {
                        className: "mb-2",
                        style: {
                            textAlign: "center"
                        }
                    }, o.a.createElement("b", null, "Privacy Policy of ", o.a.createElement("a", {
                        href: "https://bscpad.com/"
                    }, "https://bscpad.com/"))), o.a.createElement("p", {
                        style: {
                            textAlign: "center"
                        }
                    }, o.a.createElement("small", null, "Last revised Date: 4", o.a.createElement("sup", null, "th"), " September 2021")), o.a.createElement("h3", null, "Introduction"), o.a.createElement("p", null, "This Privacy Policy describes how BSCP Digital Limited (herein referred to as ", o.a.createElement("b", null, '"BSCPAD"'), ", ", o.a.createElement("b", null, '"We"'), ", ", o.a.createElement("b", null, '"Our"'), ", and ", o.a.createElement("b", null, '"Us"'), ") collects, uses, processes, discloses, shares, transfers, and protects the information You provide on ", o.a.createElement("a", {
                        href: "https://bscpad.com/"
                    }, "https://bscpad.com/"), " (", o.a.createElement("b", null, '"Website"'), "). This Privacy Policy constitutes a part of the Terms and Conditions of the Website (", o.a.createElement("b", null, '"T&Cs"'), "). The terms used in this Privacy Policy will share the same definition as those stipulated in the T&Cs except for others indicated herein."), o.a.createElement("p", null, "We respect and value your privacy as well as the integrity of the information You have provided and/or permitted Us to collect. Thus, We endeavour to follow industry standards to ensure the security and confidentiality of your Personal Information when You use Our Services or access BSCPAD Platform."), o.a.createElement("p", null, "When accessing, connecting, using, clicking on, or engaging in any Services provided on BSCPAD Platform, You are strongly advised to carefully read, acknowledge, understand, and accept all terms stipulated in this Privacy Policy. We will not use your information, in any shape or form, for any other purpose that has not been indicated in this Privacy Policy or the T&Cs without providing You prior notification or obtaining consent from You."), o.a.createElement("p", null, "This Privacy Policy has incorporated several provisions from the General Data Protection Regulation (", o.a.createElement("b", null, '"GDPR"'), "), specifically following its Personal Information Processing rules within the European Economic Area (", o.a.createElement("b", null, '"EEA"'), ")."), o.a.createElement("p", null, "This Privacy Policy will inform You about the following matters among several others:"), o.a.createElement("ul", null, o.a.createElement("li", null, "Acceptance of the Privacy Policy"), o.a.createElement("li", null, "Our Relationship with You"), o.a.createElement("li", null, "Personal Information that We collect"), o.a.createElement("li", null, "How We collect Personal Information"), o.a.createElement("li", null, "How We use Personal Information"), o.a.createElement("li", null, "How We protect Personal Information"), o.a.createElement("li", null, "How long We retain Personal Information"), o.a.createElement("li", null, "Cookies"), o.a.createElement("li", null, "Sharing your Personal Information"), o.a.createElement("li", null, "Third-Party Collection of Personal Information"), o.a.createElement("li", null, "Designated Countries and Your Legal Rights"), o.a.createElement("li", null, "Rights of the residents of the EEA"), o.a.createElement("li", null, "Cross-Border Transfer of Personal Information"), o.a.createElement("li", null, "Limitations"), o.a.createElement("li", null, "Updates or amendments to the Privacy Policy"), o.a.createElement("li", null, "How to contact BSCPAD")), o.a.createElement("ol", null, o.a.createElement("li", null, o.a.createElement("b", null, "Acceptance of the Privacy Policy"), o.a.createElement("p", null, "By accessing, connecting, clicking on, using, or engaging in Our Services, You indicate and confirm that You have consented and agreed to the terms of this Privacy Policy. We will not use your Personal Information for any other purpose that has not been covered in this Privacy Policy or the T&Cs without providing You prior notification or obtaining your consent."), o.a.createElement("p", null, "If You do not agree, either partially or wholly, to this Privacy Policy, You must immediately discontinue accessing, connecting, using, or engaging in Our Services and BSCPAD Platform. This Privacy Policy does not apply to services offered by other companies or service providers or other websites linked from Our Platform.")), o.a.createElement("li", null, o.a.createElement("b", null, "Our Relationship with You"), o.a.createElement("p", null, "BSCPAD has the relationship with individuals on its Services as described below:"), o.a.createElement("p", null, '"User" is an individual providing personal information to Us via Our Website, Medium pages, social media accounts, or other means. For example, User can engage and complete additional BSCPAD social media engagement tasks, to entitle for add up to the whitelist for each IDO fundraising event or interact with Us on Our social media accounts.'), o.a.createElement("p", null, 'Hereinafter, We may refer to User as "You" in this Privacy Policy.')), o.a.createElement("li", null, o.a.createElement("b", null, "Personal Information that We collect"), o.a.createElement("p", null, "For the purposes of this Privacy Policy, Personal Information is information that can be used to identify, describe, relate, or associate with a particular individual. The following are the types of information We collect, store, and process when You use Our services:"), o.a.createElement("ol", null, o.a.createElement("li", null, "Information provided by You when connecting with BSCPAD and for KYC purpose", o.a.createElement("p", null, 'Prior to connecting or participating in BSCPAD Platform to use Our Services, You must provide Us with your full name, birthday date, nationality, home address, location, government identification number (Identification Card/Passport Number and Date of the Issuance of Identification Card/Passport), telegram username, digital wallet address, email address, IP address, documentation for proof of address and other information as We required which can be used to distinguish your identity, to access the BSCPAD Platform and for the Know Your Customer ("KYC") Verification purpose. Additionally, You will use single sign \u2013 on (also known as "OAuth") by logging in to Our Services using Metamask. These services will authenticate your identity and provide You the option to share certain information with Us such as your username and email address.'), o.a.createElement("p", null, "Furthermore, You will be required to upload facial image data, namely photo images of your face and provide additional information when firstly connecting with BSCPAD such as linking to your Facebook account, Telegram, LinkedIn, GitHub, Google, or Twitter of other social media accounts, and more.")), o.a.createElement("li", null, "Information collected by Us as You use Our services", o.a.createElement("ol", null, o.a.createElement("li", null, "Usage Information", o.a.createElement("p", null, "When You engage or use Our Services, We will monitor your information in relation to your usage of BSCPAD Services through your device such as your IP address, phone number, the type of device You use to access Our Platform, device information, which websites You visited before accessing Our Services or Platform, browser type, Information about your browser, Date and Time You visit Our Platform, Volume of data transmitted and network operator. This information will either be directly obtained by BSCPAD or through third party service providers."), o.a.createElement("p", null, "We collect this type of information to ensure that Our interface and/or Platform is seamlessly accessible for all users around the world, except users in the prohibited jurisdictions.")), o.a.createElement("li", null, "Communication Information", o.a.createElement("p", null, "You hereby agree that We are entitled to collect and use or process the Personal Information You have provided on Our Platform or generated through your usage of BSCPAD Services for the purpose of being able to communicate with You through messages, requests, emails, live chats, file attachments in connection with your transactions on BSCPAD, or any other information related to your contact with BSCPAD. If You contact Us, We will keep a record of the information shared during the correspondence.")), o.a.createElement("li", null, "Financial Information", o.a.createElement("p", null, "You hereby agree that, for the purposes stipulated in this Privacy Policy, We are entitled to collect and use the information contained in or related to your financial information when You use Our services. This includes, without limitation, your transaction history such as your initial cryptocurrency or token amount, your BSCPAD Token amount, your staking instructions, your BEP-20 wallet address etc."), o.a.createElement("p", null, "We collect this financial information to monitor suspicious financial activities to protect You from fraud, resolution of legal cases, as well as any other purposes disclosed in this Privacy Policy."))), o.a.createElement("p", null, 'Parts of BSCPAD Services are public, including any information disclosed on Our social media accounts, thus You acknowledge that such parts of BSCPAD Services may appear on search engines or other publicly available platforms, and may be "crawled", searched and used by the third parties or other Users and Customers of the Services. Please do not post any information that You do not wish to reveal publicly.')))), o.a.createElement("li", null, o.a.createElement("b", null, "How We collect Personal Information"), o.a.createElement("ol", null, o.a.createElement("li", null, "Information automatically collected by Us", o.a.createElement("p", null, "We will collect and process Personal Information automatically provided by You under the following situations."), o.a.createElement("ol", null, o.a.createElement("li", null, "when You visit and/or firstly connect with the Website;"), o.a.createElement("li", null, "when You voluntarily complete any user survey or provide feedback to Us via emails or any other electronic channels including on Our social media accounts;"), o.a.createElement("li", null, "when You use browser cookies or any other relevant software upon visiting the Website; or"), o.a.createElement("li", null, "other situations where We may automatically collect your information as described in this Privacy Policy, Our T&Cs, or other relevant agreements with You."))), o.a.createElement("li", null, "Information collected by the third-party", o.a.createElement("p", null, "We will collect your Personal Information from the third parties as required or permitted to the extent of applicable laws. Information from the third-party sources will include, but will not limited to, public databases, ID verification partners, KYC Verification partners, blockchain data, marketing partners and resellers, advertising partners, and analytics providers.")), o.a.createElement("li", null, "Anonymized and Aggregated Data", o.a.createElement("p", null, "We will also collect other Information in the form of anonymized and aggregate information where all information will be combined and then removed of personally identifiable information, making it unusable for the identification of specific individuals. Aggregated data could be derived from your personal data, but it is not considered as personal data under applicable laws. For example, We may aggregate your usage data to calculate the percentage of users accessing a specific features of BSCPAD Services. However, if We combine or connect aggregated data with your personal data so that it can directly or indirectly identify You, You acknowledge that We treat the combined data as personal data which will be used in accordance with this Privacy Policy."), o.a.createElement("p", null, "We use anonymized or aggregate users' information for the purposes stipulated in this Privacy Policy at any time, including gaining better understanding of users' needs and behaviours, conducting business intelligence and marketing initiatives, and detecting security threats. In this regard, We reserve the right to implement innovative technologies as they become available to be used for strategic planning and operational processes.")))), o.a.createElement("li", null, o.a.createElement("b", null, "How We use Personal Information"), o.a.createElement("p", null, "Your Personal Information will be made available to need-to-know basis to BSCPAD, Our Affiliate, Our Partners and/or within Our group of companies. This will include, but not be limited to, the employees and/or any persons or third parties working for BSCPAD who are responsible for using and protecting your Personal Information."), o.a.createElement("p", null, "We use and process your Personal Information for the following purposes or in the following ways:"), o.a.createElement("ol", null, o.a.createElement("li", null, "To provide Our Services", o.a.createElement("p", null, "We respect data protection principles, and process personal data only for specified, explicit, and legitimate purpose for which such personal data were provided. We primarily use your Personal information, either collected or delivered, in order to enable your use of BSCPAD Services (including, but not limited to, processing transactions), to improve the efficiency of the Services, the process to participate in the IDO fundraising project event, and to verify your identity.")), o.a.createElement("li", null, "To protect users", o.a.createElement("p", null, 'We use the information collected to protect Our Platforms, Users\' information, and archives. We also use IP addresses and cookies to detect suspicious activities and to protect against automated abuse such as spam, phishing, and Distributed Denial of Service ("DDoS") attacks, and other security risks.')), o.a.createElement("li", null, "To comply with regulations and compliance", o.a.createElement("p", null, "For Our legitimate interests, We will use the information in compliance with Our legal obligations, global and local industry standards, and Our AML/KYC/CTF procedures. In the case where it is strictly necessary (i.e., to protect the vital interests of the users or other natural persons, to prevent or mitigate fraud, to fulfil the purpose of public interest, or to pursue Our reasonable interests), We may use and process your Personal Information without obtaining your consent. You hereby expressly authorise BSCPAD to disclose any and all information relating to You in BSCPAD's possession to any law enforcement or government officials upon a valid request.")), o.a.createElement("li", null, "For measurement, research and development purposes-", o.a.createElement("p", null, "We actively measure and analyse your information to understand the way You use and interact with Our Services, and Our Platform, and to provide You with the unique and personalized experience. For example, We allow You to use social media plugins on Our Services (e.g., Telegram, Twitter, etc.), We keep track of your preferences such as display name, time zone, and so on. This review is continuously conducted by Our operation teams to continuously improve Our Platforms' performance and to resolve issues with User experience."), o.a.createElement("p", null, "In addition, We use such information to monitor trends, and improve Our Services, Our administration, the content and layout of the Website, and to develop new Services for You.")), o.a.createElement("li", null, "For communication purposes", o.a.createElement("p", null, "We use your Personal Information, collected or derived from your communication devices or your email address, to interact with You directly, to provide You with necessary support, and/or to keep You informed of wallets connected, transactions, staking instructions, security details, as well as other aspects. All direct communications will be appropriately maintained at BSCPAD, or the service providers designated by BSCPAD, to be reviewed for accuracy, retained as evidence, or used to perform other statutory requirements or other obligations as stipulated in this Privacy Policy and the T&Cs.")), o.a.createElement("li", null, "To enforce Our T&Cs, and other relevant agreements", o.a.createElement("p", null, "Personal Information is also used to enforce Our T&Cs continuously and actively among, and other agreements relating to the Services on BSCPAD Platform . Activities in this regard include, but are not limited to, reviewing, processing, verifying, investigating, mitigating and preventing any potentially prohibited or illegal activities that may violate preceding provisions, or disclose relevant information to third parties in accordance therewith. In light of this, BSCPAD shall be entitled to freeze/close/delete accounts or any User activity on the Website as necessary to any User found to be engaged in any activities that violate Our T&Cs and other relevant agreements.")), o.a.createElement("li", null, "For marketing and advertising", o.a.createElement("p", null, "We will share your Personal Information with Our marketing partners for the purposes of targeting, modelling, and/or identifying analytics as well as marketing and advertising. We may send You marketing communications to alert You about new Services, yet You can opt-out of Our marketing activities at any time.")), o.a.createElement("li", null, "For other purposes", o.a.createElement("p", null, "Provided that we need to process or use your Personal Information for other purposes not stipulated in this Privacy Policy, We will notify or request your consent to use such information. We will not use your Personal Information for purposes other than the purposes stipulated in this Privacy Policy without your prior consent except where it is necessary for our legitimate interests (or for Our Affiliate, Our Partners and/or Our group of companies) and your interests and fundamental rights do not override those interests.")))), o.a.createElement("li", null, o.a.createElement("b", null, "How We protect Personal Information"), o.a.createElement("p", null, "BSCPAD takes reasonable care to protect the BSCPAD's security as well as your Personal Information from loss, misuse, disclosure, alteration, and destruction. We take reasonable steps to maintain physical, technical, and employ procedural safeguard to ensure the confidentiality, integrity of your Personal Information. The safeguards include the use of firewalls, and data encryption, enforcing physical access controls to Our premise and files, and limiting access to Personal Information only to those employees, agents or third parties who need access to that information to process it for Us."), o.a.createElement("p", null, "We also implement certain reasonable security measures to protect your Personal Information from unauthorized access, and such security measures are in compliance with the security practices and procedures as prescribed under the applicable laws."), o.a.createElement("p", null, "However, You agree and acknowledge that it is impossible to fully guarantee the security of your Personal Information by implementing the above-mentioned safeguard and measures. It is not absolute protection to your Personal Information and by accessing the Services."), o.a.createElement("p", null, "You agree that We will not hold any responsibility for the acts committed by those who gain unauthorized access or abuse your information and services. In addition, We will not hold any responsibility for any act committed by the third-party service providers who are contractually engaged with Us to maintain an appropriate security measure for protecting your Personal Information. Thus, You are recommended to understand this responsibility and to independently take safety precautions to protect your Personal Information, particularly your credential information such your BEP-20 wallet address. You hereby agree that We will not be liable for any information leakage and other damage or loss not caused by Our intention or gross negligence, including, but not limited to, hacker attacks, power interruptions, or unavoidable technical failures.")), o.a.createElement("li", null, o.a.createElement("b", null, "How long We retain Personal Information"), o.a.createElement("p", null, "You are aware that your Personal Information will continue to be stored and retained by Us or by a third-party processor engaged by Us for KYC Verification while You have been using or accessing BSCPAD Platform and the Services, and after your use of the Services for a reasonable period of time stipulated under the applicable law."), o.a.createElement("p", null, "In addition, We may be required by applicable laws and regulatory requirements to retain certain information, including your Personal Information, your identification verification materials, information relevant to AML/KYC/CTF procedures, information related to staking instructions, account agreements, and other agreements between Us and third-parties, account statements, and other records after You stop accessing or participating in BSCPAD.")), o.a.createElement("li", null, o.a.createElement("b", null, "Cookies"), o.a.createElement("p", null, "We will use cookies and other technologies or methods of web and analytic tools to gather, store, and analyse certain information related with your access to and activities through the Services, including when You visit the Website."), o.a.createElement("p", null, 'A "cookie" is a small piece of information that a website assigns to your device while You are viewing a website. Cookies are beneficial and may be used for various purposes. These purposes include, among other things, allowing You to navigate between pages efficiently, enabling automatic activation of certain features, remembering your preferences and making the interaction between You and the Services quicker, easier and smoother. Our Website will use the following types of cookies:'), o.a.createElement("ol", null, o.a.createElement("li", null, "Strictly Necessary Cookies", o.a.createElement("p", null, "These cookies are essential to enable You to log in, navigate a website, and use its features or to provide a service requested by You. We will not need to obtain your consent in order to use these cookies.")), o.a.createElement("li", null, "Functionality Cookies", o.a.createElement("p", null, "These cookies allow the website to remember choices You make (such as your username, language, or the region You reside in) and provide enhanced, more personal features. The information these cookies collect remains anonymous, and they cannot track your browsing activity on other websites.")), o.a.createElement("li", null, "Performance cookies", o.a.createElement("p", null, "These cookies collect information about how You use a website, for example, which pages You go to most often, how much time You spend on a page, record difficulties You may experience while using the website such as error messages. All information collected by these cookies is aggregated and therefore anonymous. It is only used to improve the efficiency of the website.")), o.a.createElement("li", null, "Targeting Cookies or Advertising Cookies", o.a.createElement("p", null, "These cookies are used to deliver advertisements tailored to You and your interests specifically. They are also used to limit the number of times You see an advertisement as well as help measure the effectiveness of the advertising campaign. These cookies remember that You have visited a website, and this information is shared with other organizations such as advertisers. Quite often targeting or advertising cookies will be linked to the sites' functionality provided by the other organizations."))), o.a.createElement("p", null, "You may remove these cookies by following the instructions of your device preferences. However, if You choose to disable cookies, some features of BSCPAD Services may not operate properly or become inaccessible, and your online experience may be limited. For Further information please visit our Cookies Policy.")), o.a.createElement("li", null, o.a.createElement("b", null, "Sharing your Personal Information"), o.a.createElement("p", null, "We will not rent, sell, or disclose your Personal Information to any third parties, except to those who require access to the information to perform their tasks and duties under the binding agreements executed with Us and to share with third parties who have a legitimate purpose for accessing it."), o.a.createElement("p", null, "We may share, transfer, disclose, or allow access to your Personal Information to the following third parties for the purposes described below:"), o.a.createElement("ol", null, o.a.createElement("li", null, "We may disclose Personal Information to the third parties in order to administer or process a transaction, or services You have authorized or requested, or in the context of facilitating the execution of a transaction, or We may disclose Personal Information to third parties that provide supporting services, or analytical information for the purpose of the Service improvement, only where we have a lawful basis to do so or under an agreement or legal requirements for the transfer of Personal Information."), o.a.createElement("li", null, "We will be required to verify your identities by applicable laws and regulatory requirements and rely on third-party services to perform these verifications. Personal Information that You provide to Us during the initial connecting process is passed to these services at KYC Verification process and on an ongoing basis thereafter."), o.a.createElement("li", null, "We may disclose or transfer a part of your Personal Information We collect if We are involved in a business transition or any merger and/or acquisition (M&A) projects. In such M&A event, your Personal Information might be among the assets transferred, but it will be protected and secure in accordance with this Privacy Policy."), o.a.createElement("li", null, "We may share your Personal Information with law enforcement, and government officials when We are compelled to do so by a subpoena, a court order to prevent financial loss, to report suspected illegal activity or to investigate violations of any of Our T&Cs or any other applicable policies."), o.a.createElement("li", null, "We may share your Personal Information with third-party processors acting on behalf of BSCPAD or engaged by BSCPAD to process your Personal Information for BSCPAD, Our Affiliate and/or Our Partners.")), o.a.createElement("p", null, "All Affiliate and Third Parties with whom We share your Personal Information have their privacy policies. However, they will be expected to protect this information in a manner that aligns with the provisions described in this Privacy Policy.")), o.a.createElement("li", null, o.a.createElement("b", null, "Third-Party Collection of Personal Information"), o.a.createElement("p", null, "This Privacy Policy only addresses the use and disclosure of the Personal Information We collect from You. To the extent that You disclose your information to other parties through the use of Our Services such as by clicking on a link to any other websites of our partner networks, different rules regarding Privacy Policies may apply to their use or disclosure of the Personal Information You disclose to them."), o.a.createElement("p", null, "You hereby acknowledge that We will not be responsible for the products, services, or descriptions of products or services that You receive from the third-party websites or to the content or privacy practices of the third-party websites. Also, this Privacy Policy will not be applied to any such third-party products and services that You access through BSCPAD Platform. You are knowingly and voluntarily assuming all risks of using third-party websites to purchase products or services, and You agree that We will have no liability whatsoever concerning such third-party websites and your usage of them."), o.a.createElement("p", null, "Your relationship with these third parties and their services and tools is independent of your relationship with Us. These third parties may allow You to permit/restrict the information that is collected. It may be in your interest to individually restrict or enable such data collections.")), o.a.createElement("li", null, o.a.createElement("b", null, "Designated Countries Privacy Right and Your Legal Rights"), o.a.createElement("p", null, "This provision applies to Users of the Services that are located in the EEA, United Kingdom and/or Switzerland (herein collectively referred as", " ", o.a.createElement("b", null, '"Designated Countries"'), ") at the time of Data or Personal Information being collected. We may ask your information regarding your nationality, your location, which country You are in when You use Our Services or Platform, or We may rely on your IP address. We cannot apply this provision to Users who do not provide information about the location or obfuscates location information so as not to appear located in the Designated Countries."), o.a.createElement("p", null, "We use and process your Personal Information based on a valid lawful basis of the GDPR and any equivalent regulations (collectively referred as ", o.a.createElement("b", null, '"Data Protection Laws"'), "). The lawful basis for processing your Personal Information includes (i) your consent, (ii) performance of a contract, (iii) a legitimate interest, (iv) a compliance with legal obligations, (v) protection your vital interest, and (vi) public task."), o.a.createElement("p", null, "In the event of any conflict or inconsistency between any term in this provision and other terms contained in this Privacy Policy, the term in this provision will govern and control over Users in the Designated Countries."), o.a.createElement("p", null, "Under certain circumstances when You use Our Services, You have the rights under the Data Protection Laws in relation to your Personal Information. These rights include the followings:"), o.a.createElement("ol", null, o.a.createElement("li", null, "Right to be informed", o.a.createElement("p", null, "You reserve the right to be informed about the collection, use, and process of your Personal Information.")), o.a.createElement("li", null, "Right of access", o.a.createElement("p", null, "You reserve the right to make a request for a copy of the Personal Information We hold about You and specific information regarding Our processing of this information.")), o.a.createElement("li", null, "Right to rectify", o.a.createElement("p", null, "You reserve the right to request Us to update, correct, or complete your Personal Information that You believe to be outdated, inaccurate, or incomplete. You will rectify at any time by informing Us via our contact channels.")), o.a.createElement("li", null, "Right to Erasure (", o.a.createElement("b", null, '"Right to be Forgotten"'), ")", o.a.createElement("p", null, "You may request to have your Personal Information deleted from Our records where (i) your Personal Information is no longer necessary to be used for the Services or on the Platform, (ii) Personal Information was collected in relation to processing that You previously consented to, but later withdrew such consent, or (iii) your Personal Information was collected in relation to processing activities to which You object, and there are no overriding legitimate grounds for Our processing."), o.a.createElement("p", null, "Please be informed that the Right to be Forgotten mentioned above is not an absolute right. We are compelled to fulfil your request only where the retention of your Personal Information might cause an infraction of the GDPR or applicable law to which We are subject. We shall exercise reasonable efforts in having your Personal Information erased to the extent required by the GDPR or applicable law including in communicating erasure to Our recipients of your Personal Information unless that proves to be impossible or a disproportionate effort.")), o.a.createElement("li", null, "Right to data portability", o.a.createElement("p", null, "You reserve the right to request to transfer a machine-readable copy of your Personal Information to You or the third-party of your choice. We will provide You, or third-party, your Personal Information in a machine-readable format. This right only applies to Personal Information You have consented Us to use.")), o.a.createElement("li", null, "Right to restrict processing", o.a.createElement("p", null, "You may request Us to restrict or suppress the processing of your Personal Information under certain circumstances as follows:"), o.a.createElement("ol", null, o.a.createElement("li", null, "to contests the accuracy of the Personal Information;"), o.a.createElement("li", null, "when the processing is considered unlawful, but You do not wish to have your Personal Information erased;"), o.a.createElement("li", null, "where We no longer need to process your Personal Information, but the information must be retained for the establishment, exercise or defence of legal claims; and"), o.a.createElement("li", null, "where You have objected to Our processing your Personal Information, but We need to determine whether Our legitimate interest overrides your objection."))), o.a.createElement("li", null, "Right to object", o.a.createElement("p", null, "You may object to Our reliance on Our legitimate interests as the basis of Our processing of your Personal Information that impacts your rights. You may also object to Our process of your Personal Information for direct marketing purposes.")), o.a.createElement("li", null, "Right to withdraw consent (", o.a.createElement("b", null, '"Opt-out"'), ")", o.a.createElement("p", null, "You reserve the right to withdraw your consent at any time where We are relying on it to process your Personal Information. Withdrawing your consent does not affect the lawfulness of Our processing of your Personal Information prior to withdrawing."))), o.a.createElement("p", null, "If You wish to exercise these rights as aforementioned, please inform and contact Us via Our Platform, including the Website or send a request to ", o.a.createElement("a", {
                        href: "mailto:support@bscpad.com"
                    }, "support@bscpad.com"), "."), o.a.createElement("p", null, "Please also be noted that there are some limitations when You wish to exercise any one of these individual rights. We may limit your individual rights in the following situations:"), "(i) Where denial of access is required by laws;", o.a.createElement("br", null), "(ii) When granting access would have a negative impact on others' privacy;", o.a.createElement("br", null), "(iii) In order to protect Our rights and properties;", o.a.createElement("br", null), "(iv) Where the request burdensome.", o.a.createElement("br", null), o.a.createElement("br", null)), o.a.createElement("li", null, o.a.createElement("b", null, "Cross Border Transfer of Personal Information"), o.a.createElement("p", null, "As a part of your use of and to ensure better and seamless delivery of the Services to You, We may store, process, analyse, transfer your Personal Information in location globally, including countries other than your home jurisdiction, and/or locations outside the Designated Countries where there may have data protections with less protection than the EU GDPR or the equivalent data protection laws."), o.a.createElement("p", null, "Our Service and Platform contain the transmission of your Personal Information to or to be transferred to or to be processed outside of the country where You are located or outside the Designated Countries, it is not suggestible if your Personal Information is restrictive."), o.a.createElement("p", null, "However, if You wish to continue using Our Services outside the Designated Countries and your home locations, We will ensure that We will transfer your Personal Information only to country that has the required contractual provisions for transferring Personal Information in place with the third parties to which your Information is transferred, or to country where is approved by the EU authorities as providing an adequate level of data protection or enter into legal agreements ensuring an adequate level of data protection in the jurisdiction of the party receiving the information. In this manner, You hereby expressly consent to this transfer, and agree that We will not be responsible for any additional T&Cs, policies or any other guidelines implemented by any party receiving the information.")), o.a.createElement("li", null, o.a.createElement("b", null, "Limitation"), o.a.createElement("ol", null, o.a.createElement("li", null, "Our Services are not designed for the individuals who are under the age of 18 or under the legal age to provide consent under the applicable laws of country or jurisdiction where You are using Our Services or Platform. If You are not over 18 or of the legal age of your country, You will not provide any Personal Information to Us, or to engage in Our services. We reserve the right to access and verify any Personal Information collected from You. If We are aware that You are under 18 or under the legal age who already shared your Personal Information with Us, We will then discard such information and block your access to BSCPAD Platform immediately."), o.a.createElement("li", null, "We cannot guarantee that any losses, misuses, unauthorized accession, or alteration of your Personal Information will not occur. You hereby agree that You play a vital role in protecting your Personal Information, including your credentials."))), o.a.createElement("li", null, o.a.createElement("b", null, "Updates or amendments to the Privacy Policy"), o.a.createElement("p", null, 'We will revise and update this Privacy Policy periodically, at Our sole discretion, and the most current version will be published on the Website or BSCPAD Platform (as reflected in the "Last Revised" heading).'), o.a.createElement("p", null, "In the event of any material change which may affect your usage on Our Services and Platform, We will notify You by means of a prominent notice in advance of such change coming into effect. A prominent notice may include sending through your email address or other communication channels You provide to Us or providing You with an in-application notice such as a banner or pop-up alerting You of the change on the Website. We strongly encourage You to review this Privacy Policy actively. If You do not agree, either partially or wholly, the revised Privacy Policy, You should discontinue accessing or using Our Services. Your continued access to and use of Our Services after any changes to this Privacy Policy constitutes your consent to any changes and agree to continue using the Services."), o.a.createElement("p", null, 'Furthermore, We may provide You with the "just-in-time" disclosures or additional information about Our data collection process, purposes for processing, or other information with respect to collection of your personal information. The purpose of the just-in-time notification is to supplement or clarify Our privacy practice or provide You with additional choices about how We process your personal information.')), o.a.createElement("li", null, o.a.createElement("b", null, "How to contact BSCPAD"), o.a.createElement("p", null, "For any questions regarding this Privacy Policy, your Personal Information collected or proceeded by Us, or in case You would like to exercise one of your legal privacy rights as stipulated in Clause 11, please submit your requests to", " ", o.a.createElement("a", {
                        href: "mailto:support@bscpad.com"
                    }, "support@bscpad.com"), " and visit Our Website at ", o.a.createElement("a", {
                        href: "https://bscpad.com/"
                    }, "https://bscpad.com/"), ".")))))))))
                },
                le = function(e) {
                    return o.a.createElement(o.a.Fragment, null, o.a.createElement("div", {
                        className: "container py-5"
                    }, o.a.createElement("div", {
                        className: "d-flex align-items-start tab-term"
                    }, o.a.createElement("div", {
                        className: "nav nav-pills-policy flex-column nav-pills me-4",
                        id: "v-pills-tab",
                        role: "tablist",
                        "aria-orientation": "vertical"
                    }, o.a.createElement(V.a, {
                        to: w,
                        className: "nav-link text-start active",
                        id: "v-pills-terms-tab"
                    }, "Terms of Use "), o.a.createElement(V.a, {
                        to: T,
                        className: "nav-link text-start",
                        id: "v-pills-privacy-policy-tab"
                    }, "Privacy Policy"), o.a.createElement(V.a, {
                        to: S,
                        className: "nav-link text-start",
                        id: "v-pills-cookies-policy-tab"
                    }, "Cookies Policy"), o.a.createElement(V.a, {
                        to: N,
                        className: "nav-link text-start",
                        id: "v-pills-staking-policy-tab"
                    }, "Staking Policy"), o.a.createElement(V.a, {
                        to: k,
                        className: "nav-link text-start",
                        id: "v-pills-clickwrap-acceptance-tab"
                    }, "Clickwrap Acceptance")), o.a.createElement("div", {
                        className: "tab-content",
                        id: "v-pills-policy-tabContent"
                    }, o.a.createElement("div", {
                        className: "tab-pane fade show active",
                        id: "v-pills-cookies-policy",
                        role: "tabpanel",
                        "aria-labelledby": "v-pills-cookies-policy-tab"
                    }, o.a.createElement(o.a.Fragment, null, o.a.createElement("div", {
                        className: "text-center mb-3"
                    }, o.a.createElement("p", null, o.a.createElement("strong", null, "BSCP DIGITAL LIMITED")), o.a.createElement("p", null, o.a.createElement("strong", null, "Terms and Conditions of ", o.a.createElement("a", {
                        href: "https://bscpad.com/",
                        target: "_blank"
                    }, "https://bscpad.com/")), o.a.createElement("br", null), o.a.createElement("small", null, "Last revised Date: 14", o.a.createElement("sup", null, "th"), " September 2021"))), o.a.createElement(o.a.Fragment, null, o.a.createElement("ol", null, o.a.createElement("li", null, o.a.createElement("b", null, "Introduction"), o.a.createElement("p", null, "These Terms and Conditions (herein referred to as ", o.a.createElement("b", null, '"Terms"'), ") govern the use and the conditions of", " ", o.a.createElement("a", {
                        href: "https://bscpad.com/"
                    }, "https://bscpad.com/"), " (herein referred as ", o.a.createElement("b", null, '"Website"'), "), and the Services provided by BSCPAD DIGITAL Limited (herein referred to as ", o.a.createElement("b", null, '"Company"'), " or ", o.a.createElement("b", null, '"We"'), " or", " ", o.a.createElement("b", null, '"Us"'), "), a company incorporated and registered under the laws of British Virgin Islands. These Terms constitute a binding and enforceable legal contract between the Company and its Affiliate and subsidiaries worldwide and you, an end user of the Services (herein referred to as", " ", o.a.createElement("b", null, '"You"'), " or ", o.a.createElement("b", null, '"User"'), ") in relation to the Services. You and the Company are referred to separately as ", o.a.createElement("b", null, '"Party"'), " and collectively as", " ", o.a.createElement("b", null, '"Parties"'), "."), o.a.createElement("p", null, "By accessing, registering, using, or clicking on the Services, and information made available by the Company via the Website, you hereby accept and agree to all the Terms set forth herein."), o.a.createElement("p", null, "You are strongly advised to carefully read these Terms as well as the provisions detailed in our Privacy Policy prior to using the Website and our Services. By using the Website and the Services in any capacity, you agree that: (i) You have read and familiarized yourself with these Terms; (ii) You understand these Terms; and (iii) You agree to be bound by these Terms when using the Website. If You do not agree to these Terms, please do not access or use the Website and the Services."), o.a.createElement("p", null, "We reserve the right to modify or amend these Terms, the Website, or any content on either one of the platforms from time to time, including for security, legal, or regulatory reasons, as well as to reflect updates or changes to the services or functionality of the Website. You are advised to check these Terms periodically to ensure that you are cognizant of the current versions and comply with them. Users of the Website and the Services are bound by these changes which will take immediate effect after the revised versions of these Terms have been published on the Website or the relevant mobile application. Through your continued use of or interaction with the Website, the Services, tools, and information made available on these platforms, you hereby agree to be bound by the provisions highlighted in the subsequent versions."), o.a.createElement("p", null, "We will provide a notification on the Website specifying that changes have been made to these Terms whenever they occur. By accepting the notification, you accept that we have provided you with sufficient notice of any changes. You should seek professional advice regarding any possible legal requirements you must comply with in relation to the use of the Website, the Service or the relevant tools provided by the Company or the Partners.")), o.a.createElement("li", null, o.a.createElement("b", null, "Definitions"), o.a.createElement("p", null, o.a.createElement("b", null, '"ADAPAD"'), " refers to the platform for Cardano Smart Chain Network, which is a platform for retail investment into tokens offered via IDO. Please find further details at", " ", o.a.createElement("a", {
                        href: "https://adapad.io/"
                    }, "https://adapad.io/")), o.a.createElement("p", null, o.a.createElement("b", null, '"Affiliate"'), " refers to in relation in any party, any other company which, directly or indirectly, (i) is controlled by that party, (ii) controls that party, or (iii) is under common control with that party, and in respect of the Company, shall also include any fund, limited partnership or other collective investment vehicle or other person which is managed or advised by the Company's team."), o.a.createElement("p", null, o.a.createElement("b", null, '"AML"'), " refers to anti-money laundering."), o.a.createElement("p", null, o.a.createElement("b", null, '"Allocation Round"'), " refers to Round 1 of the Company fundraising project tokens allocation, which will be managed by the BSCPad tiered system."), o.a.createElement("p", null, o.a.createElement("b", null, '"Applicable Laws"'), " refers to acts, statutes, regulations, ordinances, treaties, guidelines, and policies issued by governmental organizations or regulatory bodies, including, but not limited to, the governing law stipulated under Laws of the British Virgin Islands."), o.a.createElement("p", null, o.a.createElement("b", null, '"Bridge Service"'), " as defined in Clause 6.1."), o.a.createElement("p", null, o.a.createElement("b", null, '"BSCPAD Platform"'), " refers to the Company's Website, or platform that facilitates token swaps, and where the Company's Project is officially launched, and makes available its native Tokens (", o.a.createElement("b", null, '"Pool"'), ") to be distributed to the Company's user in the allocation rounds in order to be swapped for other crypto assets."), o.a.createElement("p", null, o.a.createElement("b", null, '"BSCPAD Token"'), " refers to a blockchain - based token which is issued, stored, transferred, transacted on the Binance Smart Chain Network. Users need to hold BSCPAD Token to participate in any Services on the Platform including Staking or pre-sale of Project selected for the launchpad."), o.a.createElement("p", null, o.a.createElement("b", null, '"BNB"'), " refers to Binance Cryptocurrency which is required to pay transaction fees on the Binance Smart Chain network."), o.a.createElement("p", null, o.a.createElement("b", null, '"BRIDGE"'), " refers to the service provided by the Company and its Affiliate in Clause 6."), o.a.createElement("p", null, o.a.createElement("b", null, '"BUSD"'), " refers to a stable coin issued for the Binance ecosystem and backed by the U.S. Dollar having a pegged value at 1 BUSD = $1.00 USD."), o.a.createElement("p", null, o.a.createElement("b", null, '"CFT"'), " refers to Combating the Financing of Terrorism."), o.a.createElement("p", null, o.a.createElement("b", null, '"Confidential Information"'), " refers to any non-public, proprietary information or documents of or related to the User or the Company (whether in writing, orally or by any other means) by or on behalf of the User to the Company and which if disclose in tangible or intangible form is marked confidential (including in visual, oral, or electronic form) relating to Us or any other User that was previously a User, which is provided or disclosed through the Company (or to any employees or agents) in connection with the use or participate in the services."), o.a.createElement("p", null, o.a.createElement("b", null, '"Content"'), " refers to all content generated by the Company, including logos, identifying marks, images, illustrations, designs, icons, photographs, videos, text, any written or multimedia materials, services, advertisements, software, code, data, files, archives, folders, or available downloads on the BSCPAD Platform."), o.a.createElement("p", null, o.a.createElement("b", null, '"Cookie"'), " refer to the small text files that are placed on your computer by the Website that you visit. They are widely used in order to make Websites work, or work more efficiently, as well as to provide information to the owner of the site."), o.a.createElement("p", null, o.a.createElement("b", null, '"CrossSwap"'), " refers to the cross chain swap designed to unify the trading service on one platform. Please find further details at", " ", o.a.createElement("a", {
                        href: "https://crossswap.com/",
                        target: "_blank"
                    }, "https://crossswap.com/"), "."), o.a.createElement("p", null, o.a.createElement("b", null, '"CrossWallet"'), " refers to the non-custodian wallet service that holds any digital asset you prefer to hold, trade, or send, from tokens to NFTs, which it works seamlessly move between different blockchain and works on any device, either mobile or web. Please find further details at", " ", o.a.createElement("a", {
                        href: "https://crosswallet.app/",
                        target: "_blank"
                    }, "https://crosswallet.app/"), "."), o.a.createElement("p", null, o.a.createElement("b", null, '"ETHPAD"'), " refers to the platform for Ethereum Smart Chain Network, which is a platform for retail investment into tokens offered via IDO. Please find further details at", " ", o.a.createElement("a", {
                        href: "https://ethpad.network/",
                        target: "_blank"
                    }, "https://ethpad.network/"), "."), o.a.createElement("p", null, o.a.createElement("b", null, '"FCFS Round"'), " refers to First Come First Serve Round or Round 2 of the BRCPAD fundraising project token allocation for the unsold IDO project tokens left from the Allocation Round."), o.a.createElement("p", null, o.a.createElement("b", null, '"IDO"'), " refers to Initial DEX Offerings or Initial Decentralized Exchange Offerings."), o.a.createElement("p", null, o.a.createElement("b", null, '"KCCPAD"'), " refers to the platform for KuCoin Community Chain Network, which is a platform for retail investment into tokens offered via IDO. Please find further details at", " ", o.a.createElement("a", {
                        href: "https://kccpad.io/",
                        target: "_blank"
                    }, "https://kccpad.io/"), "."), o.a.createElement("p", null, o.a.createElement("b", null, '"KCCSwap"'), " refers to the decentralized exchange service for instantly swap token, crypto token, utility token with no requirement of account registration and the service provider does not hold your funds when you participate in the swap service, you have 100% ownership of your crypto. Please find further details at", " ", o.a.createElement("a", {
                        href: "https://kccswap.io/",
                        target: "_blank"
                    }, "https://kccswap.io/"), "."), o.a.createElement("p", null, o.a.createElement("b", null, '"Partners"'), " refers to the Company, ETHPAD, KCCPAD, TRONPAD, ADAPAD, NFTLaunch, CrossWallet, CrossSwap, KCCSwap, and WagyuSwap."), o.a.createElement("p", null, o.a.createElement("b", null, '"Prohibited Jurisdictions"'), " specifically refer to the United States of America (including its territories, and dependencies, and any state of the United States), Albania, Barbados, Botswana, Burkina Faso, Cambodia, Democratic People's Republic of Korea, Haiti, Iran, Jamaica, Morocco, Myanmar (Burma), Nicaragua, Pakistan, Panama, Philippines, Senegal, South Sudan, Syria, Thailand, Uganda, and Yemen, Zimbabwe."), o.a.createElement("p", null, o.a.createElement("b", null, '"Project"'), " refers to the Company\u2019s project being launched for Initial Decentralized Offering (\u2018IDO\u2019) event on BSCPAD Platform."), o.a.createElement("p", null, o.a.createElement("b", null, '"Services"'), " refer to the services provided to the Users through the Website, which include the accessibility to the new IDO token offered from each IDO fundraising project, staking service and other relevant services available through the Platform and all free trials and beta services made available by the Company, which may be subject to periodic revision."), o.a.createElement("p", null, o.a.createElement("b", null, '"Staking or Stake"'), " refers to the staking or deposit service in which the Users can delegate or deposit the User\u2019s BSCPAD Token in exchange for a share of Net Staking Rewards on the Platform."), o.a.createElement("p", null, o.a.createElement("b", null, '"TRONPAD"'), " refers to the platform for Tron Smart Chain Network, which is a platform for retail investment into tokens offered via IDO. Please find further details at", " ", o.a.createElement("a", {
                        href: "https://tronpad.network/",
                        target: "_blank"
                    }, "https://tronpad.network/"), "."), o.a.createElement("p", null, o.a.createElement("b", null, '"NFTLaunch"'), " refers to the platform for deflationary NFT Launchpad which is the first platform to offer zero gas wars, fair distribution and free NFT airdrops of new and upcoming NFT projetcs. Please find further details at", " ", o.a.createElement("a", {
                        href: "https://nftlaunch.network/",
                        target: "_blank"
                    }, "https://nftlaunch.network/"), "."), o.a.createElement("p", null, o.a.createElement("b", null, '"WagyuSwap"'), " refers to the Decentralized Exchange build on Velas Blockchain, an entirely new blockchain adapted from Solana which guaranteed full EVM compatibility. Please find further details at", " ", o.a.createElement("a", {
                        href: "https://wagyuswap.app/",
                        target: "_blank"
                    }, "https://wagyuswap.app/"), "."), o.a.createElement("p", null, o.a.createElement("b", null, '"Wallet(s)"'), " refers to a BEP-20 wallet which must be compatible with the Binance Smart Chain Network, such as MetaMask or Trust wallet.")), o.a.createElement("li", null, o.a.createElement("b", null, "General Provisions"), o.a.createElement("ol", null, o.a.createElement("li", null, "Contractual Relationship", o.a.createElement("p", null, "These Terms constitute a valid and binding agreement between You and the Company. The binding obligations stipulated in these Terms are enforceable.")), o.a.createElement("li", null, "Revision and Amendments", o.a.createElement("p", null, "The Company reserves the right to revise, amend, or update any clauses and provisions stipulated in these Terms in its sole discretion at any time. The Company will notify the revision or amendment of such clauses or provisions by updating these Terms and specify the 'Last Revised Date' displayed on a page of Terms and Conditions. Any revisions and updates on these Terms will be automatically effective upon their publication on the Platform, which includes the Website. Therefore, your continuity of accessing or using the BSCPAD Platform, and/or Services will be deemed that you agree to have read, understood, and accepted all revised terms and provisions. If you do not agree on any revised or updated terms and provisions, you should immediately stop accessing the Website or using our the Services. You are encouraged to frequently and carefully review these Terms to ensure that you understand these Terms.")), o.a.createElement("li", null, "Privacy Policy", o.a.createElement("p", null, "You acknowledge and confirm that you have read, understood, and agreed to provisions stipulated in the Website's Privacy Policy, which will explain how the Company treats your information and protects your privacy when accessing or using the BSCPAD Platform."), o.a.createElement("p", null, "By using BSCPAD Platform, you hereby agree that the Company may collect, use your information, and anonymised data pertaining to your use of the Services for analytics, trends' identification, and purpose of statistics to further enhance the effectiveness and efficiency of the Services."), o.a.createElement("p", null, "You hereby expressly authorise the Company to disclose any and all information relating to you in the Company's possession to any law enforcement or government officials upon the request by the court order.")), o.a.createElement("li", null, "Links to and from the Website", o.a.createElement("ol", null, o.a.createElement("li", null, 'You may, through hypertext or other computer links, gain access form the Website to websites operated or made available, or otherwise licensed by persons other than us ("Third Party Services"). Such hyperlinks are provided for your convenience.'), o.a.createElement("li", null, "A link from Third Party Services does not mean that the Company endorses or approves the content on such website or does not mean that the Company is an operator of that website. You understand that you are solely responsible for determining the extent to which you may use or rely upon any content at any other Third Party Services websites which you have accessed from the Website. the Company has no control over the content of these sites or resources and accept no reasonability for them or for any loss or damage that may arise from your use of them."), o.a.createElement("li", null, "The Company assumes no responsibility for the use of, or inability to use, any Third Party Services' software, other materials, or contents posted and/or uploaded on such website and we will have no liability whatsoever to any person or entity for any inaccuracy or incompleteness of such third-party content. All intellectual property rights in and to Third Party Services are property of the respective third parties."))), o.a.createElement("li", null, "Disclaimer for Accessibility of the Website and the Services", o.a.createElement("ol", null, o.a.createElement("li", null, "The Website merely facilitates the Users accessibility to the Project tokens and does not provide you with any warranty or representation whatsoever regarding its quality, value, specification, fitness for the purpose, completeness or accuracy of its technology or infrastructure of the tokens."), o.a.createElement("li", null, "The Company will make all commercially reasonable attempts to facilitate information about the Project on the BSCPAD Platform. However, you hereby acknowledge that the Company does not guarantee the accuracy, timeliness, or completeness of such information, and does not provide any warranty in connection with your use or reliance on such information. You agree that your use of the Project information will be at all your own risk. The Company will not be liable to you in any manner for the termination, interruption, delay, or inaccuracy of any Project information launched on the BCPAD Platform."), o.a.createElement("li", null, "To the extent permitted by applicable laws, the Website and the Company\u2019s Services are provided on an \u2018AS IS\u2019 and \u2018AS AVAILABLE\u2019 basis. the Company does not warrant that the features, and functions contained in the Website and the Services will satisfy your preferences You hereby agree and acknowledge that your access and use of the Website and the Services are at your own risk, and you will be liable for any responsibility, consequences that may arise out of or in connection with the usage or accessibility of the Website and the Services. You expressly agree that the Company will have absolutely no liability in this regard."), o.a.createElement("li", null, "You hereby agree and acknowledge that the Website may contain links to a third-party website or services that are not owned or even controlled by the Company, thus the Company will hold no responsibility for the content or services, goods, or activities provided by such third-party website. You further agree that the Company has no liability directly or indirectly for any damage, loss, or consequence arising out of or in connection with the usage or reliance of any content, material, services available through the third-party website."), o.a.createElement("li", null, "The Company reserves the right to limit the availability of the Website to any person, geographic area, or jurisdiction we so desire and/or terminate your access to and use of the Website and the Services, at any time and in our sole discretion."), o.a.createElement("li", null, "The Company may, at our sole discretion, impose limits or restrictions on the use you make of the Website. Further, for commercial, security, technical, maintenance, legal or regulatory reasons, or due to any breach of these Terms, we may withdraw the Website or your access to the Website and the Services at any time and without notice to You."))), o.a.createElement("li", null, "Information", o.a.createElement("p", null, "You acknowledge that you are solely responsible for any submissions of all contents, remarks, suggestions, ideas, materials, feedbacks, or other information, including bug reports in relation to the Services provided through the Website including any submission to our social media platforms such as Twitter and Telegram, and you, not us, have full responsibility for such submissions, including their accuracy, legality, reliability, appropriateness, originality, and copyright. We shall reply on the information you have provided and will not verify it. Notwithstanding the foregoing, we have the right to refuse to post, remove, edit, or abridge any submission for any reason and to freely use, copy, disclose, publish, display, or exploit such submission as we deem necessary without any payment of royalty, acknowledgement prior to consent, we may retain copies of all information materials relevant to the Service.")))), o.a.createElement("li", null, o.a.createElement("b", null, "Intellectual Property"), o.a.createElement("ol", null, o.a.createElement("li", null, "All present and future copyright, title, interests in and to the Services, registered and unregistered trademarks, design rights, unregistered designs, database rights and all other present and future intellectual property rights and rights in the nature of intellectual property rights that exist in or in relation to the use and access of the Website and Services are owned by or otherwise licensed to the Company. Subject to your compliance with these Terms, the Company grants you a non-exclusive, non-sub license, and any limited license to merely use or access the Website and the Services in the permitted hereunder."), o.a.createElement("li", null, "Except as expressly stated in these Terms, nothing in these Terms should be construed as conferring any right in or license to BSCPAD\u2019s or any other third party\u2019s intellectual rights."), o.a.createElement("li", null, "If and to the extent that any such intellectual property rights are vested in you by operation of law or otherwise, you agree to do any and all such acts and execute any and all such documents as we may reasonably request in order to assign such intellectual property rights back to us."), o.a.createElement("li", null, "You agree and acknowledge that all Website content must not be copied or reproduced, modified, redistributed, used, created for derivative works, or otherwise dealt with for any other reason without being granted a written consent from the Company."), o.a.createElement("li", null, "Third parties participating on the Website may permit the Company to utilise trademarks, copyrighted material, and other Intellectual Property associated with their businesses. The Company will not warrant or represent that the content of the Website does not infringe the rights of any third party."))), o.a.createElement("li", null, o.a.createElement("b", null, "Participation in the BSCPAD Services"), o.a.createElement("ol", null, o.a.createElement("li", null, "In order to avail access to the Services or participate in the BSCPAD Platform, you may be required to go through KYC/AML/CFT process as requested by each IDO fundraising project. Please refer to the Identification Verification through KYC/AML/CFT/AML Process in Clause 7 for further information."), o.a.createElement("li", null, "In term of Staking, you acknowledge and agree that BACPAD provides Staking service to Users for the purposes of delegating the User\u2019s BSCPAD Token in exchange for a share of Net staking rewards. You will provide the staking instruction to the Company. Once the staking instruction is received, the system will record the instruction and you will not be able to cancel or edit the staking instruction. When the BSCPAD Platform connect with your Wallet, you will see your tier based on the numbers of BSCPAD Token held in your Wallet. The level of tier will affect the numbers of IDO tokens that you will receive, and the Company has neither responsibility nor liability in relation to the allocation of IDO tokens. Since it will be entirely subject to the IDO fundraising project creator."), o.a.createElement("p", null, "BACPAD reserves the right to reject your participation in Staking, if you fail to fulfil to satisfy the identity verification requirements through the KYC/AML/CFT process or commit any other suspicious activity while participating in the Services provided by the Company."), o.a.createElement("li", null, "Tokens being stacked are limited to BSCPAD Token only. Once you initiate staking, you will be put in the each Allocation Round of IDO fundraising project tokens event. The IDO tokens will be distributed to you based on the level of the tier you are classified. In the conclusion of the Allocation Round of IDO, you will be able to join the FCFS Round for purchasing the unsold IDO tokens.", o.a.createElement("p", null, "You hereby acknowledge and agree that the estimated IDO tokens or reward yield displayed on the BSCPAD Platform for each IDO fundraising project is an estimation. The actual amount of IDO tokens reward you will receive may not match or may lower than your estimation which will be subject to the reward compression or expression. You further hereby acknowledge that the Company cannot promise or guarantee the certain amount of the reward receiving from staking your BSCPAD Tokens in order to engage in the IDO fundraising project event. You shall to go through, and study the medium article of each IDO fundraising project and fully understand the significant information and conditions prior to participate such IDO event such as the allocation date, the underlying technology, the features and functions of IDO project tokens.")), o.a.createElement("li", null, "In the event that you wish to unstake/withdraw your BSCPAD Token and gain the reward, you will provide the unstaking instruction to the BSCPAD Platform. You acknowledge and agree that when you unstake your BSCPAD Token, the delivery of such BSCPAD Token into your wallet will take 7 days and the timing may vary based on time of day of the unstake/withdraw instruction and execution. The amount of your unstaking BSCPAD Token will not count towards your tier level for upcoming IDO fundraising projects.", o.a.createElement("p", null, "The Company will levy a withdrawing fee or minimum transaction in the form of BNB amount, which will vary and be subject to the amendment only at its sole discretion of the Company periodically. The Company will not be liable for any loss caused or alleged caused by timing differences and economic lost associated with the actual delivery of the BSCPAD Token.")), o.a.createElement("li", null, "The Company reserves the right to amend any terms related to any specific Staking program at any time in its sole discretion. The Company will not be liable for any losses due to your misunderstanding of the Staking program terms and changes to such term's rules."))), o.a.createElement("li", null, o.a.createElement("b", null, "Bridge Service"), o.a.createElement("ol", null, o.a.createElement("li", null, "Upon completion of the registration and identity verification for your Wallet, You may use services made available by the Partners, including but not limited to, staking, and accessing to other information released by the Company, participating in any launchpad, token swaps, bridge, etc., in accordance with the provision of the bridge function (", o.a.createElement("b", null, '"Bridge Service"'), ").", o.a.createElement("p", null, "Under the bridge function, You will be required to conduct the following provisions for the purpose of double verification and convenience crossing between two platforms:"), "\u2014 Connect your Wallet (by clicking the button shown on the Website) with our Partner's service; and", o.a.createElement("br", null), "\u2014 Synchronize the Company KYC/AML/CFT with our Partners;", o.a.createElement("p", null, "You hereby acknowledge and agree that the Company will not be liable for any damage, loss, consequence, or devaluation of the assets held in any of your Wallet under the provision of Partner's service, which may occur as a result or in connection with any matter related to disruptive function, broken internet system or any failure.")), o.a.createElement("li", null, "In term of KYC/AML/CFT synchronize, you understand and acknowledge that you agree to share your KYC/AML/CFT information among our Partners for the purpose of identity verification through KYC/AML/CFT process. Therefore, you hereby agree that when you use the Company\u2019s synchronize service, you will inform the Company for any KYC/AML/CFT information changed (if any)."), o.a.createElement("li", null, "Upon sending an instruction of the Company\u2019s service for KYC/AML/CFT synchronize, your account will be immediately updated to reflect the KYC/AML/CFT profile, and your KYC/AML/CFT profile will be included in our Partners\u2019 data to match the identity verification through KYC/AML/CFT requirement. Once the instruction is executed, your account will be updated to reflect that the instruction has been fully match and passed the KYC/AML/CFT verification and you are ready to experience the Company\u2019s service. The instruction will remain uncompleted until it is fully filled with the Wallet address. To provide a Wallet address, you authorized our Partners to confirm and temporarily control the data transfer to the Company."), o.a.createElement("li", null, "You are only allowed one time to synchronize KYC/AML/CFT to any launchpad provided by Partners. Double check the address input in the box, whether it is the address showing in your Wallet. If you need to synchronize again or update any information, please contact the Company\u2019s supporting team, details provided in Clause 16."), o.a.createElement("li", null, "Unless otherwise specified by the Company, to use the Bridge Service, you must complete the identification verification through KYC/AML/CFT process or passed the KYC/AML/CFT synchronized from any Partners for the BSCPad\u2019s account. You acknowledge and agree that:", o.a.createElement("br", null), o.a.createElement("br", null), "a. you fully understand the swapping process, including but not limited to the risk or major fluctuation of digital asset in swapping, and the risk of exacerbated adverse outcome when leverage is used;", o.a.createElement("br", null), "b. you have sufficient technological knowledge and experience and the capacity to understand the process and agree to independently assume all the risks arising from the Bridge Service; and", o.a.createElement("br", null), "c. you agree and authorize the Company to take various reasonable measures at its discretion (including but not limited to blocking or freezing the swapping requests under specific circumstances) in accordance with the Company's decision to protect the legitimate interests of you, the Company itself and other users."), o.a.createElement("li", null, "Prior to conducting the Bridge Service for swap your asset, in accordance with type of asset swapping, you shall provide the amount for swapping that shall comply with the daily limit (show on the BRIDGE page). Unless otherwise specified by the Company, to use Bridge Service, You agree to keep enough asset in your Wallet, as required by engaging in the swapping process. Failure to keep enough assets may result in cancellation of the swapping request."))), o.a.createElement("li", null, o.a.createElement("b", null, "Identity Verification through KYC/AML/CFT Process"), o.a.createElement("ol", null, o.a.createElement("li", null, "As a software development company, the Company has no role in enforcing KYC/AML/CFT by default, however, the Company has a mandatory requirement for KYC/AML/CFT identification verification tools for the IDO fundraising companies using the Company to enforce on their users. The Company is implementing KYC/AML/CFT tools into the Company\u2019s launchpad through", " ", o.a.createElement("a", {
                        href: "https://kycaid.com/",
                        target: "_blank"
                    }, "https://kycaid.com/"), "."), o.a.createElement("li", null, "The use of KYC/AML/CFT tools on the Company by IDO fundraising companies using the Services on BSCPAD Platform is not the discretion of said entitles, and they must require You to complete KYC/AML/CFT verification process before participating in any Projects."), o.a.createElement("li", null, "Although the Company makes no warranty as to the merit, legality, or juridical nature of any IDO token, we nonetheless understand the need of the Project to require KYC/AML/CFT verification on their token sale participants of Users. Therefore, the Company reserves the right:", o.a.createElement("ol", null, o.a.createElement("li", null, "at any time, to ask for your personal information, Name-Surname, Birthday,-e- mail address, nationality, location, government identification number (Identification Card/Passport number and Date of Identification Card/Passport issuing), telegram username, BSCPad\u2019s Wallet address, and any KYC/AML/CFT documentation with the liveness test that it deems necessary to determine the identity and location of a User, and reserves the right to restrict Service and payment until the User\u2019s identity is sufficiently determined;"), o.a.createElement("li", null, "The liveness test shall require you to take a photo of your government identification with your phone or camera. and then take a photo of (i.e., a selfie of your face) holding your ID document and a piece of paper you wrote on next to your face (not covering your face), in which you shall write down the (1) BSCPad, (2) the current date, and (3) the last 4 characters of your Wallet address\u201d. If you have any questions, please find detail about KYC/AML/CFT process here:", " ", o.a.createElement("a", {
                        href: "https://bscpad.medium.com/bscpad-kyc-process-16e6a5557138",
                        target: "_blank"
                    }, "https://bscpad.medium.com/bscpad-kyc-process-16e6a5557138"), "."), o.a.createElement("li", null, "to share the submitted KYC/AML/CFT information and documentation to the third parties to verify the authenticity of the submitted information, and the end user (you) giving the consent to share such information by using the Services; and"), o.a.createElement("li", null, "to reject the use of the Services that the Company has the reasonable ground to believe that they are found to be in violation of relevant and applicable AML/CFT laws and regulations, and to cooperate with the competent authorities or any investigation when and if necessary upon the valid request by the court order."))), o.a.createElement("li", null, 'The Company expressly prohibits and rejects the use of the Service for any form of illicit activity, including money laundering, terrorist financing or trade sanctions violations, consistent with various jurisdictions\' laws, regulations and norms. To that end, the Services are not offered to individuals or entities on any Politically Exposed Persons ("PEP") lists, or subject to any United States, European Union, or other global sanctions or watch lists. By using the Services, you represent that you are not on any of such lists.'), o.a.createElement("li", null, "You fully acknowledge that your information and KYC/AML/CFT documentation may be disclosed to government agencies or regulators upon a valid request of the court order. Once you have decided to participate in any Project and start staking your BSCPAD Token, you must ensure that all information provided to the Company is complete, accurate, and updated in a timely manner. The Company will rely on the information you provided and should there be any reasonable grounds for the Company to believe that the partial or the whole of your information provided to us is incomplete, or incorrect, or outdated, the Company reserves the right to send you a notice to demand correction, or to delete such information directly, and, as the case may be, to disable you to access to all or part of the Website and the Services."), o.a.createElement("li", null, "If the Company has a reasonable ground to believe that any User transacts or use the Services by using digital currencies derived from any suspicious illegal activities, the Company shall be entitled to freeze, close, or delete the User\u2019s accounts as necessary. The Company will hold no liability to such users for any damage, or loss arising out of or in connection with this manner herein. Please note that any attempt to circumvent the Company\u2019s measures set out in this Clause 7 will also result in a similar action."))), o.a.createElement("li", null, o.a.createElement("b", null, "BSCPAD Tokens"), o.a.createElement("ol", null, o.a.createElement("li", null, "The Company will issue a blockchain-based token called \u201cBSCPAD Token\u201d on Binance Smart Chain Network. BSCPAD Token is classified as the utility token designed to be used solely on the BSCPAD Platform or on", " ", o.a.createElement("a", {
                        href: "https://bscpad.com/"
                    }, "https://bscpad.com/"), " Website."), o.a.createElement("li", null, "Users who stake BSCPAD Token in their Wallets will be eligible to participate in a Project."), o.a.createElement("li", null, "BSCPAD Token is not considered as security of any kind, and it also does not carry any right to vote, manage or the right of ownership in the BSCPAD Platform."), o.a.createElement("li", null, "BSCPAD Token is neither money nor legal tender/currency, whether fiat or otherwise, and it does not carry any value whether it is intrinsic or assigned."))), o.a.createElement("li", null, o.a.createElement("b", null, "Misuse of the Website"), o.a.createElement("ol", null, o.a.createElement("li", null, "In the event of any misuse and/or abuse of the Website or breach any provision in these Terms, the Company reserves the right to block your access to the Website and other Services until the matter is solved."), o.a.createElement("li", null, "Use of the Website for transmission, publication or storage of any material on or via the Website which is in violation of any applicable laws or regulations or any third-party's rights is strictly prohibited, including but not limited to the use of the Website or the transmission, distribution, publication or storage any material on or via the Website in a matter or for the purpose which infringes copyright, trademark, trade secret or other intellectual property rights, is obscene or harmful to minors or constitutes an illegal act or harassment, is libellous or defamatory, violates any privacy or data protections laws, is fraudulent or breaches any exchange control laws."))), o.a.createElement("li", null, o.a.createElement("b", null, "BSCPAD Services Representations and Warranties"), o.a.createElement("ol", null, o.a.createElement("li", null, "Representations and Warranties You hereby agree to make the following representations and warranties by accessing to the Website and/or using the Services:", o.a.createElement("ol", null, o.a.createElement("li", null, "You have full capacity and authority under the applicable laws to agree and bind yourself to these Terms."), o.a.createElement("li", null, "You are eighteen years of age or older."), o.a.createElement("li", null, "You are not a citizen or a resident of the Prohibited Jurisdictions, and you do not have any relevant connection with any of the Prohibited Jurisdictions."), o.a.createElement("li", null, "You are aware and agree to comply with all applicable domestic and international laws, statutes, ordinances, and regulations applicable to your use of the Website and the Services. Your use of the Website and the Services are not for any unlawful or illegal purposes, including but not limited to the usage against the copyright laws and, AML/CFT laws."), o.a.createElement("li", null, "You are the exclusive owner of BSCPAD Token and your other cryptocurrencies, including BNB held in your Wallet. The tokens maintained in your Wallets are not and will not be derived from money laundering, terrorist financing, fraud, or any other illegal activities under any applicable laws. You further hereby acknowledge and agree that the Company will not be responsible for actions taken by you that result in the loss or destruction of the value of the tokens and rewards you hold in the Wallet."), o.a.createElement("li", null, "You validly undertake any action or enter into any transaction with regard to these Terms. You are solely responsible for the use of the Website and the Services for all activities, or transactions that occur on or through your User account on BCPAD."), o.a.createElement("li", null, "You will provide only accurate, complete, and up-to-date information and documents, if any, for the purposes of accessing or using or participating the Company\u2019s Services on the BSCPAD Platform. You will further agree to put your effort to ensure that the confidentiality of your personal or credential information, including your wallet address is restricted, and safely maintained to your device you use to access the Website."), o.a.createElement("li", null, "You acknowledged and agree that if you lose access to the Wallet that you connected with BSCPAD Platform, the Company will not be able to help you recover the loss, or transfer of IDO tokens or any BSCPAD Token back to your wallet. It will be your solely responsibility to manage your BSCPad\u2019s account, and the private key."), o.a.createElement("li", null, "You will be responsible for obtaining the data network access necessary to use the Website. Your network's data and rates and fees may apply if you access or use the Website from a wireless-enabled device, and you will be responsible for such rates and fees."), o.a.createElement("li", null, "You understand and are aware of the risks associated with accessing or using or participating in the Services, and you will be fully liable at your own risk."), o.a.createElement("li", null, "You are aware that you are subject to tax regulations in the jurisdiction you reside in and will be fully responsible for filling or reporting any taxes and paying them as required by the Applicable Laws. The Company will not be liable to compensate you for your tax obligations or advise you in relation to your tax obligations. Any uncertainties and unpredictable matters in tax legislation with respect to any tokens may expose you to any unknown or unforeseeable tax implications associated with your holding of tokens and the use the Services for which the Company will have no liability. Moreover, you will not hold the Company liable for any expenses or losses resulting from unknown or unforeseeable tax implications."), o.a.createElement("li", null, "You will not breach any of the provisions stipulated in these Terms, the Privacy Policy, or any Applicable Laws in any relevant jurisdictions."), o.a.createElement("li", null, "You will not use the Website and the Services in one of any following manners, except as expressly permitted in these Terms, or at the Company's discretion.", o.a.createElement("p", null, "You will not:"), o.a.createElement("p", null, "(a) infringe any propriety rights, including but not limited to copyrights, patents, trademarks, or trade secrets of the Company."), o.a.createElement("p", null, "(b) use the Website or the Services to transmit any data or send or upload any material or content that contains viruses, Trojan horses, worms, time-bombs, keystroke loggers, spyware, adware, or any other harmful programmes or similar computer code designed to adversely affect the operation of the Website and/or the Services."), o.a.createElement("p", null, "(c) expressly or impliedly, use the Website and the Services in the manner that is deemed unlawful, offensive, malicious, threatening, libellous, defamatory, obscene, or otherwise objectionable or violates these Terms, or any other party's intellectual property."), o.a.createElement("p", null, "(d) modify, make any back-up or archival copies of the Platform or any part thereof including disassembling, and you will also not adapt, hack the Website or modify another website to falsely imply that it is associated with the Website falsely."), o.a.createElement("p", null, "(f) crawl, scrape, or otherwise cache any content from the Website, and you agree not to use any automated data collection methods, data mining, robots, or scraping or any data gathering methods of any kind on the Website."), o.a.createElement("p", null, "(g) use the Website or any of its contents for advertising or soliciting, for any other commercial, political, or religious purpose, or to compete, either directly or indirectly with the Company.")), o.a.createElement("li", null, "You will defend, indemnify, and not hold the Company, the Partners, its Affiliate, each of their respective employees, officers, directors, and representatives liable to and against any claims, damages, losses, liabilities, costs, and expenses (including reasonable attorney's fees), arising out of or relating to any third-party claim concerning these Terms, or your use of the Company\u2019s Services in violation of these Terms and applicable laws."))), o.a.createElement("li", null, "Each of the User\u2019s Representations and warranties under this Clause 10 shall survive and continue to remain in full force and effect after the termination and/or the expiration of these Terms."))), o.a.createElement("li", null, o.a.createElement("b", null, "Risk Disclosure"), o.a.createElement("p", null, "By accessing the Website or using or participating in the Company Services, you expressly acknowledge and assume the following risks:"), o.a.createElement("ol", null, o.a.createElement("li", null, "Risk of loss in value", o.a.createElement("p", null, "Tokens or any digital currencies are not issued by any central banks or national, supra-national, or quasi-national organizations. They are also not backed by any hard assets or other credit. The value of tokens or any digital currencies is affected by several factors, including but not limited to, the total number of tokens or any digital currencies in existence, the continued willingness of market participants to exchange government-issued currency for tokens or digital currencies , purchasers' expectations with respect to the rate of inflation of fiat currencies, purchasers' expectations with respect to the rate of deflation of cryptocurrencies, interest rates, currency exchange rates, cyber theft of cryptocurrencies from online digital wallet providers, or news of such theft from such providers or individuals' digital wallets, investment and trading activities of large investors, monetary policies of the governments, trade restrictions, currency devaluations and revaluations, regulatory measures, the global or regional political, economic or financial events and situations. Thus, all these factors will affect the value of tokens or digital currencies, which may result in the permanent partial or total loss of the value of the Company, a particular tokens or digital currency. No one will be obliged to guarantee the liquidity or the market price of any of the BSCPAD Token or digital currencies maintained into your Wallets. The volatility and unpredictability of the value of tokens or digital currencies relative to the government-issued currency may result in a significant loss over a short period of time.")), o.a.createElement("li", null, "The regulatory regime governing tokens or digital currencies", o.a.createElement("p", null, "The regulatory framework relating to tokens or digital currencies remains unsettled, and any laws, regulations, or guidelines may be significantly revised and amended which will materially and adversely affect the value of tokens or digital currencies and your services on ", o.a.createElement("a", {
                        href: "https://bscpad.com/"
                    }, "https://bscpad.com/"), " ", "Website or BSCPAD Platform as follows.")), o.a.createElement("li", null, "Technical and system failure affected the obligations stipulated in these Terms the Company may experience system failures, unplanned interruptions in its Binance Smart Chain Network or services, hardware or software defects, security breaches or other causes that could adversely affect the Company\u2019s infrastructure network, which includes", " ", o.a.createElement("a", {
                        href: "https://bscpad.com/"
                    }, "https://bscpad.com/"), " Website and BSCPAD Platform.", o.a.createElement("p", null, "The Company is unable to anticipate the occurrence of hacks, cyber-attacks, mining attacks, including but not limited to double-spend attacks, majority mining power attacks and selfish-mining attacks, distributed denial of service attacks or errors, vulnerabilities or defects on the Website, BSCPAD Token, Users' Wallets or any technology, including but not limited to smart contract technology. Also, the Company is unable to detect the hacks as mentioned earlier, mining attacks, cyber-attacks, distributed denials of service errors vulnerabilities, or defects in a timely manner and does not have sufficient resources to efficiently cope with multiple service incidents happening simultaneously or in rapid succession."), o.a.createElement("p", null, "In addition, the Company's network or the services could be disrupted by numerous events, including natural disasters, equipment breakdown, network connectivity downtime, power losses, or even intentional disruptions of its services, such as disruptions caused by software viruses or attacks by unauthorized users, some of which are beyond the Company's control. Although the Company has taken steps and used its best endeavour against malicious attacks on its appliances or its infrastructure, which are critical for the maintenance of the BSCPAD Platform and the Services, there can be no assurance that cyber-attacks, such as distributed denials of the Service, will not be attempted in the future, and that the Company's enhanced security measures will be effective. Any significant breach of the Company's security measures or other disruptions resulting in a compromise of the usability, stability and security of the Company's network or the services, including the BSCPAD Platform, may adversely affect BSCPAD Token.")), o.a.createElement("li", null, "The Company will have no liability for any delay, error, interruption, or failure to perform any obligation under these Terms where the delay or failure is directly or indirectly resulting from any causes beyond the Company's control, including, but not limited to:", o.a.createElement("ol", null, o.a.createElement("li", null, "Acts of God, nature, court or government;"), o.a.createElement("li", null, "Failure or interruption of public or private telecommunication networks, the failure of Binance Smart Chain Network, communication channels or information systems;"), o.a.createElement("li", null, "Acts or omission of a party for whom the Company is not responsible;"), o.a.createElement("li", null, "Delay, failure, or interruption in, or unavailability of, third-party services; and"), o.a.createElement("li", null, "Strikes, lockouts, labour disputes, wars, terrorist acts and riots."))), o.a.createElement("li", null, "YOU UNDERSTAND AND AGREE THAT YOUR USE OF THE SERVICES AND THE WEBSITE IS COMPLETELY AT YOUR OWN RISK. THIS CLAUSE IS NOT EXHAUSTIVE AND DOES NOT DISCLOSE ALL THE RISKS ASSOCIATED WITH DIGITAL CURRENCIES AND THE USE OF SERVICES. THEREFORE, YOU ARE RECOMMENDED TO CAREFULLY CONSIDER WHETHER SUCH USE IS SUITABLE FOR YOU IN LIGHT OF YOUR JUDGEMENT, CIRCUMSTANCES, AND FINANCIAL POSITION."))), o.a.createElement("li", null, o.a.createElement("b", null, "Limitation of Liability"), o.a.createElement("ol", null, o.a.createElement("li", null, "NOTWITHSTANDING ANY PROVISIONS WITHIN THESE TERMS, IN NO EVENT WILL THE COMPANY, ITS PARTNERS ITS AFFILIATE, OR ITS EMPLOYEES, AGENTS, OFFICERS, OR DIRECTORS BE LIABLE TO THE USER FOR ANY INCIDENTAL, SPECIAL, EXEMPLARY, PUNITIVE, INDIRECT, OR CONSEQUENTIAL DAMAGES OF ANY KIND, UNDER ANY LEGAL THEORY, ARISING OUT OF OR IN CONNECTION WITH YOUR USE, OR INABILITY TO USE, THE WEBSITE, ANY WEBSITES LINKED TO IT, ANY CONTENT ON THE WEBSITE OR OTHER SUCH WEBSITES, OR ANY OTHER SERVICES OR ITEMS OBTAINED THROUGH THE WEBSITE, OR OTHER SUCH WEBSITES, INCLUDING, BUT NOT LIMITED TO, LOST REVENUE, LOST PROFITS, LOSS OF BUSINESS OR ANTICIPATED SAVINGS, LOSS OF USE, LOSS OF GOODWILL, LOSS OF DATA, LOSS OF YOUR CREDENTIAL INFORMATION, LOSS OR INTERRUPTION OF TECHNOLOGY, LOSS OF USE OF SERVICE OR EQUIPMENT, EVEN IF THE USER WAS ADVISED OF THE POSSIBILITY OF SUCH DAMAGES, AND WHETHER ARISING UNDER A THEORY OF CONTRACT, TORT, STRICT LIABILITY OR OTHERWISE. THE COMPANY WILL ALSO HAVE NO LIABILITY FOR ANY EMERGENCY AND/OR UNFORESEEABLE INCIDENTS RELATED TO YOUR USE OF THE SERVICES ON THE BSCPAD Platform SUCH AS STOLEN PRIVATE KEY, OR HACKED ACCOUNTS."), o.a.createElement("li", null, "Except as expressly provided in these Terms, and to the maximum extent permitted by any Applicable Laws, we disclaim all other representations or warranties, express or implied, made to you, your affiliates, or any other person, including, without limitation, any warranties regarding the quality, suitability, merchantability, fitness for a particular purpose or otherwise (regardless of any course of dealing, custom or usage of trade) of any service provided incidental to the Services under these Terms."), o.a.createElement("li", null, "In no event will our aggregate liability for any loss or damage that arises in connection with the Services exceed the purchase amount you paid to participate in the Service, if any, during a twelve (12) month period immediately preceding the event that gave rise to the claim for liability. The preceding limitations of liability will apply to the fullest actual amount you paid to participate in or access in the Service."), o.a.createElement("li", null, "Except as expressly provided in these Terms, and to the fullest extent permitted by any Applicable Laws, the Company, its Affiliate, and its related parties each disclaim all liability to you for any loss or damage arising out of or due to:", o.a.createElement("ol", null, o.a.createElement("li", null, "your use of, inability to use, or availability or unavailability of the Services, including any Third Party Services made available through the Services;"), o.a.createElement("li", null, "the occurrence or existence of any defect, interruption, deletion of files, delays in the operation or transmission of information to, from, or through the Services, communications failure, theft, destruction or unauthorised access to BSCPAD\u2019s records, programs, services, server, or other infrastructure relating to the Services;"), o.a.createElement("li", null, "the Services being infected with any malicious code or viruses; or"), o.a.createElement("li", null, "the failure of the Services to remain operational for any period of time."))))), o.a.createElement("li", null, o.a.createElement("b", null, "Indemnification"), o.a.createElement("p", null, "You irrevocably undertake the responsibility of fully indemnifying and holding harmless each of the Company, its Affiliate, licensors, shareholders, officers, directors, managers, employees, and agents from and against any and all losses, claims, actions, proceedings, damages, demands, judgements, sums, liabilities, damages, costs, charges and expenses, including, but not limited to, any reasonable attorney's fees or penalties imposed by any regulatory authority, and reimbursements arising out of or related to the following situations:"), o.a.createElement("ol", null, o.a.createElement("li", null, "Your use or any person using the Services on your behalf or participation in accordance with the Services on the Website or the BSCPAD Platform;"), o.a.createElement("li", null, "Your breach of or our enforcement of these Terms;"), o.a.createElement("li", null, "Any violations of Applicable Laws, regulation, or rights of any third-party during your use or participate in the Service.")), o.a.createElement("p", null, "If you are obligated to indemnify the Company, its Affiliate, shareholders, licensors, officers, directors, managers, employees, and agents, the Company will have the right, at our sole discretion, to control any action or proceeding and to determine whether BSPAD wishes to proceed, or settle, and if so, on what terms or provisions.")), o.a.createElement("li", null, o.a.createElement("b", null, "Termination"), o.a.createElement("ol", null, o.a.createElement("li", null, "These Terms will be immediately terminated by discontinuing your use of or participate in the Services and you agree to terminate the accessibility on the BSCPAD\u2019s Platform."), o.a.createElement("li", null, "These Terms can be suspended or terminated without a notice from the Company if there is a reasonable ground for the Company to believe that you have breached any of the terms or provisions stipulated in these Terms, or if you do not comply with these Terms."), o.a.createElement("li", null, "The termination of these Terms will not prevent the Company from seeking remedies from you in the case where you have breached any terms or provisions of these term before such termination. The Company will not be liable to you or to any third party for any termination, suspension, or modification of your access to the Services."), o.a.createElement("li", null, "Any ongoing obligation to you as well as the provisions regarding (i) BSCPAD' Intellectual Property, (ii) No solicitation or Offering, (iii) Indemnification, (iv) Limitation of liability, and (v) any other provisions designed to survive, will survive any termination or expiration of these Terms for any reason."))), o.a.createElement("li", null, o.a.createElement("b", null, "No Financial and Legal Advice"), o.a.createElement("p", null, "The Company is merely a technology platform, and is not your broker, intermediary, agent, or legal advisor and has no fiduciary relationship or obligation to you in connection with any decisions or activities effected by you using the Website or the Services. No communication or information provided to you by the Company is intended as or will be considered or construed as, the solicitation of an offer to buy, the investment advice, financial advice, legal advice, or any other sort of advice. All Services, transactions, and Investments will be executed automatically based on the parameters of your consideration. You will be solely responsible for determining whether any Services, or investments are suitable and match your interests according to your judgement, objectives, circumstances, and risk tolerance. You will be solely responsible for any losses or liabilities therefrom."), o.a.createElement("p", null, "Before executing any transactions, purchasing BSCPAD Token or IDO tokens on the BSCPAD Platform, you should consult with your independent financial, legal, or tax professionals. The Company will not be liable for the decisions you make to access and purchase through the Company.", " ")), o.a.createElement("li", null, o.a.createElement("b", null, "Notice/Announcement"), o.a.createElement("p", null, "Any notice, requests, demands, and determinations for the Company under these Terms (other than routine operational communications) shall be sent to ", o.a.createElement("a", {
                        href: "mailto:support@bscpad.com"
                    }, "support@bscpad.com"), " at", " ", o.a.createElement("a", {
                        href: "https://bscpad.com/"
                    }, "https://bscpad.com/"), ".")), o.a.createElement("li", null, o.a.createElement("b", null, "Governing Law, Resolving Disputes, Arbitration and Class Action Waiver"), o.a.createElement("p", null, "PLEASE READ THIS SECTION CAREFULLY AS IT INVOLVES A WAIVER OF CERTAIN RIGHTS TO BRING LEGAL PROCEEDINGS, INCLUDING A CLASS ACTION."), o.a.createElement("ol", null, o.a.createElement("li", null, "Notice of Claim and Dispute Resolution Period", o.a.createElement("p", null, "Please contact the Company first. The Company will seek to address your concerns without resorting to formal legal proceedings whenever possible. If you have a dispute with the Company, you should contact the Company, and a case number will be assigned. The Company will attempt to resolve your dispute internally as soon as possible. The parties will agree to negotiate in good faith to resolve the dispute and discussions will remain confidential and subject to applicable laws protecting settlement discussions from use as evidence in any legal proceeding.")), o.a.createElement("li", null, "Agreement to Arbitrate", o.a.createElement("p", null, "You and the Company agree that subject to paragraph 16.1 above, any dispute, claim, or controversy between you and the Company that arises in connection with, or relating in any way, to these Terms, or to your relationship with the Company as a user of the Services (whether by contract, tort, statute, fraud, misrepresentation, or any other legal theory, and whether the claims arise during or after the termination of these Terms) will be determined by a mandatory final and binding individual arbitration rather than a class action, except as set forth below under Exceptions to the Agreement to Arbitrate. You and the Company further agree that the arbitrator will have the exclusive power to rule on his or her jurisdiction, including, without limitation, any objections with respect to the existence, scope, or validity of the Agreement to Arbitrate, or to the arbitrability of any claim or counterclaim. Arbitration is more informal than a lawsuit in court. THERE IS NO JUDGE OR JURY IN ARBITRATION, AND COURT REVIEW OF AN ARBITRATION AWARD IS LIMITED. There may be more limited discovery than in court. The arbitrator must follow this agreement and can award the same damages and relief as a court, including, if applicable, attorney fees, except the arbitrator may not award declaratory or injunctive relief benefiting anyone but the parties to the arbitration. The arbitration provisions set forth in Clause 17 will survive termination of these Terms.")), o.a.createElement("li", null, "Arbitration Rules", o.a.createElement("p", null, 'Any dispute arising out of or in connection with these Terms including any question regarding its existence, validity or termination, shall be referred to and finally resolved by arbitration administered by the Singapore International Arbitration Centre ("SIAC") in accordance with the Arbitration Rules of the Singapore International Arbitration Centre ("SIAC Rules") for the time being in force, which rules are deemed to be incorporated by reference in these Terms. The seat of the arbitration shall be Singapore. The Tribunal shall consist of one arbitrator. The language of the arbitration shall be English.')), o.a.createElement("li", null, "Governing Law/Jurisdiction", o.a.createElement("p", null, "The governing law of the arbitration will be that of the British Virgin Islands.")), o.a.createElement("li", null, "Confidentiality", o.a.createElement("p", null, "The parties agree that the arbitration will be kept confidential. The existence of the arbitration, any non-public information provided in the arbitration, and any submissions, orders or awards made in the arbitration will not be disclosed to any non-parties except the tribunal, the parties, their counsel, experts, witnesses, accountants and auditors, insurers and reinsurers, and any other person necessary to facilitate the arbitration. Notwithstanding the preceding, a party may disclose information to the extent that disclosure may be required to fulfil a legal duty, protect, or pursue a legal right, or enforce or challenge an award in bona fide legal proceedings. This confidentiality provision will survive the termination of these Terms and any arbitration brought under these Terms.")), o.a.createElement("li", null, "Class Action Waiver", o.a.createElement("p", null, "You and the Company agree that any claims relevant to these Terms, or your relationship with the Company will be brought against the other party in arbitration on an individual basis only and not as a plaintiff or class member in a purported class or representative action. You and the Company further agree to waive any right for such claims to be brought, heard, or arbitrated as a class, collective, representative, or private attorney general action, to the extent permissible by applicable laws. Combining or consolidating individual arbitrations into a single arbitration is not permitted without the consent of all parties involved.")), o.a.createElement("li", null, "The Company reserves the right to update, modify, revise, suspend, or make future changes to Section 16.2 regarding the parties' Agreement to Arbitrate, subject to applicable laws. You hereby consent and agree that it is your responsibility to ensure that your understanding of this Clause is up to date. Subject to applicable laws, your continued use of your BSCPad\u2019s account will be interpreted as your acceptance of any modifications to Clause 16 regarding the parties' Agreement to Arbitrate. You agree that if you object to the modifications to Clause 16, the Company may block access to your account pending closure of your account. In such circumstances, these Terms prior to modification will remain in full force and affect the pending closure of your accessibility."))), o.a.createElement("li", null, o.a.createElement("b", null, "Miscellaneous"), o.a.createElement("ol", null, o.a.createElement("li", null, "Severability", o.a.createElement("p", null, "If any of the provisions in these Terms is found by a court of competent authority to be invalid, void, unlawful or unenforceable under any applicable laws, such unenforceability or invalidity will not render these Terms unenforceable or invalid as a whole, and such provisions will be deleted without affecting the remaining provisions herein.")), o.a.createElement("li", null, "Variation of Terms", o.a.createElement("p", null, "the Company has the right to revise these Terms at our sole discretion at any time, and by using the Website or other BSCPAD\u2019s platform, you will be expected to review such Terms regularly to ensure that you understand all provisions stipulated in these Terms.")), o.a.createElement("li", null, "Assignment", o.a.createElement("p", null, "The Company will be allowed to assign, transfer, and subcontract Our rights and/or obligations under these Terms without the need to provide you any notification or acquire your consent. Nevertheless, you will not be permitted to assign, transfer, or subcontract any of your rights and/or obligations under these Terms.")), o.a.createElement("li", null, "Entire Agreement", o.a.createElement("p", null, "These Terms, including the Privacy Policy and any rules contained on the Website or others BSCPAD Platform, constitute the sole and entire agreement between You and the Company with respect to your use of the BSCPAD Platform, and supersedes other prior or contemporaneous negotiations, discussions, agreements, understandings, representations, and warranties, both written and oral, between You and the Company with respect to such subject matter.")), o.a.createElement("li", null, "No Third-Party Rights", o.a.createElement("p", null, "Nothing in these Terms will be deemed to create any rights to any creditors or other persons, not a party hereto. Moreover, these Terms will not be construed, in any respect, to be a contract, in whole or in part, for the benefit of any third parties.")), o.a.createElement("li", null, "Clickwrap", o.a.createElement("p", null, "The Company may deliver the Service through electronic means such as download links, graphical, Tools or other technologies for providing the Service for users. The user interfaces to such electronic means may require that the users agree to these Terms by checking a box, clicking a button, or continuing with the Service. If user through such action the user becomes a Party to these Terms. Such an action of acceptance shall be sufficient to bind the users to the terms and conditions herein these Terms.")), o.a.createElement("li", null, "Waiver", o.a.createElement("p", null, "The failure of one Party to require the performance of any provision will not affect that Party's right to require performance at any time thereafter. At the same time, the waiver of one Party to seek recovery for the other Party's violation of these Terms of any provisions of applicable terms will not constitute a waiver by that Party of any subsequent breach or violation by the other Party or of the provision itself."))))))))))))
                };

            function se() {
                return {
                    type: D.SUBMIT_GET_PROJECTS
                }
            }

            function ce(e) {
                return {
                    type: D.SUBMIT_PROJECT_SELECTED,
                    data: e
                }
            }
            var ue = a(23),
                me = a.n(ue),
                de = a(13);
            var pe = function(e, t, a, n) {
                    var r = t,
                        o = setInterval((function() {
                            var t = (new Date).getTime(),
                                a = r - t,
                                i = Math.floor(a / 864e5),
                                l = Math.floor(a % 864e5 / 36e5),
                                s = Math.floor(a % 36e5 / 6e4),
                                c = Math.floor(a % 6e4 / 1e3);
                            try {
                                document.getElementById(e).innerHTML = i + "d " + l + "h " + s + "m " + c + "s ", a <= 0 && (n(o), clearInterval(o), document.getElementById(e).innerHTML = "0d 0h 0m 0s")
                            } catch (u) {}
                        }), 1e3);
                    a(o)
                },
                he = function(e) {
                    var t = Object($.a)().t,
                        a = Object(s.c)((function(e) {
                            return Object(ue.get)(e, "project.waitingProjects", [])
                        }));
                    return o.a.createElement("div", {
                        className: "pp-investment pt-0",
                        style: {
                            backgroundImage: "none"
                        }
                    }, o.a.createElement("div", {
                        className: "container text-center"
                    }, o.a.createElement("div", {
                        className: "row d-flex justify-content-center"
                    }, o.a.createElement("div", {
                        className: "col-lg-12 text-center"
                    }, o.a.createElement("div", {
                        className: "section-text"
                    }, o.a.createElement("h2", {
                        className: "section-title"
                    }, t("Projects Coming soon")), o.a.createElement("p", {
                        className: "section-description"
                    })))), o.a.createElement("div", {
                        className: "investment-section-items"
                    }, o.a.createElement("div", {
                        className: "row d-flex"
                    }, a.length > 0 ? a.map((function(e, a) {
                        return pe("idOpenTime-".concat(e.contract, "-").concat(e.openTime), 1e3 * e.openTime, (function(e) {}), (function(e) {})), o.a.createElement("div", {
                            className: "col-lg-6 col-md-6 text-center",
                            key: a
                        }, o.a.createElement("div", {
                            className: "single-item"
                        }, e.athMultiplier && o.a.createElement("div", {
                            className: "pp-top-tag"
                        }, o.a.createElement("div", null, o.a.createElement("small", null, "ATH")), o.a.createElement("div", null, o.a.createElement("b", null, e.athMultiplier, "x"))), o.a.createElement("div", {
                            className: "pp-card-body"
                        }, o.a.createElement("div", {
                            className: "pp-card-top"
                        }, o.a.createElement(V.a, {
                            to: e.contract && "TBA" !== e.contract ? "project/".concat(e.contract) : "#"
                        }, o.a.createElement("div", {
                            className: "icon-box"
                        }, o.a.createElement("span", null, o.a.createElement("img", {
                            src: e.logo,
                            alt: "#"
                        })))), o.a.createElement("div", {
                            className: "title-box"
                        }, o.a.createElement("h3", {
                            className: "d-flex align-items-center"
                        }, o.a.createElement(V.a, {
                            to: e.contract && "TBA" !== e.contract ? "project/".concat(e.contract) : "#"
                        }, o.a.createElement("div", null, e.name))), o.a.createElement("div", {
                            className: "item-social"
                        }, e.pancakeswap && o.a.createElement("a", {
                            style: {
                                backgroundColor: "#47d4dc"
                            },
                            href: e.pancakeswap,
                            target: "_blank"
                        }, o.a.createElement("img", {
                            height: "18",
                            src: "/images/pancake-swap.png"
                        })), e.website && o.a.createElement("a", {
                            href: e.website,
                            target: "_blank"
                        }, o.a.createElement("i", {
                            className: "fas fa-globe"
                        })), e.twitter && o.a.createElement("a", {
                            href: e.twitter,
                            target: "_blank"
                        }, o.a.createElement("i", {
                            className: "fab fa-twitter"
                        })), e.medium && o.a.createElement("a", {
                            href: e.medium,
                            target: "_blank"
                        }, o.a.createElement("i", {
                            className: "fab fa-medium-m"
                        })), e.telegram && o.a.createElement("a", {
                            href: e.telegram,
                            target: "_blank"
                        }, o.a.createElement("i", {
                            className: "fab fa-telegram"
                        }))), o.a.createElement(V.a, {
                            className: "items-morex",
                            to: e.contract && "TBA" !== e.contract ? "project/".concat(e.contract) : "#"
                        }, "P" === e.state && o.a.createElement(o.a.Fragment, null, "TBA" === e.contract || 0 === e.openTime || 0 == e.rate ? o.a.createElement("span", {
                            className: "pp-status-opening"
                        }, o.a.createElement("i", {
                            className: "mdi mdi-circle"
                        }), " ", t("Opens in TBA"), o.a.createElement("b", null)) : o.a.createElement("span", {
                            className: "pp-status-opening"
                        }, o.a.createElement("i", {
                            className: "mdi mdi-circle"
                        }), " ", t("Opens in"), " ", o.a.createElement("b", {
                            id: "idOpenTime-".concat(e.contract, "-").concat(e.openTime)
                        }, function(e) {
                            var t = e - (new Date).getTime();
                            return Math.floor(t / 864e5) + "d " + Math.floor(t % 864e5 / 36e5) + "h " + Math.floor(t % 36e5 / 6e4) + "m " + Math.floor(t % 6e4 / 1e3) + "s"
                        }(1e3 * e.openTime)))), "TBA" !== e.contract ? o.a.createElement("div", null, o.a.createElement("span", {
                            className: ""
                        }, e.symbol)) : o.a.createElement("div", null)))), o.a.createElement("div", {
                            className: "item-desc mb-1"
                        }, o.a.createElement("div", {
                            className: "item-short-desc"
                        }, e.description), o.a.createElement("div", {
                            className: "item-learn-more"
                        }, e.detail && o.a.createElement("a", {
                            target: "blank",
                            href: e.detail
                        }, t("Learn more")))), o.a.createElement(V.a, {
                            to: e.contract && "TBA" !== e.contract ? "project/".concat(e.contract) : "#"
                        }, o.a.createElement("div", {
                            className: "part-prize"
                        }, o.a.createElement("div", {
                            className: "pp-card-info"
                        }, o.a.createElement("div", {
                            className: "pp-card-col"
                        }, t("Swap rate"), o.a.createElement("br", null), o.a.createElement("b", {
                            className: "nowrap"
                        }, e.contract && "TBA" !== e.contract && 0 !== e.rate ? "1 ".concat(e.symbol, " = ").concat(e.rate, " ").concat(e.projectTokenSymbol) : "TBA")), o.a.createElement("div", {
                            className: "pp-card-col text-center ps-28"
                        }, t("Cap"), o.a.createElement("br", null), o.a.createElement("b", null, e.contract ? "TBA" !== e.contract ? "".concat(e.maxTotalParticipationAllocated || 0, " ").concat(e.projectToken || "") : t("TBA") : "TBA")), o.a.createElement("div", {
                            className: "pp-card-col text-end"
                        }, t("Access"), o.a.createElement("br", null), o.a.createElement("b", null, e.isPrivate ? t("Private") : t("Public")))), o.a.createElement("div", {
                            className: "pp-card-info d-block"
                        }, o.a.createElement("div", {
                            className: "O" == e.state ? "pp-card-progress-wrap disabled" : "pp-card-progress-wrap"
                        }, o.a.createElement("div", {
                            className: "mb-2 d-flex justify-content-between align-items-center pp-card-progress-top"
                        }, o.a.createElement("div", {
                            className: "pp-card-col"
                        }, t("Progress")), "TBA" !== e.contract && "P" != e.state && o.a.createElement("div", {
                            className: "pp-card-col text-end"
                        }, t("Participants"), " ", o.a.createElement("b", {
                            className: "text-participants font-12"
                        }, e.totalCountUserParticipated))), o.a.createElement("div", {
                            className: "pp-card-progress"
                        }, o.a.createElement("div", {
                            className: "pp-card-progress-percent",
                            style: {
                                width: "".concat(100 * (e.totalFundParticipated / e.maxTotalParticipationAllocated || 0), "%")
                            }
                        }), o.a.createElement("div", {
                            className: "pp-card-progress-label"
                        }, o.a.createElement("span", null, o.a.createElement("b", null, (100 * (e.totalFundParticipated / e.maxTotalParticipationAllocated || 0)).toFixed(2), "%")), "O" == e.state && o.a.createElement("span", {
                            className: "participants-center"
                        }, o.a.createElement("b", null, e.totalCountUserParticipated), " ", t("Participants")), o.a.createElement("span", {
                            className: "text-allocation"
                        }, o.a.createElement("b", null, e.totalFundParticipated.toFixed(4), "/", e.maxTotalParticipationAllocated)))))))))))
                    })) : o.a.createElement(o.a.Fragment, null, o.a.createElement("div", null, o.a.createElement("span", null, t("No projects currently coming soon"))))))))
                },
                be = function(e) {
                    var t = Object($.a)().t,
                        a = Object(s.c)((function(e) {
                            return Object(ue.get)(e, "project.openingProjects", [])
                        }));
                    return o.a.createElement("div", {
                        className: "pp-investment pp-open"
                    }, o.a.createElement("div", {
                        className: "container text-center"
                    }, o.a.createElement("div", {
                        className: "row d-flex"
                    }, o.a.createElement("div", {
                        className: "col-lg-12 text-center"
                    }, o.a.createElement("div", {
                        className: "section-text"
                    }, o.a.createElement("h2", {
                        className: "section-title"
                    }, t("Projects Open Now")), o.a.createElement("p", {
                        className: "section-description"
                    })))), o.a.createElement("div", {
                        className: "investment-section-items"
                    }, o.a.createElement("div", {
                        className: "row d-flex "
                    }, a.length > 0 ? a.map((function(e, a) {
                        return o.a.createElement("div", {
                            className: "col-lg-6 col-md-6 text-center",
                            key: a
                        }, o.a.createElement("div", {
                            className: "single-item"
                        }, e.athMultiplier && o.a.createElement("div", {
                            className: "pp-top-tag"
                        }, o.a.createElement("div", null, o.a.createElement("small", null, t("ATH"))), o.a.createElement("div", null, o.a.createElement("b", null, e.athMultiplier, "x"))), o.a.createElement("div", {
                            className: "pp-card-body"
                        }, o.a.createElement("div", {
                            className: "pp-card-top"
                        }, o.a.createElement(V.a, {
                            to: "project/".concat(e.contract)
                        }, o.a.createElement("div", {
                            className: "icon-box"
                        }, o.a.createElement("span", null, o.a.createElement("img", {
                            src: e.logo,
                            alt: "#"
                        })))), o.a.createElement("div", {
                            className: "title-box"
                        }, o.a.createElement("h3", {
                            className: "d-flex align-items-center"
                        }, o.a.createElement(V.a, {
                            to: "project/".concat(e.contract)
                        }, o.a.createElement("div", null, e.name))), o.a.createElement("div", {
                            className: "item-social"
                        }, e.pancakeswap && o.a.createElement("a", {
                            style: {
                                backgroundColor: "#47d4dc"
                            },
                            href: e.pancakeswap,
                            target: "_blank"
                        }, o.a.createElement("img", {
                            height: "18",
                            src: "/images/pancake-swap.png"
                        })), e.website && o.a.createElement("a", {
                            href: e.website,
                            target: "_blank"
                        }, o.a.createElement("i", {
                            className: "fas fa-globe"
                        })), e.twitter && o.a.createElement("a", {
                            href: e.twitter,
                            target: "_blank"
                        }, o.a.createElement("i", {
                            className: "fab fa-twitter"
                        })), e.medium && o.a.createElement("a", {
                            href: e.medium,
                            target: "_blank"
                        }, o.a.createElement("i", {
                            className: "fab fa-medium-m"
                        })), e.telegram && o.a.createElement("a", {
                            href: e.telegram,
                            target: "_blank"
                        }, o.a.createElement("i", {
                            className: "fab fa-telegram"
                        }))), o.a.createElement(V.a, {
                            className: "items-morex",
                            to: "project/".concat(e.contract)
                        }, ("O" === e.state || "F" === e.state) && o.a.createElement("span", {
                            className: "pp-status-open"
                        }, o.a.createElement("i", {
                            className: "mdi mdi-circle"
                        }), " ", t("Open")), o.a.createElement("div", null, o.a.createElement("span", {
                            className: ""
                        }, e.symbol))))), o.a.createElement("div", {
                            className: "item-desc mb-1"
                        }, o.a.createElement("div", {
                            className: "item-short-desc"
                        }, e.description), o.a.createElement("div", {
                            className: "item-learn-more"
                        }, e.detail && o.a.createElement("a", {
                            target: "blank",
                            href: e.detail
                        }, t("Learn more")))), o.a.createElement(V.a, {
                            to: "project/".concat(e.contract)
                        }, o.a.createElement("div", {
                            className: "part-prize"
                        }, o.a.createElement("div", {
                            className: "pp-card-info mb-3"
                        }, o.a.createElement("div", {
                            className: "pp-card-col"
                        }, t("Swap rate"), o.a.createElement("br", null), o.a.createElement("b", {
                            className: "nowrap"
                        }, "1 ", e.symbol, " = ", e.rate, " ", e.projectTokenSymbol)), o.a.createElement("div", {
                            className: "pp-card-col text-center ps-28"
                        }, t("Cap"), o.a.createElement("br", null), o.a.createElement("b", null, "".concat(e.maxTotalParticipationAllocated || 0, " ").concat(e.projectToken || ""))), o.a.createElement("div", {
                            className: "pp-card-col text-end"
                        }, t("Access"), o.a.createElement("br", null), o.a.createElement("b", null, e.isPrivate ? t("Private") : t("Public")))), "O" == e.state ? o.a.createElement("div", {
                            className: "O" == e.state ? "pp-card-progress-wrap light-progress disabled" : "pp-card-progress-wrap"
                        }, o.a.createElement("div", {
                            className: "mb-2 d-flex justify-content-between align-items-center pp-card-progress-top"
                        }, o.a.createElement("div", {
                            className: "pp-card-col"
                        }, t("Progress")), "O" != e.state && o.a.createElement("div", {
                            className: "pp-card-col text-end"
                        }, t("Participants"), " ", o.a.createElement("b", {
                            className: "text-participants font-12"
                        }, e.totalCountUserParticipated))), o.a.createElement("div", {
                            className: "pp-card-progress"
                        }, o.a.createElement("div", {
                            className: "pp-card-progress-percent",
                            style: {
                                width: "".concat(100 * (e.totalFundParticipated / e.maxTotalParticipationAllocated || 0), "%")
                            }
                        }), o.a.createElement("div", {
                            className: "pp-card-progress-label"
                        }, o.a.createElement("span", {
                            className: "participants-center"
                        }, t("Allocation round")), o.a.createElement("span", {
                            className: "participants-center",
                            style: {
                                top: "8px"
                            }
                        }, o.a.createElement("b", null, e.totalCountUserParticipated), " ", t("Participants"))))) : o.a.createElement(o.a.Fragment, null, o.a.createElement("div", {
                            className: "pp-card-progress-wrap"
                        }, o.a.createElement("div", {
                            className: "mb-2 d-flex justify-content-between align-items-center pp-card-progress-top"
                        }, o.a.createElement("div", {
                            className: "pp-card-col"
                        }, t("Progress")), o.a.createElement("div", {
                            className: "pp-card-col text-end"
                        }, t("Participants"), " ", o.a.createElement("b", {
                            className: "text-participants font-12"
                        }, e.totalCountUserParticipated))), o.a.createElement("div", {
                            className: "pp-card-progress"
                        }, o.a.createElement("div", {
                            className: "pp-card-progress-percent",
                            style: {
                                width: "".concat(100 * (e.totalFundParticipated / e.maxTotalParticipationAllocated || 0), "%")
                            }
                        }), o.a.createElement("div", {
                            className: "pp-card-progress-label"
                        }, o.a.createElement("span", null, o.a.createElement("b", null, (100 * (e.totalFundParticipated / e.maxTotalParticipationAllocated || 0)).toFixed(2), "%")), "O" == e.state && o.a.createElement("span", {
                            className: "participants-center",
                            style: {
                                top: "8px"
                            }
                        }, o.a.createElement("b", null, e.totalCountUserParticipated), " ", t("Participants")), o.a.createElement("span", {
                            className: "text-allocation"
                        }, o.a.createElement("b", null, e.totalFundParticipated.toFixed(4), "/", e.maxTotalParticipationAllocated)))))))))))
                    })) : o.a.createElement(o.a.Fragment, null, o.a.createElement("div", null, o.a.createElement("span", null, t("No projects currently open"))))))))
                },
                fe = a(86),
                ye = a.n(fe),
                Ee = (a(721), a(156)),
                ge = function(e) {
                    var t = e.total,
                        a = void 0 === t ? 0 : t,
                        n = e.itemsPerPage,
                        i = void 0 === n ? 10 : n,
                        l = e.currentPage,
                        s = void 0 === l ? 1 : l,
                        c = e.onPageChange,
                        u = Object(r.useState)(0),
                        m = Object(de.a)(u, 2),
                        d = m[0],
                        p = m[1];
                    Object(r.useEffect)((function() {
                        a > 0 && i > 0 && p(Math.ceil(a / i))
                    }), [a, i]);
                    var h = Object(r.useMemo)((function() {
                        for (var e = [], t = function(t) {
                                e.push(o.a.createElement(Ee.a.Item, {
                                    key: t,
                                    active: t === s,
                                    onClick: function() {
                                        return c(t)
                                    }
                                }, t))
                            }, a = 1; a <= d; a++) t(a);
                        return e
                    }), [d, s]);
                    return 0 === d ? null : o.a.createElement(Ee.a, null, o.a.createElement(Ee.a.Prev, {
                        onClick: function() {
                            return c(s - 1)
                        },
                        disabled: 1 === s
                    }), h, o.a.createElement(Ee.a.Next, {
                        onClick: function() {
                            return c(s + 1)
                        },
                        disabled: s === d
                    }))
                },
                ve = function(e) {
                    var t = e.onSearch,
                        a = e.placeholder,
                        n = void 0 === a ? "Search" : a,
                        i = Object(r.useState)(""),
                        l = Object(de.a)(i, 2),
                        s = l[0],
                        c = l[1];
                    return o.a.createElement("div", {
                        className: "table-input-search d-flex align-items-center",
                        style: {
                            border: "1px solid rgba(206, 212, 218,.2)",
                            borderRadius: "16px"
                        }
                    }, o.a.createElement("span", {
                        className: "mdi mdi-magnify ms-3 me-1"
                    }), o.a.createElement("input", {
                        type: "text",
                        className: "form-control form-control-sm",
                        style: {
                            backgroundColor: "transparent",
                            border: "0",
                            boxShadow: "none",
                            outline: 0,
                            color: "#999"
                        },
                        placeholder: n,
                        value: s,
                        onChange: function(e) {
                            return a = e.target.value, c(a), void t(a);
                            var a
                        }
                    }))
                },
                we = function() {
                    return Object(s.c)((function(e) {
                        return Object(ue.get)(e, "utils.web3Utils", null)
                    }))
                },
                Te = function() {
                    return Object(s.c)((function(e) {
                        return Object(ue.get)(e, "project.selectedProject", null)
                    }))
                },
                Se = function(e) {
                    var t = Object($.a)().t,
                        a = Object(r.useState)([]),
                        n = Object(de.a)(a, 2),
                        i = n[0],
                        l = (n[1], Object(s.c)((function(e) {
                            return Object(ue.get)(e, "project.closedProjects", [])
                        }))),
                        c = Object(r.useState)(0),
                        u = Object(de.a)(c, 2),
                        m = u[0],
                        d = u[1],
                        p = Object(r.useState)(1),
                        h = Object(de.a)(p, 2),
                        b = h[0],
                        f = h[1],
                        y = Object(r.useState)(""),
                        E = Object(de.a)(y, 2),
                        g = E[0],
                        v = E[1],
                        w = Object(r.useMemo)((function() {
                            var e = l;
                            return g && (e = e.filter((function(e) {
                                return e.name.toLowerCase().includes(g.toLowerCase())
                            }))), d(e.length), e.slice(12 * (b - 1), 12 * (b - 1) + 12)
                        }), [l, b, g]);
                    return o.a.createElement("div", {
                        className: "pp-investment pp-close"
                    }, o.a.createElement("div", {
                        className: "container text-center"
                    }, o.a.createElement("div", {
                        className: "row d-flex justify-content-center"
                    }, o.a.createElement("div", {
                        className: "col-lg-12 text-center"
                    }, o.a.createElement("div", {
                        className: "section-text"
                    }, o.a.createElement("h2", {
                        className: "section-title"
                    }, t("Projects Closed")), o.a.createElement("p", {
                        className: "section-description"
                    })))), o.a.createElement(ve, {
                        onSearch: function(e) {
                            v(e), f(1)
                        },
                        placeholder: "Project Name"
                    }), o.a.createElement("div", {
                        className: "investment-section-items"
                    }, o.a.createElement("div", {
                        className: "row d-flex "
                    }, w.length > 0 && w.map((function(e, a) {
                        return o.a.createElement("div", {
                            className: "col-lg-6 col-md-6 text-center",
                            key: a
                        }, o.a.createElement("div", {
                            className: "single-item"
                        }, e.athMultiplier && o.a.createElement("div", {
                            className: "pp-top-tag"
                        }, o.a.createElement("div", null, o.a.createElement("small", null, t("ATH"))), o.a.createElement("div", null, o.a.createElement("b", null, e.athMultiplier, "x"))), o.a.createElement("div", {
                            className: "pp-card-body"
                        }, o.a.createElement("div", {
                            className: "pp-card-top"
                        }, o.a.createElement(V.a, {
                            to: e.contract && "TBA" !== e.contract ? "project/".concat(e.contract) : "#"
                        }, o.a.createElement("div", {
                            className: "icon-box"
                        }, o.a.createElement("span", null, o.a.createElement("img", {
                            src: e.logo,
                            alt: "#"
                        })))), o.a.createElement("div", {
                            className: "title-box"
                        }, o.a.createElement("h3", {
                            className: "d-flex align-items-center"
                        }, o.a.createElement(V.a, {
                            to: e.contract && "TBA" !== e.contract ? "project/".concat(e.contract) : "#"
                        }, o.a.createElement("div", null, e.name))), o.a.createElement("div", {
                            className: "item-social"
                        }, e.pancakeswap && o.a.createElement("a", {
                            style: {
                                backgroundColor: "#47d4dc"
                            },
                            href: e.pancakeswap,
                            target: "_blank"
                        }, o.a.createElement("img", {
                            height: "18",
                            src: "/images/pancake-swap.png"
                        })), e.website && o.a.createElement("a", {
                            href: e.website,
                            target: "_blank"
                        }, o.a.createElement("i", {
                            className: "fas fa-globe"
                        })), e.twitter && o.a.createElement("a", {
                            href: e.twitter,
                            target: "_blank"
                        }, o.a.createElement("i", {
                            className: "fab fa-twitter"
                        })), e.medium && o.a.createElement("a", {
                            href: e.medium,
                            target: "_blank"
                        }, o.a.createElement("i", {
                            className: "fab fa-medium-m"
                        })), e.telegram && o.a.createElement("a", {
                            href: e.telegram,
                            target: "_blank"
                        }, o.a.createElement("i", {
                            className: "fab fa-telegram"
                        }))), o.a.createElement(V.a, {
                            className: "items-morex",
                            to: e.contract && "TBA" !== e.contract ? "project/".concat(e.contract) : "#"
                        }, o.a.createElement("span", {
                            className: "pp-status-closed"
                        }, o.a.createElement("i", {
                            className: "mdi mdi-circle"
                        }), " ", t("Closed")), o.a.createElement("div", null, o.a.createElement("span", {
                            className: ""
                        }, e.symbol))))), o.a.createElement("div", {
                            className: "item-desc mb-1"
                        }, o.a.createElement("div", {
                            className: "item-short-desc"
                        }, t(e.description)), o.a.createElement("div", {
                            className: "item-learn-more"
                        }, e.detail && o.a.createElement("a", {
                            target: "blank",
                            href: e.detail
                        }, t("Learn more")))), o.a.createElement(V.a, {
                            to: e.contract && "TBA" !== e.contract ? "project/".concat(e.contract) : "#"
                        }, o.a.createElement("div", {
                            className: "part-prize"
                        }, o.a.createElement("div", {
                            className: "pp-card-info mb-3"
                        }, o.a.createElement("div", {
                            className: "pp-card-col"
                        }, t("Swap rate"), o.a.createElement("br", null), o.a.createElement("b", {
                            className: "nowrap"
                        }, "1 ", e.symbol, " = ", e.rate, " ", e.projectTokenSymbol)), o.a.createElement("div", {
                            className: "pp-card-col text-center ps-28"
                        }, t("Cap"), o.a.createElement("br", null), o.a.createElement("b", null, "".concat(e.maxTotalParticipationAllocated || 0, " ").concat(e.projectToken || ""))), o.a.createElement("div", {
                            className: "pp-card-col text-end"
                        }, t("Access"), o.a.createElement("br", null), o.a.createElement("b", null, e.isPrivate ? t("Private") : t("Public")))), o.a.createElement("div", {
                            className: "O" == e.state ? "pp-card-progress-wrap disabled" : "pp-card-progress-wrap"
                        }, o.a.createElement("div", {
                            className: "mb-2 d-flex justify-content-between align-items-center pp-card-progress-top"
                        }, o.a.createElement("div", {
                            className: "pp-card-col"
                        }, t("Progress")), "O" != e.state && o.a.createElement("div", {
                            className: "pp-card-col text-end"
                        }, t("Participants"), " ", o.a.createElement("b", {
                            className: "text-participants font-12"
                        }, e.totalCountUserParticipated))), o.a.createElement("div", {
                            className: "pp-card-progress"
                        }, (!i || i.length <= 0) && o.a.createElement("div", {
                            title: "9",
                            className: "pp-card-progress-percent",
                            style: {
                                width: "".concat(100 * (e.totalFundParticipated / e.maxTotalParticipationAllocated || 0), "%")
                            }
                        }), i && i.length > 0 && i.map((function(e, t) {
                            return o.a.createElement("div", {
                                key: t,
                                title: "0",
                                className: "pp-card-progress-percent animation",
                                style: {
                                    width: e.width + "%",
                                    left: e.left + "%"
                                }
                            })
                        })), o.a.createElement("div", {
                            className: "pp-card-progress-label"
                        }, o.a.createElement("span", null, o.a.createElement("b", null, (100 * (e.totalFundParticipated / e.maxTotalParticipationAllocated || 0)).toFixed(2), "%")), "O" == e.state && o.a.createElement("span", {
                            className: "participants-center"
                        }, o.a.createElement("b", {
                            className: ""
                        }, e.totalCountUserParticipated), " ", t("Participants")), o.a.createElement("span", {
                            className: "text-allocation"
                        }, o.a.createElement("b", {
                            className: ""
                        }, e.totalFundParticipated.toFixed(4), "/", e.maxTotalParticipationAllocated))))))))))
                    })), w.length > 0 && o.a.createElement(ge, {
                        total: m,
                        itemsPerPage: 12,
                        currentPage: b,
                        className: "mx-auto",
                        onPageChange: function(e) {
                            return f(e)
                        }
                    }), 0 === w.length && o.a.createElement("div", null, "No projects not found")))))
                },
                Ne = a(412),
                ke = function(e) {
                    var t = Object(s.b)(),
                        a = Object(s.c)((function(e) {
                            return Object(Ne.a)(e, "utils.latestBlock", 0)
                        }));
                    return Object(r.useEffect)((function() {
                        t(se())
                    }), [a]), o.a.createElement(o.a.Fragment, null, o.a.createElement("div", {
                        className: "pp-projects-page mt-5 pt-3"
                    }, o.a.createElement(be, null), o.a.createElement(he, null), o.a.createElement(Se, null)))
                },
                Ce = a(67),
                Ae = Object(Ce.a)(),
                Oe = a(55),
                Pe = a.n(Oe),
                Ie = a(31),
                xe = (a(727), a(304), a(183)),
                De = ["https://i.pinimg.com/originals/51/f6/fb/51f6fb256629fc755b8870c801092942.png", "https://uploads.republic.co/p/users/avatars/small/000/495/921/495921-1603918306-631c3134317c6b89d945800117b7001813302445.JPG", "https://assets.republic.co/assets/default/user/small-9619dc1066bbd4d6507d72cb757a4dedd53b72fde52f7e402ecc8535824609c3.svg"],
                _e = function(e, t) {
                    return xe.div(xe.floor(xe.mul(e, xe.pow(10, t))), xe.pow(10, t)).toFixed(t)
                };
            var je = {
                    convertTimeStampToDate: function(e) {
                        if (e) return new Date(e).toLocaleString()
                    },
                    validatePwd: function(e) {
                        return new RegExp(/^(?:(?=.*[a-z])(?:(?=.*[A-Z])(?=.*[\d\W])|(?=.*\W)(?=.*\d))|(?=.*\W)(?=.*[A-Z])(?=.*\d)).{8,}$/).test(e)
                    },
                    validateUrl: function(e) {
                        return new RegExp(/(^http[s]?:\/{2})|(^www)|(^\/{1,2})/gim).test(e)
                    },
                    validateConversionRatio: function(e) {
                        return new RegExp(/\d+:\d+/g).test(e)
                    },
                    convertPhone: function(e, t) {
                        var a = "object" === typeof e ? e[0] : e;
                        return "+".concat(a.concat(t.replace(/^0+/, "").trim()))
                    },
                    hidePhone: function(e) {
                        return e.length > 3 ? e.substring(0, e.length - 3) + "***" : "***"
                    },
                    convertTime: function(e) {
                        return Pe()(e).format("LTS").concat(", " + Pe()(e).format("L"))
                    },
                    phoneNumberValidate: function(e) {
                        return new RegExp(/((09|03|07|08|05)+([0-9]{8})\b)/g).test(e)
                    },
                    formatNumber: function(e) {
                        return e ? e.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1,") : e
                    },
                    emailValidate: function(e) {
                        return new RegExp(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/).test(e)
                    },
                    capitalizeFirstLetter: function(e) {
                        return "string" !== typeof e ? "" : e.charAt(0).toUpperCase() + e.slice(1)
                    },
                    hideWalletAddress: function(e) {
                        return "string" !== typeof e ? "" : e.length < 20 ? e : e.substring(0, 5) + "..." + e.substring(e.length - 8, e.length)
                    },
                    roundUNWPrice: function(e, t) {
                        return "string" === typeof e ? e : e ? Math.round(e * Math.pow(10, t)) / Math.pow(10, t).toString() : e
                    },
                    formatUnw: function(e) {
                        return Number(e) / Math.pow(10, 6)
                    },
                    formatNumberWithPrecision: function(e, t) {
                        return Number(e) / Math.pow(10, t)
                    },
                    getRatioUNW: function(e) {
                        if ("string" === typeof e) {
                            var t = (e = e.trim()).split(":");
                            return {
                                tokenRatio: parseInt(t[0]),
                                unxRatio: parseInt(t[1])
                            }
                        }
                        return null
                    },
                    formatAmount: function(e) {
                        var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 2,
                            a = Number(e).toFixed(t);
                        return a = Math.round(a * Math.pow(10, t)) / Math.pow(10, t), (a = String(a)).indexOf(".") < 0 ? (a += ".", String(a).replace(/\d(?=(\d{3})+\.)/g, "$&,").replace(".", "")) : String(a).replace(/\d(?=(\d{3})+\.)/g, "$&,")
                    },
                    formatTransactionHash: function(e, t, a) {
                        if (e) return e.substring(0, t) + "..." + e.substring(e.length, e.length - a)
                    },
                    getDateDiff: function(e) {
                        var t = new Date,
                            a = new Date(t.getMonth() + 1 + "/" + t.getDay() + "/" + t.getFullYear()),
                            n = new Date(e),
                            r = Math.abs(n - a);
                        return Math.ceil(r / 864e5) + 1
                    },
                    randomAvatar: function() {
                        var e = Math.floor(Math.random() * (De.length + 1));
                        return De[e]
                    },
                    formatNumberDownRound: function(e, t) {
                        if (null === e || void 0 === e) return 0;
                        "string" === typeof e && (e = Number(e));
                        var a = e.toString().split(".");
                        if (a.length >= 2) {
                            if (a[1].length > t) {
                                var n = a[1].substring(0, t);
                                return "".concat(a[0], ".").concat(n)
                            }
                            return e.toFixed(t)
                        }
                        return e.toFixed(t)
                    },
                    formatNumberDownRoundWithExtractMax: _e,
                    isFloatFormatted: function(e, t) {
                        var a = e.toString().split(".");
                        return !(a.length >= 2 && a[1].length > t)
                    }
                },
                Be = function(e) {
                    if (console.log("timestamp==>", typeof e), "number" == typeof e) return Pe()(1e3 * e || 0).utc().format("YY-MM-DD HH:mm");
                    if ("string" == typeof e) {
                        if (!e.includes("-")) return Pe()(1e3 * e || 0).utc().format("YY-MM-DD HH:mm");
                        var t = e.split("-");
                        if (t.length >= 2) {
                            var a = Pe()(1e3 * t[0] || 0).utc().format("YY-MM-DD HH:mm"),
                                n = Pe()(1e3 * t[1] || 0).utc().format("YY-MM-DD HH:mm");
                            return "".concat(a, " <span class='mx-1 text-secondary'>to</span> ").concat(n)
                        }
                    }
                },
                Re = function(e) {
                    var t = Object($.a)().t,
                        a = Object(s.b)(),
                        n = Te(),
                        i = we(),
                        l = Object(r.useState)(""),
                        c = Object(de.a)(l, 2),
                        u = c[0],
                        m = c[1],
                        d = Object(r.useState)(""),
                        b = Object(de.a)(d, 2),
                        f = b[0],
                        y = b[1],
                        E = Object(r.useState)(0),
                        g = Object(de.a)(E, 2),
                        v = g[0],
                        w = g[1],
                        T = Object(r.useState)(!1),
                        S = Object(de.a)(T, 2),
                        N = S[0],
                        k = S[1];
                    Object(r.useEffect)((function() {
                        n && (m(n.name), y(n.symbol))
                    }), [n]);
                    return o.a.createElement("div", {
                        className: "modal fade",
                        id: "buyModal",
                        tabIndex: "-1",
                        "aria-labelledby": "buyModalLabel",
                        "aria-hidden": "true",
                        "data-bs-backdrop": "static",
                        "data-bs-keyboard": "false"
                    }, o.a.createElement("div", {
                        className: "modal-dialog modal-md modal-dialog-centered"
                    }, o.a.createElement("div", {
                        className: "modal-content"
                    }, o.a.createElement("div", {
                        className: "modal-header"
                    }, o.a.createElement("h5", {
                        className: "modal-title",
                        id: "buyModalLabel"
                    }, t("Join"), " ", u, " ", t("Pool")), o.a.createElement("div", {
                        className: "d-flex align-items-center"
                    }, o.a.createElement("button", {
                        type: "button",
                        className: "btn-close me-2",
                        "data-bs-dismiss": "modal",
                        "aria-label": "Close"
                    }))), o.a.createElement("div", {
                        className: "modal-body"
                    }, o.a.createElement("div", {
                        className: "mb-3 d-flex align-items-center"
                    }, o.a.createElement("label", {
                        className: "form-label mb-0 me-4"
                    }, t("Your balance"), ": "), o.a.createElement("h4", {
                        className: "text-warning mb-0"
                    }, null === e || void 0 === e ? void 0 : e.tokenBalance, " ", null === e || void 0 === e ? void 0 : e.symbol)), o.a.createElement("div", {
                        className: "mb-4 d-flex align-items-center justify-content-between",
                        style: {
                            columnGap: "10px"
                        }
                    }, o.a.createElement("span", {
                        className: "ps-0",
                        style: {
                            border: 0,
                            whiteSpace: "nowrap"
                        }
                    }, f, " ", t("amount"), ":"), o.a.createElement("input", {
                        type: "number",
                        id: "inputAmountSwap",
                        className: "form-control ms-2 me-1",
                        style: {
                            width: "calc(100% - 12px)"
                        },
                        defaultValue: 0,
                        autoFocus: !0,
                        onChange: function(t) {
                            return function(t) {
                                var a = Number(t.target.value);
                                0 < a && a <= e.allocationNumber && a <= e.walletInfo.remainingAllocation && a <= e.walletInfo.tokenBalance ? k(!0) : k(!1), w(a), e.handleInputAmount(a)
                            }(t)
                        }
                    }), o.a.createElement("button", {
                        style: {
                            borderRadius: "5px"
                        },
                        className: "btn btn-outline-primary",
                        onClick: function() {
                            return e.walletInfo.tokenBalance > 0 && e.allocationNumber >= e.walletInfo.tokenBalance ? (document.getElementById("inputAmountSwap").value = je.formatNumberDownRound(e.walletInfo.tokenBalance, 4), w(je.formatNumberDownRound(e.walletInfo.tokenBalance, 4)), void k(!0)) : e.allocationNumber > 0 && e.allocationNumber < e.walletInfo.tokenBalance ? (document.getElementById("inputAmountSwap").value = je.formatNumberDownRound(e.allocationNumber, 4), w(je.formatNumberDownRound(e.allocationNumber, 4)), void k(!0)) : void k(!1)
                        }
                    }, " ", t("Max"))), o.a.createElement("div", {
                        className: "get-start mt-3 text-center mb-2 d-flex",
                        style: {
                            columnGap: "10px"
                        }
                    }, o.a.createElement("button", {
                        className: "btn btn-primary w-100",
                        disabled: !N,
                        onClick: function() {
                            i && n && (a({
                                type: D.REQUEST_SUBMIT
                            }), console.log("amount==>", Number(v)), i.buyTokens({
                                contractAddress: n.contract,
                                tokenAddress: n.tokenAddress,
                                amount: Number(v)
                            }, (function(t) {
                                "BUY_SUCCESS" == t.status && (a({
                                    type: D.REQUEST_DONE
                                }), e.handleBuyClick(), k(!1), document.getElementById("inputAmountSwap").value = 0, a({
                                    type: D.ALERT_SUCCESS,
                                    message: p
                                })), "BUY_FAIL" == t.status && (a({
                                    type: D.REQUEST_DONE
                                }), a({
                                    type: D.ALERT_FAILS,
                                    message: h
                                }))
                            })).catch((function(e) {
                                a({
                                    type: D.REQUEST_DONE
                                }), a({
                                    type: D.ALERT_FAILS,
                                    message: h
                                }), console.log(e)
                            })))
                        },
                        "data-bs-dismiss": "modal"
                    }, t("Join")))))))
                },
                Le = function(e) {
                    var t = Object($.a)().t,
                        a = Object(s.b)(),
                        n = Te(),
                        i = we(),
                        l = Object(r.useState)(""),
                        c = Object(de.a)(l, 2),
                        u = c[0],
                        p = c[1],
                        h = Object(r.useState)(""),
                        b = Object(de.a)(h, 2),
                        f = b[0],
                        y = b[1],
                        E = Object(r.useState)(0),
                        g = Object(de.a)(E, 2),
                        v = g[0],
                        w = g[1],
                        T = Object(r.useState)(!1),
                        S = Object(de.a)(T, 2),
                        N = S[0],
                        k = S[1];
                    Object(r.useEffect)((function() {
                        n && (p(n.name), y(n.symbol))
                    }), [n]);
                    return o.a.createElement("div", {
                        className: "modal fade",
                        id: "approveModal",
                        tabIndex: "-1",
                        "aria-labelledby": "approveModalLabel",
                        "aria-hidden": "true",
                        "data-bs-backdrop": "static",
                        "data-bs-keyboard": "false"
                    }, o.a.createElement("div", {
                        className: "modal-dialog modal-md modal-dialog-centered"
                    }, o.a.createElement("div", {
                        className: "modal-content"
                    }, o.a.createElement("div", {
                        className: "modal-header"
                    }, o.a.createElement("h5", {
                        className: "modal-title",
                        id: "approveModalLabel"
                    }, t("Join"), " ", u, " ", t("Pool")), o.a.createElement("div", {
                        className: "d-flex align-items-center"
                    }, o.a.createElement("button", {
                        type: "button",
                        className: "btn-close me-2",
                        "data-bs-dismiss": "modal",
                        "aria-label": "Close"
                    }))), o.a.createElement("div", {
                        className: "modal-body"
                    }, o.a.createElement("div", {
                        className: "mb-3 d-flex align-items-center"
                    }, o.a.createElement("label", {
                        className: "form-label mb-0 me-4"
                    }, t("Your balance"), ": "), o.a.createElement("h4", {
                        className: "text-warning mb-0"
                    }, null === e || void 0 === e ? void 0 : e.tokenBalance, " ", null === e || void 0 === e ? void 0 : e.symbol)), o.a.createElement("div", {
                        className: "mb-2 d-flex align-items-center justify-content-between",
                        style: {
                            columnGap: "10px"
                        }
                    }, o.a.createElement("span", {
                        className: "ps-0",
                        style: {
                            border: 0,
                            whiteSpace: "nowrap"
                        }
                    }, f, " ", t("amount"), ":"), o.a.createElement("input", {
                        type: "number",
                        id: "inputAmountApprove",
                        className: "form-control ms-2 me-1",
                        style: {
                            width: "calc(100% - 12px)"
                        },
                        autoFocus: !0,
                        onChange: function(t) {
                            return function(t) {
                                var a = Number(t.target.value);
                                0 < a && a <= e.walletInfo.remainingAllocation && a <= e.walletInfo.tokenBalance ? k(!0) : k(!1), w(a), e.handleInputAmount(a)
                            }(t)
                        }
                    }), o.a.createElement("button", {
                        style: {
                            borderRadius: "5px"
                        },
                        className: "btn btn-outline-primary",
                        onClick: function() {
                            return e.walletInfo.tokenBalance > 0 && e.walletInfo.remainingAllocation <= e.walletInfo.tokenBalance ? (w(je.formatNumberDownRound(e.walletInfo.remainingAllocation, 4)), document.getElementById("inputAmountApprove").value = je.formatNumberDownRound(e.walletInfo.remainingAllocation, 4), void k(!0)) : e.walletInfo.remainingAllocation > 0 && e.walletInfo.remainingAllocation > e.walletInfo.tokenBalance ? (w(je.formatNumberDownRound(e.walletInfo.tokenBalance, 4)), document.getElementById("inputAmountApprove").value = je.formatNumberDownRound(e.walletInfo.tokenBalance, 4), void k(!0)) : void k(!1)
                        }
                    }, " ", t("Max"))), o.a.createElement("div", {
                        className: "get-start mt-3 text-center mb-2 d-flex",
                        style: {
                            columnGap: "10px"
                        }
                    }, o.a.createElement("button", {
                        className: "btn btn-primary w-100",
                        disabled: !N,
                        onClick: function() {
                            i && n && (a({
                                type: D.REQUEST_SUBMIT
                            }), console.log("amount=>", v), i.approve({
                                contractAddress: n.contract,
                                tokenContractAddress: n.tokenAddress,
                                amount: Number(v)
                            }, (function(t) {
                                "APPROVED" == t.status && (a({
                                    type: D.REQUEST_DONE
                                }), e.handleBuyClick(), document.getElementById("inputAmountApprove").value = 0, k(!1), a({
                                    type: D.ALERT_SUCCESS,
                                    message: m
                                })), "APPROVE_FAILS" == t.status && (a({
                                    type: D.REQUEST_DONE
                                }), a({
                                    type: D.ALERT_FAILS,
                                    message: d
                                }))
                            })).catch((function(e) {
                                a({
                                    type: D.ALERT_SUCCESS,
                                    message: d
                                }), a({
                                    type: D.REQUEST_DONE
                                })
                            })))
                        },
                        "data-bs-dismiss": "modal"
                    }, t("APPROVE")))))))
                },
                We = function(e) {
                    var t = Object($.a)().t;
                    return o.a.createElement("div", {
                        className: "tab-pane fade",
                        id: "schedule",
                        role: "tabpanel",
                        "aria-labelledby": "schedule-tab"
                    }, o.a.createElement("div", {
                        className: "py-3"
                    }, o.a.createElement("div", {
                        className: "row"
                    }, o.a.createElement("div", {
                        className: "col-md-6"
                    }, o.a.createElement("div", {
                        className: "card"
                    }, o.a.createElement("div", {
                        className: "card-body p-0"
                    }, o.a.createElement("div", {
                        className: "table-responsive"
                    }, o.a.createElement("table", {
                        className: "table mb-0 pp-table-info"
                    }, o.a.createElement("tbody", null, o.a.createElement("tr", {
                        className: "card-header",
                        style: {
                            border: "none"
                        }
                    }, o.a.createElement("td", null, t("Round")), o.a.createElement("td", null, t("Opens")), o.a.createElement("td", null, t("Closes"))), e.roundInfo.length > 0 && e.roundInfo.map((function(e, t) {
                        return o.a.createElement("tr", {
                            key: t
                        }, o.a.createElement("td", null, e.round, o.a.createElement("br", null)), o.a.createElement("td", null, Pe()(1e3 * e.opens || 0).utc().format("YYYY-MM-DD HH:mm:ss"), " UTC"), o.a.createElement("td", null, Pe()(1e3 * e.closes || 0).utc().format("YYYY-MM-DD HH:mm:ss"), " UTC"))
                    })))))))))))
                },
                Ue = function() {
                    var e = Object(B.a)(j.a.mark((function e(t, a) {
                        var n, r, o, i, l;
                        return j.a.wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    return n = t.tokenAddress, r = t.tokenSymbol, o = t.tokenDecimals, i = t.tokenImage, e.prev = 1, e.next = 4, window.ethereum.request({
                                        method: "wallet_watchAsset",
                                        params: {
                                            type: "ERC20",
                                            options: {
                                                address: n,
                                                symbol: r,
                                                decimals: o,
                                                image: i
                                            }
                                        }
                                    });
                                case 4:
                                    l = e.sent, a(l ? {
                                        status: J.ADD_TOKEN_SUCCESS,
                                        data: l
                                    } : {
                                        status: J.ADD_TOKEN_FAILS,
                                        data: l
                                    }), e.next = 12;
                                    break;
                                case 8:
                                    e.prev = 8, e.t0 = e.catch(1), a({
                                        status: J.ADD_TOKEN_FAILS,
                                        data: null
                                    }), console.log(e.t0);
                                case 12:
                                case "end":
                                    return e.stop()
                            }
                        }), e, null, [
                            [1, 8]
                        ])
                    })));
                    return function(t, a) {
                        return e.apply(this, arguments)
                    }
                }(),
                Fe = a(240),
                Me = function(e) {
                    var t = Object($.a)().t,
                        a = Object(s.b)(),
                        n = we(),
                        i = Object(r.useState)(1),
                        l = Object(de.a)(i, 2),
                        c = l[0],
                        u = l[1],
                        m = Object(r.useState)([]),
                        d = Object(de.a)(m, 2),
                        p = d[0],
                        h = d[1];
                    Object(r.useEffect)((function() {
                        e && (h(e.allocationInfo), u(e.layout))
                    }), [e]);
                    var b = function(t) {
                            n && (a({
                                type: D.REQUEST_SUBMIT
                            }), n.claim({
                                contractAddress: e.contractAddress,
                                index: t
                            }, (function(t) {
                                t.status == J.CLAIM_SUCCESS && (a({
                                    type: D.REQUEST_DONE
                                }), a({
                                    type: D.ALERT_SUCCESS,
                                    message: "Tokens Successfully Claimed"
                                }), e.handleBuyClick()), t.status == J.CLAIM_FAIL && (a({
                                    type: D.REQUEST_DONE
                                }), a({
                                    type: D.ALERT_FAILS,
                                    message: "Failed to claim tokens, Please contact support"
                                }), e.handleBuyClick())
                            })))
                        },
                        f = function() {
                            var t = Object(B.a)(j.a.mark((function t() {
                                return j.a.wrap((function(t) {
                                    for (;;) switch (t.prev = t.next) {
                                        case 0:
                                            e.tokenAddress ? Ue({
                                                tokenAddress: e.tokenAddress,
                                                tokenSymbol: e.tokenSymbol,
                                                tokenDecimals: e.decimals,
                                                tokenImage: ""
                                            }, (function(e) {
                                                "ADD_TOKEN_SUCCESS" == e.status && a({
                                                    type: D.ALERT_SUCCESS,
                                                    message: "Successfully added token to MetaMask"
                                                }), "ADD_TOKEN_FAILS" == e.status && a({
                                                    type: D.ALERT_FAILS,
                                                    message: "Failed to add token to MetaMask"
                                                })
                                            })) : a({
                                                type: D.ALERT_FAILS,
                                                message: "Token incorrect!"
                                            });
                                        case 1:
                                        case "end":
                                            return t.stop()
                                    }
                                }), t)
                            })));
                            return function() {
                                return t.apply(this, arguments)
                            }
                        }();
                    return o.a.createElement(o.a.Fragment, null, o.a.createElement("div", {
                        className: "tab-pane fade",
                        id: "allocation",
                        role: "tabpanel",
                        "aria-labelledby": "allocation-tab"
                    }, o.a.createElement("div", {
                        className: "py-3"
                    }, o.a.createElement("div", {
                        className: "row"
                    }, o.a.createElement("div", {
                        className: "col-md-9 pe-md-0"
                    }, o.a.createElement("div", {
                        className: "card"
                    }, o.a.createElement("div", {
                        className: "card-body p-0"
                    }, o.a.createElement("div", {
                        className: "table-responsive"
                    }, o.a.createElement("table", {
                        className: "table mb-0 pp-table-info"
                    }, o.a.createElement("tbody", null, o.a.createElement("tr", {
                        className: "card-header",
                        style: {
                            border: "none"
                        }
                    }, o.a.createElement("td", null, t("No.")), o.a.createElement("td", null, t("Allocation")), 2 === c && o.a.createElement("td", null, t("Percentage")), o.a.createElement("td", null, t("Date")), o.a.createElement("td", null, t("Claimed")), U() && o.a.createElement("td", null, t("Action"))), p.length > 0 && 1 === c && p.map((function(a, n) {
                        return o.a.createElement("tr", {
                            key: n
                        }, o.a.createElement("td", null, a.no), o.a.createElement("td", null, je.formatNumberDownRoundWithExtractMax(a.allocationAmount / Math.pow(10, e.decimals) || 0, 4), " ", e.tokenSymbol), o.a.createElement("td", null, 0 !== a.timestamp ? o.a.createElement("div", null, Pe()(1e3 * a.timestamp || 0).utc().format("YYYY-MM-DD HH:mm:ss"), " UTC ") : t("DEX Listing")), o.a.createElement("td", null, je.formatNumberDownRoundWithExtractMax(a.claimedAmount / Math.pow(10, e.decimals) || 0, 4), " ", e.tokenSymbol), o.a.createElement("td", null, o.a.createElement("button", {
                            className: "btn btn-primary btn-sm",
                            onClick: function() {
                                return b(n)
                            },
                            disabled: !("OPEN" === a.status)
                        }, t("Claim Tokens"))))
                    })), p.length > 0 && 2 === c && p.map((function(a, n) {
                        return o.a.createElement("tr", {
                            key: n
                        }, o.a.createElement("td", null, a.no), o.a.createElement("td", null, function(e, t, a) {
                            if ("number" === typeof e) return "".concat(_e(e / Math.pow(10, t), a));
                            if ("string" === typeof e) {
                                if (!e.includes("-")) return "".concat(_e(e / Math.pow(10, t), a));
                                var n = e.split("-");
                                if (n.length >= 2) {
                                    var r = _e(n[0] / Math.pow(10, t) || 0, a),
                                        o = _e(n[1] / Math.pow(10, t) || 0, a);
                                    return "".concat(r, " / ").concat(o)
                                }
                            }
                        }(a.allocationAmount, e.decimals, 4)), o.a.createElement("td", null, (a.percentage / 100).toFixed(2), "%"), o.a.createElement("td", null, 0 !== a.timestamp && "0" !== a.timestamp ? o.a.createElement("div", {
                            dangerouslySetInnerHTML: {
                                __html: Be(a.timestamp)
                            }
                        }) : t("DEX Listing")), o.a.createElement("td", null, je.formatNumberDownRoundWithExtractMax(a.claimedAmount / Math.pow(10, e.decimals) || 0, 4)), o.a.createElement("td", null, o.a.createElement("button", {
                            className: "btn btn-primary btn-sm",
                            onClick: function() {
                                return b(n)
                            },
                            disabled: !("OPEN" === a.status)
                        }, t("Claim Tokens"))))
                    })))))))), o.a.createElement("div", {
                        className: "col-md-3 text-md-end"
                    }, o.a.createElement("div", {
                        className: "mt-2"
                    }, e.allocationInfo.length >= 0 && o.a.createElement("button", {
                        onClick: function() {
                            return f()
                        },
                        className: "btn btn-primary mt-2 text-n\u01a1wrap",
                        style: {
                            width: "240px"
                        }
                    }, o.a.createElement("i", {
                        className: "fas fa-plus me-2"
                    }), o.a.createElement("span", {
                        dangerouslySetInnerHTML: {
                            __html: t("Add token to <b>MetaMask</b>")
                        }
                    }))), o.a.createElement("div", {
                        className: "mt-2"
                    }, e.claim && o.a.createElement("a", {
                        className: "btn btn-primary ms-2 text-n\u01a1wrap",
                        href: e.claim,
                        target: "blank",
                        style: {
                            width: "240px"
                        }
                    }, t("Claim via Project site"))))))))
                },
                Ye = a(66),
                Ge = a(117);

            function He() {
                var e = Object(Ye.d)(),
                    t = Object(Ye.d)("NETWORK");
                return e.active ? e : t
            }
            var Ke = new Ge.a({
                supportedChainIds: [56, 97]
            });
            var qe = function(e) {
                    var t = Object($.a)().t,
                        a = He(),
                        n = a.account,
                        i = (a.library, Object(s.b)()),
                        l = Object(c.f)(),
                        u = Object(r.useState)(""),
                        m = Object(de.a)(u, 2),
                        d = m[0],
                        p = m[1],
                        h = Object(r.useState)(0),
                        b = Object(de.a)(h, 2),
                        f = b[0],
                        y = b[1],
                        g = Object(r.useState)(0),
                        v = Object(de.a)(g, 2),
                        w = v[0],
                        T = v[1],
                        S = Object(r.useState)(0),
                        N = Object(de.a)(S, 2),
                        k = N[0],
                        C = N[1],
                        A = Object(r.useState)(0),
                        O = Object(de.a)(A, 2),
                        P = O[0],
                        I = O[1],
                        x = Object(r.useState)(0),
                        _ = Object(de.a)(x, 2),
                        R = (_[0], _[1]),
                        L = Object(r.useState)(0),
                        W = Object(de.a)(L, 2),
                        U = W[0],
                        F = W[1],
                        M = Object(r.useState)(!1),
                        Y = Object(de.a)(M, 2),
                        G = Y[0],
                        H = Y[1],
                        K = Object(r.useState)(!1),
                        q = Object(de.a)(K, 2),
                        z = q[0],
                        J = q[1],
                        V = Object(r.useState)(null),
                        X = Object(de.a)(V, 2),
                        Q = X[0],
                        Z = X[1],
                        ee = Object(r.useState)(""),
                        te = Object(de.a)(ee, 2),
                        ae = te[0],
                        ne = te[1],
                        re = Object(r.useState)(0),
                        oe = Object(de.a)(re, 2),
                        ie = oe[0],
                        le = oe[1],
                        me = Object(r.useState)(""),
                        he = Object(de.a)(me, 2),
                        be = he[0],
                        fe = he[1],
                        ye = Object(r.useState)(0),
                        Ee = Object(de.a)(ye, 2),
                        ge = Ee[0],
                        ve = Ee[1],
                        Se = Object(r.useState)(0),
                        Ne = Object(de.a)(Se, 2),
                        ke = Ne[0],
                        Ce = Ne[1],
                        Oe = Object(r.useState)([]),
                        Ie = Object(de.a)(Oe, 2),
                        xe = Ie[0],
                        De = Ie[1],
                        _e = Object(r.useState)(!1),
                        Be = Object(de.a)(_e, 2),
                        Ue = Be[0],
                        Fe = Be[1],
                        Ye = Object(r.useState)(1),
                        Ge = Object(de.a)(Ye, 2),
                        Ke = Ge[0],
                        qe = Ge[1],
                        ze = Object(s.c)((function(e) {
                            return Object(ue.get)(e, "utils.latestBlock", 0)
                        })),
                        Je = Object(r.useState)({
                            remainingAllocation: 0,
                            tokenBalance: 0
                        }),
                        Ve = Object(de.a)(Je, 2),
                        Xe = Ve[0],
                        Qe = Ve[1];
                    Object(r.useEffect)((function() {
                        var e = l.contract;
                        e && "string" === typeof e ? (p(e), i(ce(e)), i(function(e) {
                            return {
                                type: D.SET_CURRENT_CONTRACT_SELECTED,
                                data: e
                            }
                        }(e))) : Ae.push(E)
                    }), [ze, n]);
                    var $e = Te(),
                        Ze = Object(s.c)((function(e) {
                            return Object(ue.get)(e, "utils.showModalHelp", !1)
                        })),
                        et = Object(s.c)((function(e) {
                            return Object(ue.get)(e, "utils.isConnectWallet", !1)
                        })),
                        tt = we(),
                        at = Object(s.c)((function(e) {
                            return Object(ue.get)(e, "project.selectedProject.infoRound", [])
                        })),
                        nt = Object(r.useState)(0),
                        rt = Object(de.a)(nt, 2),
                        ot = rt[0],
                        it = rt[1],
                        lt = Object(r.useState)(0),
                        st = Object(de.a)(lt, 2),
                        ct = st[0],
                        ut = st[1],
                        mt = Object(r.useState)(0),
                        dt = Object(de.a)(mt, 2),
                        pt = dt[0],
                        ht = dt[1];
                    Object(r.useEffect)((function() {
                        $e && ($e.closeTime !== ot && it($e.closeTime), $e.openTime != ct && ut($e.openTime), $e.fcfsOpenTime != pt && ht($e.fcfsOpenTime), Fe($e.yourAllocationVisible), Z($e))
                    }), [$e]), Object(r.useEffect)((function() {
                        ct > 0 && pe("idOpenTime-".concat($e.contract), 1e3 * ct, (function(e) {
                            i({
                                type: D.SET_JOB_COUNT_DOWN_OPEN,
                                data: e
                            })
                        }), (function(e) {
                            bt(d), i(ce(d))
                        }))
                    }), [ct]), Object(r.useEffect)((function() {
                        ot > 0 && pe("idTimeClose-".concat($e.contract), 1e3 * ot, (function(e) {
                            i({
                                type: D.SET_JOB_COUNT_DOWN_CLOSE,
                                data: e
                            })
                        }), (function(e) {
                            bt(d), i(ce(d))
                        }))
                    }), [ot]), Object(r.useEffect)((function() {
                        pt > 0 && pe("idFcfsOpenTime-".concat($e.contract), 1e3 * pt, (function(e) {
                            i({
                                type: D.SET_JOB_COUNT_DOWN_FCFS_TIME,
                                data: e
                            })
                        }), (function(e) {
                            bt(d), i(ce(d))
                        }))
                    }), [pt]), Object(r.useEffect)((function() {
                        Number(k) > Number(ke) ? J(!0) : J(!1)
                    }), [ke, k]), Object(r.useEffect)((function() {
                        ge > 0 && $e && pe("idRoundTime-".concat($e.contract), 1e3 * ge, (function(e) {
                            i({
                                type: D.SET_JOB_COUNT_DOWN_ROUND,
                                data: e
                            })
                        }), (function(e) {
                            bt(d), i(ce(d))
                        }))
                    }), [ge]);
                    Object(r.useEffect)((function() {
                        function e() {
                            return (e = Object(B.a)(j.a.mark((function e() {
                                var t;
                                return j.a.wrap((function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            return t = l.contract, e.next = 3, bt(t);
                                        case 3:
                                            return e.next = 5, ft();
                                        case 5:
                                            return e.next = 7, yt(t);
                                        case 7:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e)
                            })))).apply(this, arguments)
                        }
                        et && tt && Q && (i(se()), function() {
                            e.apply(this, arguments)
                        }())
                    }), [et, tt, U, d, Q, ze, n]);
                    var bt = function() {
                            var e = Object(B.a)(j.a.mark((function e(t) {
                                return j.a.wrap((function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            tt && tt.getInfoWallet(t).then((function(e) {
                                                if (Qe({
                                                        remainingAllocation: e.remainingAllocation / Math.pow(10, Q.decimal),
                                                        tokenBalance: e.tokenBalance / Math.pow(10, Q.decimal),
                                                        bnbBalance: e.bnbBalance
                                                    }), T(e.bnbBalance), y(e.tokenBalance / Math.pow(10, Q.decimal)), I(e.userParticipation / Math.pow(10, Q.decimal)), C(e.remainingAllocation / Math.pow(10, Q.decimal)), ne(e.tier), le(e.roundState), fe(e.roundStateText), document.getElementById("idTextRoundState") && (document.getElementById("idTextRoundState").innerHTML = e.roundStateText), ge != e.roundTimestamp && ve(e.roundTimestamp), 0 === e.remainingAllocation ? J(!1) : J(!0), 1 !== e.roundState && 3 !== e.roundState) return console.log("call here state "), void H(!1);
                                                if ("C" !== Q.state && "P" !== Q.state && "TBA" !== Q.address)
                                                    if ($e.isPrivate) {
                                                        if (0 === e.remainingAllocation) return void H(!1);
                                                        H(!0)
                                                    } else H(!0), C(Q.maxSingleParticipationAllocated);
                                                else H(!1)
                                            })).catch((function(e) {
                                                console.log(e)
                                            }));
                                        case 1:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e)
                            })));
                            return function(t) {
                                return e.apply(this, arguments)
                            }
                        }(),
                        ft = function() {
                            var e = Object(B.a)(j.a.mark((function e() {
                                return j.a.wrap((function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            tt.getAllowance($e.tokenAddress, $e.contract).then((function(e) {
                                                Ce(e)
                                            })).catch((function(e) {
                                                console.log(e)
                                            }));
                                        case 1:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e)
                            })));
                            return function() {
                                return e.apply(this, arguments)
                            }
                        }(),
                        yt = function(e) {
                            tt.getInfoAllocations(e).then((function(e) {
                                qe(e.layout), De(e.infoAllocation)
                            })).catch((function(e) {
                                console.log(e)
                            }))
                        };
                    return o.a.createElement(o.a.Fragment, null, $e ? o.a.createElement(o.a.Fragment, null, o.a.createElement("div", {
                        className: "pp-detail-banner"
                    }, o.a.createElement("div", {
                        className: "container"
                    }, o.a.createElement("div", {
                        className: "row align-items-center"
                    }, o.a.createElement("div", {
                        className: "col-lg-5 col-md-5"
                    }, o.a.createElement("div", {
                        className: "pp-card-top animation"
                    }, o.a.createElement("div", {
                        className: "icon-box"
                    }, o.a.createElement("span", null, o.a.createElement("img", {
                        src: $e.logo,
                        alt: $e.name
                    })))), o.a.createElement("div", {
                        className: "ms-0"
                    }, o.a.createElement("div", {
                        className: "pp-card-top"
                    }, o.a.createElement("div", {
                        className: "title-box"
                    }, o.a.createElement("h2", null, $e.name, $e.pancakeswap && o.a.createElement("a", {
                        href: $e.pancakeswap,
                        target: "_blank"
                    }, o.a.createElement("img", {
                        height: "20",
                        src: "/images/pancake-swap.png"
                    })), $e.website && o.a.createElement("a", {
                        href: $e.website,
                        target: "_blank"
                    }, o.a.createElement("i", {
                        className: "fas fa-globe-americas"
                    })), $e.twitter && o.a.createElement("a", {
                        href: $e.twitter,
                        target: "_blank"
                    }, o.a.createElement("i", {
                        className: "fab fa-twitter"
                    })), $e.medium && o.a.createElement("a", {
                        href: $e.medium,
                        target: "_blank"
                    }, o.a.createElement("i", {
                        className: "fab fa-medium-m"
                    })), $e.telegram && o.a.createElement("a", {
                        href: $e.telegram,
                        target: "_blank"
                    }, o.a.createElement("i", {
                        className: "fab fa-telegram-plane"
                    }))), o.a.createElement("div", {
                        className: "items-morex"
                    }, ("O" === $e.state || "F" === $e.state) && o.a.createElement(o.a.Fragment, null, o.a.createElement("span", {
                        className: "pp-status-open"
                    }, o.a.createElement("i", {
                        className: "mdi mdi-circle"
                    }), " ", t("Open"))), "C" === $e.state && o.a.createElement(o.a.Fragment, null, o.a.createElement("span", {
                        className: "pp-status-closed"
                    }, o.a.createElement("i", {
                        className: "mdi mdi-circle"
                    }), " ", t("Closed"))), "P" === $e.state && o.a.createElement(o.a.Fragment, null, void 0 !== $e.openTime ? o.a.createElement("span", {
                        className: "pp-status-opening"
                    }, o.a.createElement("i", {
                        className: "mdi mdi-circle"
                    }), " ", t("Opens in"), " ", o.a.createElement("b", {
                        id: "idOpenTime-".concat($e.contract)
                    }, "0d 0h 0m 0s")) : o.a.createElement("span", {
                        className: "pp-status-opening"
                    }, o.a.createElement("i", {
                        className: "mdi mdi-circle"
                    }), t("TBA"))), o.a.createElement("div", null, o.a.createElement("span", {
                        className: ""
                    }, $e.symbol))))), o.a.createElement("div", {
                        className: "mb-3"
                    }, o.a.createElement("p", {
                        className: "text-muted"
                    }, t($e.description))), o.a.createElement("div", null, et ? o.a.createElement(o.a.Fragment, null, o.a.createElement("button", {
                        type: "button",
                        className: "btn btn-primary me-2",
                        "data-bs-toggle": "modal",
                        "data-bs-target": "#approveModal",
                        disabled: !z
                    }, t("Approve")), o.a.createElement("button", {
                        type: "button",
                        className: "btn btn-primary me-2",
                        "data-bs-toggle": "modal",
                        "data-bs-target": "#buyModal",
                        disabled: !G || 0 == ke
                    }, t("Join Pool"))) : o.a.createElement("button", {
                        type: "button",
                        className: "btn btn-primary me-2",
                        "data-bs-toggle": "modal",
                        "data-bs-target": Ze ? "#helpModal" : "#connectWalletModal"
                    }, t("Connect Wallet"))))), "P" !== $e.state && o.a.createElement("div", {
                        className: "col-lg-5 col-md-7"
                    }, o.a.createElement("div", {
                        className: "card card-img-holder bg-gradient-danger mx-auto mx-lg-0"
                    }, o.a.createElement("div", {
                        className: "card-body px-3 py-2"
                    }, et && o.a.createElement(o.a.Fragment, null, o.a.createElement("div", {
                        className: "pp-card-info mt-2"
                    }, o.a.createElement("div", {
                        className: "pp-card-col"
                    }, t("Your balance"), o.a.createElement("br", null), o.a.createElement("div", {
                        className: "d-flex justify-content-between align-items-center"
                    }, o.a.createElement("h4", {
                        className: "mb-0"
                    }, o.a.createElement("strong", {
                        id: "idBusdBalance"
                    }, je.formatNumberDownRound(f, 4), " ", $e.symbol))), "BNB" !== $e.symbol && o.a.createElement("div", {
                        className: "d-flex justify-content-between align-items-center"
                    }, o.a.createElement("h4", {
                        className: "mb-0"
                    }, o.a.createElement("strong", {
                        id: "idBnbBalance"
                    }, je.formatNumberDownRound(w, 4), " BNB"))), o.a.createElement("div", {
                        className: "pp-card-col"
                    }, t("Your approved amount"), ":", o.a.createElement("br", null), o.a.createElement("b", null, je.formatNumberDownRound(ke, 4), " ", $e.symbol))), o.a.createElement("div", {
                        className: "pp-card-col"
                    }, t("Your tier"), o.a.createElement("br", null), o.a.createElement("h4", {
                        className: "mb-0"
                    }, ae))), o.a.createElement("hr", {
                        className: "mb-2"
                    })), "O" == $e.state && o.a.createElement("div", {
                        className: "pp-card-info mt-2"
                    }, et ? 4 !== ie ? o.a.createElement("div", {
                        className: "pp-card-col w-200px"
                    }, o.a.createElement("span", {
                        id: "idTextRoundState"
                    }, " ", be), o.a.createElement("br", null), o.a.createElement("b", {
                        id: "idRoundTime-".concat($e.contract)
                    }, " 0d 0h 0m 0s")) : o.a.createElement("div", null, t("ROUND CLOSED")) : o.a.createElement("div", {
                        className: "pp-card-col w-200px"
                    }, t("First Come First Serve"), " ", o.a.createElement("u", null, "opens"), " in:", o.a.createElement("br", null), o.a.createElement("b", {
                        id: "idFcfsOpenTime-".concat($e.contract)
                    }, " 0d 0h 0m 0s"))), "F" == $e.state && o.a.createElement("div", {
                        className: "pp-card-info mt-2"
                    }, et ? 4 !== ie ? o.a.createElement("div", {
                        className: "pp-card-col w-200px"
                    }, o.a.createElement("span", {
                        id: "idTextRoundState"
                    }, " ", be), o.a.createElement("br", null), o.a.createElement("b", {
                        id: "idRoundTime-".concat($e.contract)
                    }, " 0d 0h 0m 0s")) : o.a.createElement("div", null, t("ROUND CLOSED")) : o.a.createElement("div", {
                        className: "pp-card-col w-200px"
                    }, t("Closing in"), ":", o.a.createElement("br", null), o.a.createElement("b", {
                        id: "idTimeClose-".concat($e.contract)
                    }, " 0d 0h 0m 0s"))), "C" == $e.state && o.a.createElement("div", {
                        className: "pp-card-info mt-2 text-white"
                    }, o.a.createElement("div", null, t("CLOSED"))), et && o.a.createElement(o.a.Fragment, null, o.a.createElement("hr", {
                        className: "mb-2 mt-2"
                    }), o.a.createElement("div", {
                        className: "pp-card-info"
                    }, o.a.createElement("div", {
                        className: "d-flex justify-content-between w-100"
                    }, o.a.createElement("div", {
                        className: "pp-card-col"
                    }, t("Swapped"), o.a.createElement("br", null), o.a.createElement("b", {
                        id: "idUseParticipation"
                    }, je.formatNumberDownRound(P, 4), " ", $e.symbol), o.a.createElement("div", null, o.a.createElement("span", null, " ", "\n                                    ".concat(je.formatNumberDownRound(P * $e.rate, 4), " ").concat($e.projectTokenSymbol)))), o.a.createElement("div", {
                        className: "pp-card-col w-200px"
                    }, t("Remaining Allocation"), ":", o.a.createElement("br", null), o.a.createElement("b", {
                        id: "idBusdMaxBuy"
                    }, je.formatNumberDownRound(k, 4), " ", $e.symbol))))), o.a.createElement("hr", {
                        className: "mb-2 mt-2"
                    }), o.a.createElement("div", {
                        className: "pp-card-info"
                    }, o.a.createElement("div", {
                        className: "d-flex justify-content-between w-100"
                    }, "O" !== $e.state ? o.a.createElement("div", {
                        className: "pp-card-col w-200px"
                    }, t("Swap progress"), o.a.createElement("br", null), o.a.createElement("div", {
                        className: "pp-card-progress"
                    }, o.a.createElement("div", {
                        className: "pp-card-progress-percent",
                        style: {
                            width: "".concat(100 * ($e.totalFundParticipated / $e.maxTotalParticipationAllocated || 0), "%")
                        }
                    }), o.a.createElement("div", {
                        className: "pp-card-progress-label"
                    }, o.a.createElement("span", null, o.a.createElement("b", null, (100 * ($e.totalFundParticipated / $e.maxTotalParticipationAllocated || 0)).toFixed(2), "%")), o.a.createElement("span", null, $e.totalFundParticipated.toFixed(4), "/", $e.maxTotalParticipationAllocated, " ", $e.symbol)))) : o.a.createElement("div", {
                        className: "pp-card-col w-200px pp-card-progress-wrap light-progress disabled"
                    }, o.a.createElement("div", {
                        className: "pp-card-progress text-center"
                    }, o.a.createElement("div", {
                        className: "pp-card-progress-percent pp-card-progress-percent-card"
                    }), o.a.createElement("div", {
                        className: "pp-card-progress-label"
                    }, o.a.createElement("span", {
                        className: "participants-center"
                    }, t("Allocation round")), o.a.createElement("span", {
                        className: "participants-center",
                        style: {
                            top: "8px"
                        }
                    }, $e.totalCountUserParticipated, " ", t("Participants")))))))))), "P" === $e.state && et && o.a.createElement("div", {
                        className: "col-lg-5 col-md-7"
                    }, o.a.createElement("div", {
                        className: "card card-img-holder bg-gradient-danger mx-auto mx-lg-0"
                    }, o.a.createElement("div", {
                        className: "card-body py-3 px-3 px-md-4"
                    }, et && o.a.createElement("div", {
                        className: "pp-card-info mt-2"
                    }, o.a.createElement("div", {
                        className: "pp-card-col"
                    }, t("Your balance"), o.a.createElement("br", null), void 0 !== $e.openTime ? o.a.createElement("div", {
                        className: "d-flex justify-content-between align-items-center"
                    }, o.a.createElement("h4", {
                        className: "mb-0"
                    }, o.a.createElement("strong", {
                        id: "idBusdBalance"
                    }, je.formatNumberDownRound(f, 4) || 0, $e.symbol)), "P" !== $e.state && o.a.createElement("h6", {
                        id: "idBusdConvert"
                    }, "1 ", $e.symbol, " = ", $e.rate, " ", $e.projectTokenSymbol)) : o.a.createElement("div", null), "BNB" !== $e.symbol && o.a.createElement("div", {
                        className: "d-flex justify-content-between align-items-center"
                    }, o.a.createElement("h4", {
                        className: "mb-0"
                    }, o.a.createElement("strong", {
                        id: "idBnbBalance"
                    }, je.formatNumberDownRound(w, 4) || 0, " BNB"))))))))))), o.a.createElement("div", {
                        className: "pp-detail-content pt-1"
                    }, o.a.createElement("div", {
                        className: "container"
                    }, o.a.createElement("ul", {
                        className: "nav nav-tabs text-end",
                        id: "myTab",
                        role: "tablist"
                    }, o.a.createElement("li", {
                        className: "nav-item",
                        role: "presentation"
                    }, o.a.createElement("button", {
                        className: "nav-link active",
                        id: "home-tab",
                        "data-bs-toggle": "tab",
                        type: "button",
                        role: "tab",
                        "aria-controls": "home",
                        "aria-selected": "true",
                        "data-bs-target": "#home"
                    }, t("Project details"))), o.a.createElement("li", {
                        className: ""
                    }, o.a.createElement("button", {
                        className: "nav-link",
                        id: "schedule-tab",
                        "data-bs-toggle": "tab",
                        type: "button",
                        role: "tab",
                        "aria-controls": "schedule",
                        "data-bs-target": "#schedule",
                        "aria-selected": "true"
                    }, t("Schedule"))), Ue && o.a.createElement("li", {
                        className: ""
                    }, o.a.createElement("button", {
                        className: "nav-link",
                        id: "allocation-tab",
                        "data-bs-toggle": "tab",
                        type: "button",
                        role: "tab",
                        "aria-controls": "allocation",
                        "data-bs-target": "#allocation",
                        "aria-selected": "true"
                    }, t("Your Allocation")))), o.a.createElement("div", {
                        className: "tab-content",
                        id: "myTabContent"
                    }, o.a.createElement("div", {
                        className: "tab-pane fade show active",
                        id: "home",
                        role: "tabpanel",
                        "aria-labelledby": "home-tab"
                    }, o.a.createElement("div", {
                        className: "py-3"
                    }, o.a.createElement("div", {
                        className: "row"
                    }, o.a.createElement("div", {
                        className: "col-md-6"
                    }, o.a.createElement("div", {
                        className: "card"
                    }, o.a.createElement("div", {
                        className: "card-header"
                    }, t("Pool information")), o.a.createElement("div", {
                        className: "card-body p-0"
                    }, o.a.createElement("div", {
                        className: "table-responsive"
                    }, o.a.createElement("table", {
                        className: "table mb-0 pp-table-info"
                    }, o.a.createElement("tbody", null, o.a.createElement("tr", null, o.a.createElement("td", null, t("Opens")), void 0 === $e.openTime ? o.a.createElement("td", {
                        className: "text-right"
                    }, t("TBA")) : o.a.createElement("td", {
                        className: "text-right"
                    }, Pe()(1e3 * $e.openTime || 0).utc().format("YYYY-MM-DD HH:mm:ss"), " UTC ")), o.a.createElement("tr", null, o.a.createElement("td", null, t("FCFS Opens")), void 0 === $e.fcfsOpenTime ? o.a.createElement("td", {
                        className: "text-right"
                    }, t("TBA")) : o.a.createElement("td", {
                        className: "text-right"
                    }, Pe()(1e3 * $e.fcfsOpenTime || 0).utc().format("YYYY-MM-DD HH:mm:ss"), " UTC ")), o.a.createElement("tr", null, o.a.createElement("td", null, t("Closes")), void 0 === $e.closeTime ? o.a.createElement("td", {
                        className: "text-right"
                    }, t("TBA")) : o.a.createElement("td", {
                        className: "text-right"
                    }, Pe()(1e3 * $e.closeTime || 0).utc().format("YYYY-MM-DD HH:mm:ss"), " UTC")), o.a.createElement("tr", null, o.a.createElement("td", null, t("Swap Rate")), void 0 !== $e.openTime ? o.a.createElement("td", null, o.a.createElement("span", {
                        style: {
                            textTransform: "uppercase"
                        },
                        id: "idBusdConvert"
                    }, "1 ", $e.symbol, " = ", $e.rate.toFixed(4), " ", $e.projectTokenSymbol)) : o.a.createElement("td", null, o.a.createElement("span", {
                        style: {
                            textTransform: "uppercase"
                        },
                        id: "idBusdConvert"
                    }, t("TBA")))), o.a.createElement("tr", null, o.a.createElement("td", null, t("Cap")), void 0 !== $e.openTime ? o.a.createElement("td", null, o.a.createElement("span", {
                        style: {
                            textTransform: "uppercase"
                        }
                    }, $e.maxTotalParticipationAllocated, " ", $e.symbol)) : o.a.createElement("td", null, o.a.createElement("span", {
                        style: {
                            textTransform: "uppercase"
                        }
                    }, t("TBA")))), o.a.createElement("tr", null, o.a.createElement("td", null, t("Total Users Participated")), o.a.createElement("td", {
                        className: "text-right"
                    }, $e.totalCountUserParticipated || 0, " ")), o.a.createElement("tr", null, o.a.createElement("td", null, t("Total Funds Swapped")), void 0 !== $e.openTime ? o.a.createElement("td", {
                        className: "text-right"
                    }, $e.totalFundParticipated.toFixed(4) || 0, " ", $e.symbol || "") : o.a.createElement("td", {
                        className: "text-right"
                    }, "0")), o.a.createElement("tr", null, o.a.createElement("td", null, t("Access Type")), o.a.createElement("td", {
                        className: "text-right"
                    }, $e.isPrivate ? "Private" : "Public")))))))), o.a.createElement("div", {
                        className: "col-md-6 mt-4 mt-md-0"
                    }, o.a.createElement("div", {
                        className: "card"
                    }, o.a.createElement("div", {
                        className: "card-header"
                    }, t("Token information")), o.a.createElement("div", {
                        className: "card-body p-0"
                    }, o.a.createElement("div", {
                        className: "table-responsive"
                    }, o.a.createElement("table", {
                        className: "table mb-0 pp-table-info"
                    }, o.a.createElement("tbody", null, o.a.createElement("tr", null, o.a.createElement("td", null, t("Name")), o.a.createElement("td", {
                        className: "text-right"
                    }, $e.name)), o.a.createElement("tr", null, o.a.createElement("td", null, t("Token Symbol")), o.a.createElement("td", {
                        className: "text-right"
                    }, $e.projectTokenSymbol)), o.a.createElement("tr", null, o.a.createElement("td", null, t("Total Supply")), o.a.createElement("td", {
                        className: "text-right"
                    }, $e.totalSupply || 0)), o.a.createElement("tr", null, o.a.createElement("td", null, o.a.createElement("br", null)), o.a.createElement("td", null)), o.a.createElement("tr", null, o.a.createElement("td", null, o.a.createElement("br", null)), o.a.createElement("td", {
                        className: "text-right"
                    })), o.a.createElement("tr", null, o.a.createElement("td", null, o.a.createElement("br", null)), o.a.createElement("td", null)), o.a.createElement("tr", null, o.a.createElement("td", null, o.a.createElement("br", null)), o.a.createElement("td", null)), o.a.createElement("tr", null, o.a.createElement("td", null, o.a.createElement("br", null)), o.a.createElement("td", null))))))))))), o.a.createElement(We, {
                        roundInfo: at
                    }), Ue && o.a.createElement(Me, {
                        allocationInfo: xe,
                        tokenSymbol: $e.projectTokenSymbol,
                        decimals: Q.decimals || 18,
                        contractAddress: d,
                        tokenAddress: Q.projectTokenContract,
                        handleBuyClick: function() {
                            return F(U + 1)
                        },
                        claim: $e.claim,
                        layout: Ke
                    }))))) : o.a.createElement(o.a.Fragment, null, o.a.createElement("div", {
                        className: "pp-detail-banner"
                    }, o.a.createElement("div", {
                        className: "container"
                    }, o.a.createElement("div", {
                        className: "row align-items-center"
                    }, o.a.createElement("div", {
                        className: "col-lg-12 col-md-12"
                    }, o.a.createElement("div", {
                        className: "card card-img-holder bg-gradient-danger mx-auto mx-lg-0"
                    }, o.a.createElement("div", {
                        className: "card-body py-3 px-3 px-md-4 text-center"
                    }))))))), o.a.createElement(Re, {
                        walletInfo: Xe,
                        allocationNumber: ke,
                        handleBuyClick: function() {
                            return F(U + 1)
                        },
                        countClick: U,
                        tokenBalance: je.formatNumberDownRound(f, 4),
                        symbol: null === $e || void 0 === $e ? void 0 : $e.symbol,
                        handleInputAmount: function(e) {
                            return R(e)
                        }
                    }), o.a.createElement(Le, {
                        walletInfo: Xe,
                        handleBuyClick: function() {
                            return F(U + 1)
                        },
                        handleInputAmount: function(e) {
                            return R(e)
                        },
                        tokenBalance: je.formatNumberDownRound(f, 4)
                    }))
                },
                ze = a(192),
                Je = a(151),
                Ve = function() {
                    var e = Object(B.a)(j.a.mark((function e(t, a) {
                        var n, r;
                        return j.a.wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    return e.prev = 0, e.next = 3, ye.a.get("".concat(Ie.BACKEND_URL).concat(u.GET_KYC, "?address=").concat(t, "&type=").concat(a));
                                case 3:
                                    if (n = e.sent, console.log(n), 200 != n.status) {
                                        e.next = 7;
                                        break
                                    }
                                    return e.abrupt("return", n.data);
                                case 7:
                                    return e.abrupt("return", null);
                                case 10:
                                    return e.prev = 10, e.t0 = e.catch(0), r = e.t0.response, console.log(r), e.abrupt("return", null);
                                case 15:
                                case "end":
                                    return e.stop()
                            }
                        }), e, null, [
                            [0, 10]
                        ])
                    })));
                    return function(t, a) {
                        return e.apply(this, arguments)
                    }
                }(),
                Xe = a(183),
                Qe = a.n(Xe);

            function $e(e) {
                return {
                    type: D.LANGUAGE_CHANGE,
                    language: e
                }
            }
            var Ze = function(e) {
                var t = Object($.a)().t,
                    a = Object(s.b)(),
                    n = He(),
                    i = n.account,
                    l = (n.library, Object(r.useState)(!1)),
                    c = Object(de.a)(l, 2),
                    u = c[0],
                    m = c[1],
                    d = Object(s.c)((function(e) {
                        return Object(ue.get)(e, "utils.showModalHelp", !1)
                    })),
                    p = Object(s.c)((function(e) {
                        return Object(ue.get)(e, "utils.web3Utils", null)
                    })),
                    h = Object(s.c)((function(e) {
                        return Object(ue.get)(e, "wallet.stakingWalletInfo.stakedAmount", 0)
                    })),
                    b = Object(s.c)((function(e) {
                        return Object(ue.get)(e, "utils.latestBlock", 0)
                    })),
                    f = Object(s.c)((function(e) {
                        return Object(ue.get)(e, "wallet.kycStatus", null)
                    })),
                    y = Object(r.useState)(0),
                    v = Object(de.a)(y, 2),
                    w = v[0],
                    T = v[1],
                    S = Object(r.useState)(!1),
                    N = Object(de.a)(S, 2),
                    k = N[0],
                    O = N[1],
                    P = Object(s.c)((function(e) {
                        return Object(ue.get)(e, "language.language", null)
                    }));
                Object(r.useEffect)((function() {
                    i && m(!0)
                }), [i]), Object(r.useEffect)((function() {
                    p && i && (p.web3.eth.getBalance(i).then((function(e) {
                        a({
                            type: D.GET_BNB_BALANCE,
                            data: Qe.a.div(e, Math.pow(10, 18))
                        })
                    })).catch((function(e) {
                        console.log(e)
                    })), p.getBscpadBalance().then((function(e) {
                        a({
                            type: D.GET_BSCPAD_BALANCE,
                            data: e
                        }), T(e)
                    })))
                }), [i, p, b]);
                var I = function() {
                    Ve(i, "url").then((function(e) {
                        if (e) {
                            var t = e.url;
                            Object(Je.isMobile)() && U() || F() ? window.location.href = t : window.open(t, "_blank")
                        }
                    })).catch((function(e) {
                        console.log(e)
                    }))
                };
                Object(r.useEffect)((function() {
                    if (i && Number(w) + Number(h) >= 100) {
                        O(!0), x(i);
                        var e = setInterval((function() {
                            x(i)
                        }), 3e4);
                        a({
                            type: D.SET_JOB_GET_KYC,
                            data: e
                        })
                    }
                }), [i, w, h]);
                var x = function(e) {
                    Ve(e, "state").then((function(t) {
                        if (e = e.toLowerCase(), t) {
                            var n = t.state;
                            if (console.log("state===>", n), console.log("address==>", e), 1 === n) return a({
                                type: D.GET_KYC_INFO,
                                data: "START"
                            });
                            if (2 === n) return a({
                                type: D.GET_KYC_INFO,
                                data: "PENDING"
                            });
                            if (3 === n) return a({
                                type: D.GET_KYC_INFO,
                                data: "APPROVED"
                            });
                            if (4 === n) return a({
                                type: D.GET_KYC_INFO,
                                data: "ERROR"
                            })
                        }
                    })).catch((function(e) {
                        console.log(e)
                    }))
                };
                var _ = function(e, t) {
                    e.preventDefault(), a($e(t))
                };
                return o.a.createElement(o.a.Fragment, null, o.a.createElement("nav", {
                    id: "PPNavbar",
                    className: "navbar navbar-expand-md navbar-light bg-white"
                }, o.a.createElement("div", {
                    className: "container"
                }, o.a.createElement(V.a, {
                    className: "navbar-brand d-flex align-items-center",
                    to: E
                }, o.a.createElement("img", {
                    src: "/images/logo.png",
                    height: "27",
                    alt: "BSCPad",
                    className: "me-2"
                }), " BSCPad"), o.a.createElement("div", {
                    className: "d-flex align-items-center",
                    style: {
                        flexWrap: "nowrap"
                    }
                }, o.a.createElement("div", {
                    className: "dropdown d-block d-md-none"
                }, o.a.createElement("button", {
                    className: "btn btn-lang btn-sm btn-outline-primary dropdown-toggle text-uppercase mw-72",
                    type: "button",
                    id: "dropdownMenuButton1",
                    "data-bs-toggle": "dropdown",
                    "aria-expanded": "false"
                }, P), o.a.createElement("ul", {
                    className: "dropdown-menu dropdown-menu-language dropdown-menu-end",
                    "aria-labelledby": "dropdownMenuButton1"
                }, o.a.createElement("li", null, o.a.createElement("a", {
                    className: "dropdown-item ".concat("en" === P ? "active" : ""),
                    href: "#",
                    onClick: function(e) {
                        return _(e, "en")
                    }
                }, o.a.createElement("img", {
                    className: "me-2",
                    src: "/images/united-states-of-america.png",
                    width: "20"
                }), o.a.createElement("span", null, "English"))), o.a.createElement("li", null, o.a.createElement("a", {
                    className: "dropdown-item ".concat("cn" === P ? "active" : ""),
                    href: "#",
                    onClick: function(e) {
                        return _(e, "cn")
                    }
                }, o.a.createElement("img", {
                    className: "me-2",
                    src: "/images/china.png",
                    width: "20"
                }), o.a.createElement("span", null, "Chinese"))))), Object(Je.isMobile)() && o.a.createElement("div", {
                    className: "dropdown ms-3 d-block d-md-none d-lg-none d-xl-none"
                }, o.a.createElement("button", {
                    className: "nav-link btn btn-sm btn-outline-primary btn-circle dropdown-toggle btn-helpmore",
                    type: "button",
                    id: "dropdownMenuButton1",
                    "data-bs-toggle": "dropdown",
                    "aria-expanded": "false"
                }, o.a.createElement("i", {
                    className: "mdi mdi-help"
                })), o.a.createElement("ul", {
                    className: "dropdown-menu  dropdown-menu-end",
                    "aria-labelledby": "dropdownMenuButton1"
                }, o.a.createElement("li", null, o.a.createElement("a", {
                    className: "dropdown-item",
                    "data-bs-toggle": "modal",
                    "data-bs-target": "#helpModal",
                    href: "#"
                }, t("How to connect wallet"))), u && o.a.createElement("li", null, o.a.createElement("a", {
                    className: "dropdown-item",
                    href: "https://bscpad.medium.com/bscpad-kyc-process-16e6a5557138",
                    target: "_blank"
                }, t("KYC Help"))))), o.a.createElement("button", {
                    className: "navbar-toggler",
                    type: "button",
                    "data-bs-toggle": "collapse",
                    "data-bs-target": "#navbarSupportedContent",
                    "aria-controls": "navbarSupportedContent",
                    "aria-expanded": "false",
                    "aria-label": "Toggle navigation"
                }, o.a.createElement("span", {
                    className: "navbar-toggler-icon"
                }))), o.a.createElement("div", {
                    className: "collapse navbar-collapse",
                    id: "navbarSupportedContent"
                }, o.a.createElement("ul", {
                    className: u ? "navbar-nav ms-auto mb-2 mb-md-0 connected" : "navbar-nav ms-auto mb-2 mb-md-0"
                }, u ? o.a.createElement(o.a.Fragment, null, o.a.createElement("li", {
                    className: "nav-item me-2"
                }, o.a.createElement("a", {
                    className: "btn btn-primary btn-sm",
                    href: "#",
                    "data-bs-toggle": "modal",
                    "data-bs-target": "#walletModal"
                }, o.a.createElement("i", {
                    className: "mdi mdi-wallet-plus-outline me-1"
                }), o.a.createElement("span", null, je.formatTransactionHash(i, 8, 8)), " - ", o.a.createElement("b", null, je.formatNumberDownRoundWithExtractMax(w, 4)), " BSCPAD")), k && o.a.createElement(o.a.Fragment, null, "START" === f && o.a.createElement("li", {
                    className: "nav-item me-2"
                }, o.a.createElement("button", {
                    className: "btn btn-warning btn-sm",
                    onClick: function() {
                        return I()
                    },
                    id: "bnt-kyc-start"
                }, o.a.createElement("i", {
                    className: "mdi mdi-file-edit-outline me-1"
                }), o.a.createElement("span", null, t("KYC")))), "PENDING" === f && o.a.createElement("li", {
                    className: "nav-item me-2"
                }, o.a.createElement("button", {
                    className: "btn btn-primary btn-sm",
                    onClick: function() {
                        return I()
                    }
                }, o.a.createElement("i", {
                    className: "mdi mdi-clock-outline me-1"
                }), o.a.createElement("span", null, t("KYC")))), "APPROVED" === f && o.a.createElement(o.a.Fragment, null, o.a.createElement("li", {
                    className: "nav-item me-2"
                }, o.a.createElement("button", {
                    className: "btn btn-success btn-sm"
                }, o.a.createElement("i", {
                    className: "mdi mdi-check me-1"
                }), o.a.createElement("span", null, t("KYC")))), o.a.createElement("li", {
                    className: "nav-item me-2"
                }, o.a.createElement("button", {
                    className: "btn btn-outline-primary btn-sm",
                    "data-bs-toggle": "modal",
                    "data-bs-target": "#setKycModal"
                }, o.a.createElement("img", {
                    src: "/images/tron-logo-crop.png",
                    height: "14",
                    alt: "TronPad"
                }), o.a.createElement("span", {
                    className: "ms-1"
                }, t("Sync KYC"))))), "ERROR" === f && o.a.createElement("li", {
                    className: "nav-item me-2"
                }, o.a.createElement("button", {
                    className: "btn btn-danger btn-sm",
                    onClick: function() {
                        return I()
                    }
                }, o.a.createElement("i", {
                    className: "mdi mdi-close me-1"
                }), o.a.createElement("span", null, t("KYC")))))) : o.a.createElement("li", {
                    className: "nav-item me-2"
                }, o.a.createElement("a", {
                    className: "btn btn-primary btn-sm",
                    href: "#",
                    "data-bs-toggle": "modal",
                    "data-bs-target": d ? "#helpModal" : "#connectWalletModal"
                }, o.a.createElement("i", {
                    className: "mdi mdi-wallet-plus-outline me-1"
                }), o.a.createElement("span", null, t("Connect Wallet")))), o.a.createElement("li", {
                    className: "nav-item me-2"
                }, o.a.createElement(V.a, {
                    className: "btn btn-outline-primary btn-sm btn-projects",
                    "aria-current": "page",
                    to: g,
                    onClick: function() {
                        a({
                            type: D.CLEAR_INTERVAL_PROJECTS_JOB
                        })
                    }
                }, o.a.createElement("i", {
                    className: "mdi mdi-fire me-1"
                }), o.a.createElement("span", null, t("Projects")))), o.a.createElement("li", {
                    className: "nav-item me-2"
                }, o.a.createElement(V.a, {
                    className: "btn btn-outline-primary btn-sm btn-staking",
                    "aria-current": "page",
                    to: A
                }, o.a.createElement("i", {
                    className: "mdi mdi-blender-software me-1"
                }), o.a.createElement("span", null, t("Staking")))), o.a.createElement("li", {
                    className: "nav-item me-2"
                }, o.a.createElement(V.a, {
                    className: "nav-link btn btn-sm btn-outline-primary btn-circle",
                    to: C
                }, o.a.createElement("i", {
                    className: "mdi mdi-calendar-range-outline"
                }))), o.a.createElement("li", {
                    className: "nav-item me-2"
                }, o.a.createElement("button", {
                    className: "nav-link btn btn-sm btn-outline-primary btn-circle",
                    type: "button",
                    onClick: function() {
                        document.body.classList.contains("darkmode") ? document.body.classList.remove("darkmode") : document.body.classList.add("darkmode")
                    }
                }, o.a.createElement("i", {
                    className: "mdi mdi-lightbulb-on"
                }))), !Object(Je.isMobile)() && u && o.a.createElement("li", {
                    className: "nav-item d-none d-md-block"
                }, o.a.createElement("div", {
                    className: "dropdown"
                }, o.a.createElement("button", {
                    className: "nav-link btn btn-sm btn-outline-primary btn-circle dropdown-toggle btn-helpmore",
                    type: "button",
                    id: "dropdownMenuButton1",
                    "data-bs-toggle": "dropdown",
                    "aria-expanded": "false"
                }, o.a.createElement("i", {
                    className: "mdi mdi-help"
                })), o.a.createElement("ul", {
                    className: "dropdown-menu  dropdown-menu-end",
                    "aria-labelledby": "dropdownMenuButton1"
                }, o.a.createElement("li", null, o.a.createElement("a", {
                    className: "dropdown-item",
                    href: "https://bscpad.medium.com/bscpad-kyc-process-16e6a5557138",
                    target: "_blank"
                }, t("KYC Help")))))), o.a.createElement("li", {
                    className: "nav-item d-md-block d-none"
                }, o.a.createElement("div", {
                    className: "dropdown"
                }, o.a.createElement("button", {
                    className: "btn btn-lang btn-sm btn-outline-primary dropdown-toggle text-uppercase mw-72",
                    type: "button",
                    id: "dropdownMenuButton1",
                    "data-bs-toggle": "dropdown",
                    "aria-expanded": "false"
                }, P), o.a.createElement("ul", {
                    className: "dropdown-menu dropdown-menu-language dropdown-menu-end",
                    "aria-labelledby": "dropdownMenuButton1"
                }, o.a.createElement("li", null, o.a.createElement("a", {
                    className: "dropdown-item ".concat("en" === P ? "active" : ""),
                    href: "#",
                    onClick: function(e) {
                        return _(e, "en")
                    }
                }, o.a.createElement("img", {
                    className: "me-2",
                    src: "/images/united-states-of-america.png",
                    width: "20"
                }), o.a.createElement("span", null, "English"))), o.a.createElement("li", null, o.a.createElement("a", {
                    className: "dropdown-item ".concat("cn" === P ? "active" : ""),
                    href: "#",
                    onClick: function(e) {
                        return _(e, "cn")
                    }
                }, o.a.createElement("img", {
                    className: "me-2",
                    src: "/images/china.png",
                    width: "20"
                }), o.a.createElement("span", null, "Chinese")))))))))))
            };

            function et() {
                return {
                    type: D.ALERT_LINK_CLEAR
                }
            }
            var tt, at = a(188),
                nt = a(241),
                rt = a(414),
                ot = a(3),
                it = a(4),
                lt = a(5),
                st = a(6),
                ct = a(115),
                ut = (a(77), a(45)),
                mt = a(79),
                dt = a(444),
                pt = function(e) {
                    Object(lt.a)(a, e);
                    var t = Object(st.a)(a);

                    function a(e, n, r) {
                        return Object(ot.a)(this, a), t.call(this, e)
                    }
                    return a
                }(Object(dt.a)(Error)),
                ht = function e(t, a, n) {
                    var r = this;
                    Object(ot.a)(this, e), this.isMetaMask = !1, this.chainId = 97, this.url = "", this.host = "", this.path = "", this.nextId = 1, this.batchTimeoutId = null, this.batch = [], this.clearBatch = Object(B.a)(j.a.mark((function e() {
                        var t, a, n, o, i, l, s, c, u, m, d, p, h, b;
                        return j.a.wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    return console.info("Clearing batch", r.batch), t = r.batch, r.batch = [], r.batchTimeoutId = null, e.prev = 4, e.next = 7, fetch(r.url, {
                                        method: "POST",
                                        headers: {
                                            "content-type": "application/json",
                                            accept: "application/json"
                                        },
                                        body: JSON.stringify(t.map((function(e) {
                                            return e.request
                                        })))
                                    });
                                case 7:
                                    a = e.sent, e.next = 14;
                                    break;
                                case 10:
                                    return e.prev = 10, e.t0 = e.catch(4), t.forEach((function(e) {
                                        return (0, e.reject)(new Error("Failed to send batch call"))
                                    })), e.abrupt("return");
                                case 14:
                                    if (a.ok) {
                                        e.next = 17;
                                        break
                                    }
                                    return t.forEach((function(e) {
                                        return (0, e.reject)(new pt("".concat(a.status, ": ").concat(a.statusText), -32e3))
                                    })), e.abrupt("return");
                                case 17:
                                    return e.prev = 17, e.next = 20, a.json();
                                case 20:
                                    n = e.sent, e.next = 27;
                                    break;
                                case 23:
                                    return e.prev = 23, e.t1 = e.catch(17), t.forEach((function(e) {
                                        return (0, e.reject)(new Error("Failed to parse JSON response"))
                                    })), e.abrupt("return");
                                case 27:
                                    o = t.reduce < Object(x.a)({}, id, BatchItem) > {}, i = Object(mt.a)(n);
                                    try {
                                        for (i.s(); !(l = i.n()).done;) s = l.value, c = o[s.id], u = c.resolve, m = c.reject, d = c.request.method, u && ("error" in s ? m(new pt(null === s || void 0 === s || null === (p = s.error) || void 0 === p ? void 0 : p.message, null === s || void 0 === s || null === (h = s.error) || void 0 === h ? void 0 : h.code, null === s || void 0 === s || null === (b = s.error) || void 0 === b ? void 0 : b.data)) : "result" in s ? u(s.result) : m(new pt("Received unexpected JSON-RPC response to ".concat(d, " request."), -32e3, s)))
                                    } catch (f) {
                                        i.e(f)
                                    } finally {
                                        i.f()
                                    }
                                case 30:
                                case "end":
                                    return e.stop()
                            }
                        }), e, null, [
                            [4, 10],
                            [17, 23]
                        ])
                    }))), this.sendAsync = function(e, t) {
                        r.request(e.method, e.params).then((function(a) {
                            return t(null, {
                                jsonrpc: "2.0",
                                id: e.id,
                                result: a
                            })
                        })).catch((function(e) {
                            return t(e, null)
                        }))
                    }, this.request = function() {
                        var e = Object(B.a)(j.a.mark((function e(t, a) {
                            var n, o;
                            return j.a.wrap((function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        if ("string" === typeof t) {
                                            e.next = 2;
                                            break
                                        }
                                        return e.abrupt("return", r.request(t.method, t.params));
                                    case 2:
                                        if ("eth_chainId" !== t) {
                                            e.next = 4;
                                            break
                                        }
                                        return e.abrupt("return", "0x".concat(r.chainId.toString(16)));
                                    case 4:
                                        return o = new Promise((function(e, n) {
                                            r.batch.push({
                                                request: {
                                                    jsonrpc: "2.0",
                                                    id: r.nextId++,
                                                    method: t,
                                                    params: a
                                                },
                                                resolve: e,
                                                reject: n
                                            })
                                        })), r.batchTimeoutId = null !== (n = r.batchTimeoutId) && void 0 !== n ? n : setTimeout(r.clearBatch, r.batchWaitTimeMs), e.abrupt("return", o);
                                    case 7:
                                    case "end":
                                        return e.stop()
                                }
                            }), e)
                        })));
                        return function(t, a) {
                            return e.apply(this, arguments)
                        }
                    }(), this.chainId = t, this.url = a;
                    var o = new URL(a);
                    this.host = o.host, this.path = o.pathname, this.batchWaitTimeMs = null !== n && void 0 !== n ? n : 50
                },
                bt = function(e) {
                    Object(lt.a)(a, e);
                    var t = Object(st.a)(a);

                    function a(e) {
                        var n, r = e.urls,
                            o = e.defaultChainId;
                        return Object(ot.a)(this, a), Object(ut.a)(o || 1 === Object.keys(r).length, "defaultChainId is a required argument with >1 url"), (n = t.call(this, {
                            supportedChainIds: Object.keys(r).map((function(e) {
                                return Number(e)
                            }))
                        })).providers = [], n.currentChainId = o || Number(Object.keys(r)[0]), n.providers = Object.keys(r).reduce((function(e, t) {
                            return e[Number(t)] = new ht(Number(t), r[Number(t)]), e
                        }), {}), n
                    }
                    return Object(it.a)(a, [{
                        key: "provider",
                        value: function() {
                            return this.providers[this.currentChainId]
                        }
                    }, {
                        key: "activate",
                        value: function() {
                            var e = Object(B.a)(j.a.mark((function e() {
                                return j.a.wrap((function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            return e.abrupt("return", {
                                                provider: this.providers[this.currentChainId],
                                                chainId: this.currentChainId,
                                                account: null
                                            });
                                        case 1:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e, this)
                            })));
                            return function() {
                                return e.apply(this, arguments)
                            }
                        }()
                    }, {
                        key: "getProvider",
                        value: function() {
                            var e = Object(B.a)(j.a.mark((function e() {
                                return j.a.wrap((function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            return e.abrupt("return", this.providers[this.currentChainId]);
                                        case 1:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e, this)
                            })));
                            return function() {
                                return e.apply(this, arguments)
                            }
                        }()
                    }, {
                        key: "getChainId",
                        value: function() {
                            var e = Object(B.a)(j.a.mark((function e() {
                                return j.a.wrap((function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            return e.abrupt("return", this.currentChainId);
                                        case 1:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e, this)
                            })));
                            return function() {
                                return e.apply(this, arguments)
                            }
                        }()
                    }, {
                        key: "getAccount",
                        value: function() {
                            var e = Object(B.a)(j.a.mark((function e() {
                                return j.a.wrap((function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            return e.abrupt("return", null);
                                        case 1:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e)
                            })));
                            return function() {
                                return e.apply(this, arguments)
                            }
                        }()
                    }, {
                        key: "deactivate",
                        value: function() {
                            return null
                        }
                    }]), a
                }(ct.AbstractConnector),
                ft = bt;
            new bt({
                urls: Object(x.a)({}, K, q),
                defaultChainId: K
            });
            var yt = new Ge.a({
                    supportedChainIds: [56]
                }),
                Et = new at.BscConnector({
                    supportedChainIds: [56]
                }),
                gt = new rt.a({
                    rpc: Object(x.a)({}, K, q),
                    qrcode: !0,
                    pollingInterval: 15e3
                });
            tt = {}, Object(x.a)(tt, Y, yt), Object(x.a)(tt, G, Et), Object(x.a)(tt, H, gt);
            var vt = function() {
                    var e, t = Object(s.b)(),
                        a = Object(Ye.d)(),
                        n = a.activate,
                        o = a.deactivate,
                        i = (e = {}, Object(x.a)(e, Y, yt), Object(x.a)(e, G, Et), Object(x.a)(e, H, gt), e);
                    return {
                        login: Object(r.useCallback)((function(e) {
                            var a = i[e];
                            if (a) try {
                                n(a, function() {
                                    var e = Object(B.a)(j.a.mark((function e(a) {
                                        return j.a.wrap((function(e) {
                                            for (;;) switch (e.prev = e.next) {
                                                case 0:
                                                    window.localStorage.removeItem("connectorId"), a instanceof Ye.a ? t({
                                                        type: D.ALERT_WARNING,
                                                        message: y
                                                    }) : a instanceof Ge.b || a instanceof at.NoBscProviderError ? t({
                                                        type: D.ALERT_FAILS,
                                                        message: "No provider was found"
                                                    }) : a instanceof Ge.c ? t({
                                                        type: D.ALERT_FAILS,
                                                        message: "Please authorize to access your account"
                                                    }) : t({
                                                        type: D.ALERT_FAILS,
                                                        message: a.message
                                                    });
                                                case 2:
                                                case "end":
                                                    return e.stop()
                                            }
                                        }), e)
                                    })));
                                    return function(t) {
                                        return e.apply(this, arguments)
                                    }
                                }())
                            } catch (r) {
                                console.log(r)
                            } else t({
                                type: D.ALERT_FAILS,
                                message: "The connector config is wrong"
                            })
                        }), []),
                        logout: o
                    }
                },
                wt = a(105),
                Tt = a.n(wt),
                St = a(194),
                Nt = a(120),
                kt = a(88),
                Ct = a(246),
                At = function() {
                    function e(t, a) {
                        Object(ot.a)(this, e), this.web3 = new Tt.a(t), this.address = a
                    }
                    return Object(it.a)(e, [{
                        key: "getWeb3Helper",
                        value: function(t, a) {
                            return e.web3 || (e.web3 = new e(t, a)), e.web3
                        }
                    }, {
                        key: "approve",
                        value: function() {
                            var e = Object(B.a)(j.a.mark((function e(t, a) {
                                var n, r, o, i, l;
                                return j.a.wrap((function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            return n = t.tokenContractAddress, r = t.contractAddress, o = M(o = t.amount), e.prev = 2, i = new this.web3.eth.Contract(St, n), a({
                                                status: J.APPROVING
                                            }), l = "0x" + o.toString(16), console.log(l), e.next = 9, i.methods.approve(r, l).send({
                                                from: this.address
                                            });
                                        case 9:
                                            a({
                                                status: J.APPROVED
                                            }), e.next = 16;
                                            break;
                                        case 12:
                                            e.prev = 12, e.t0 = e.catch(2), a({
                                                status: J.APPROVE_FAILS
                                            }), console.log(e.t0);
                                        case 16:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e, this, [
                                    [2, 12]
                                ])
                            })));
                            return function(t, a) {
                                return e.apply(this, arguments)
                            }
                        }()
                    }, {
                        key: "claim",
                        value: function() {
                            var e = Object(B.a)(j.a.mark((function e(t, a) {
                                var n, r, o, i;
                                return j.a.wrap((function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            return n = t.contractAddress, r = t.index, o = new this.web3.eth.Contract(Nt, n), e.prev = 2, e.next = 5, o.methods.claim(r).send({
                                                from: this.address
                                            }).on("error", (function(e) {
                                                console.log(e), a({
                                                    status: J.CLAIM_FAIL
                                                })
                                            })).then((function(e) {
                                                1 == e.status ? a({
                                                    status: J.CLAIM_SUCCESS,
                                                    txID: e.transactionHash
                                                }) : a({
                                                    status: J.CLAIM_FAIL
                                                })
                                            })).catch((function(e) {
                                                console.log(e), a({
                                                    status: J.CLAIM_FAIL
                                                })
                                            }));
                                        case 5:
                                            return i = e.sent, e.abrupt("return", i);
                                        case 9:
                                            return e.prev = 9, e.t0 = e.catch(2), console.error(e.t0.message), a({
                                                status: J.CLAIM_FAIL
                                            }), e.abrupt("return", e.t0.message);
                                        case 14:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e, this, [
                                    [2, 9]
                                ])
                            })));
                            return function(t, a) {
                                return e.apply(this, arguments)
                            }
                        }()
                    }, {
                        key: "buyTokens",
                        value: function() {
                            var e = Object(B.a)(j.a.mark((function e(t, a) {
                                var n, r, o, i, l, s, c;
                                return j.a.wrap((function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            return n = t.contractAddress, r = t.tokenAddress, o = t.amount, i = new this.web3.eth.Contract(Nt, n), o = M(o), l = "0x" + o.toString(16), s = "0x0000000000000000000000000000000000000000" === r ? {
                                                from: this.address,
                                                value: l
                                            } : {
                                                from: this.address
                                            }, e.prev = 5, e.next = 8, i.methods.participate(r, l).send(s).on("error", (function(e) {
                                                console.log(e), a({
                                                    status: J.BUY_FAIL
                                                })
                                            })).then((function(e) {
                                                1 == e.status ? a({
                                                    status: J.BUY_SUCCESS,
                                                    txID: e.transactionHash
                                                }) : a({
                                                    status: J.BUY_FAIL
                                                })
                                            })).catch((function(e) {
                                                console.log(e), a({
                                                    status: J.BUY_FAIL
                                                })
                                            }));
                                        case 8:
                                            return c = e.sent, e.abrupt("return", c);
                                        case 12:
                                            return e.prev = 12, e.t0 = e.catch(5), console.error(e.t0.message), a({
                                                status: J.BUY_FAIL
                                            }), e.abrupt("return", e.t0.message);
                                        case 17:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e, this, [
                                    [5, 12]
                                ])
                            })));
                            return function(t, a) {
                                return e.apply(this, arguments)
                            }
                        }()
                    }, {
                        key: "getInfoAllocations",
                        value: function() {
                            var e = Object(B.a)(j.a.mark((function e(t) {
                                var a, n;
                                return j.a.wrap((function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            return {
                                                0: "PENDING",
                                                1: "OPEN",
                                                2: "CLOSED"
                                            }, a = new this.web3.eth.Contract(Nt, t), e.next = 4, a.methods.infoAllocations().call({
                                                from: this.address
                                            });
                                        case 4:
                                            return n = e.sent, e.abrupt("return", Ot(n));
                                        case 6:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e, this)
                            })));
                            return function(t) {
                                return e.apply(this, arguments)
                            }
                        }()
                    }, {
                        key: "getInfoWallet",
                        value: function() {
                            var e = Object(B.a)(j.a.mark((function e(t) {
                                var a, n, r, o, i, l, s, c, u, m;
                                return j.a.wrap((function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            return a = new this.web3.eth.Contract(Nt, t), e.next = 3, a.methods.infoWallet().call({
                                                from: this.address
                                            });
                                        case 3:
                                            return n = e.sent, r = parseFloat(n[0] / Math.pow(10, 18)), o = parseInt(n[1]), i = n[2], l = parseInt(n[3]), s = n[4], c = parseInt(n[5]), u = parseInt(n[6]), m = parseInt(n[7]), e.abrupt("return", {
                                                tokenBalance: o,
                                                tier: i,
                                                roundState: l,
                                                roundStateText: s,
                                                roundTimestamp: c,
                                                remainingAllocation: u,
                                                bnbBalance: r,
                                                userParticipation: m
                                            });
                                        case 13:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e, this)
                            })));
                            return function(t) {
                                return e.apply(this, arguments)
                            }
                        }()
                    }, {
                        key: "getTokenBalance",
                        value: function() {
                            var e = Object(B.a)(j.a.mark((function e(t) {
                                var a, n;
                                return j.a.wrap((function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            return a = new this.web3.eth.Contract(St, t), e.next = 3, a.methods.balanceOf(this.address).call();
                                        case 3:
                                            return n = e.sent, e.abrupt("return", new W.BigNumber(n.toString()).dividedBy(Math.pow(10, 18)).toFixed(18).replace(/\.?0+$/, "").toString());
                                        case 5:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e, this)
                            })));
                            return function(t) {
                                return e.apply(this, arguments)
                            }
                        }()
                    }, {
                        key: "getAllowance",
                        value: function() {
                            var e = Object(B.a)(j.a.mark((function e(t, a) {
                                var n, r;
                                return j.a.wrap((function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            return n = new this.web3.eth.Contract(St, t), e.next = 3, n.methods.allowance(this.address, a).call();
                                        case 3:
                                            return r = e.sent, e.abrupt("return", new W.BigNumber(r.toString()).dividedBy(Math.pow(10, 18)).toString());
                                        case 5:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e, this)
                            })));
                            return function(t, a) {
                                return e.apply(this, arguments)
                            }
                        }()
                    }, {
                        key: "getBscpadBalance",
                        value: function() {
                            var e = Object(B.a)(j.a.mark((function e() {
                                var t, a, n;
                                return j.a.wrap((function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            return t = new this.web3.eth.Contract(kt, Ie.STAKING_CONTRACT_ADDRESS), e.next = 3, t.methods.token().call();
                                        case 3:
                                            return a = e.sent, e.next = 6, this.getTokenBalance(a);
                                        case 6:
                                            return n = e.sent, e.abrupt("return", n);
                                        case 8:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e, this)
                            })));
                            return function() {
                                return e.apply(this, arguments)
                            }
                        }()
                    }, {
                        key: "stakingDeposit",
                        value: function() {
                            var e = Object(B.a)(j.a.mark((function e(t, a) {
                                var n, r, o, i;
                                return j.a.wrap((function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            return n = t.amount, r = new this.web3.eth.Contract(kt, Ie.STAKING_CONTRACT_ADDRESS), n = M(n), o = "0x" + n.toString(16), e.prev = 4, e.next = 7, r.methods.stake(o).send({
                                                from: this.address
                                            }).on("error", (function(e) {
                                                console.log(e), a({
                                                    status: J.STAKING_DEPOSIT_FAIL
                                                })
                                            })).on("transactionHash", (function(e) {
                                                a({
                                                    status: J.STAKING_DEPOSIT_SUBMIT,
                                                    txID: e
                                                })
                                            })).then((function(e) {
                                                !0 === e.status ? a({
                                                    status: J.STAKING_DEPOSIT_SUCCESS,
                                                    txID: e.transactionHash
                                                }) : a({
                                                    status: J.STAKING_DEPOSIT_FAIL
                                                })
                                            })).catch((function(e) {
                                                console.log(e), a({
                                                    status: J.STAKING_DEPOSIT_FAIL
                                                })
                                            }));
                                        case 7:
                                            return i = e.sent, e.abrupt("return", i);
                                        case 11:
                                            return e.prev = 11, e.t0 = e.catch(4), console.error(e.t0.message), a({
                                                status: J.STAKING_DEPOSIT_FAIL
                                            }), e.abrupt("return", e.t0.message);
                                        case 16:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e, this, [
                                    [4, 11]
                                ])
                            })));
                            return function(t, a) {
                                return e.apply(this, arguments)
                            }
                        }()
                    }, {
                        key: "stakingInitiateWithdrawal",
                        value: function() {
                            var e = Object(B.a)(j.a.mark((function e(t, a) {
                                var n, r, o, i;
                                return j.a.wrap((function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            return n = t.amount, r = new this.web3.eth.Contract(kt, Ie.STAKING_CONTRACT_ADDRESS), n = M(n), o = "0x" + n.toString(16), e.prev = 4, e.next = 7, r.methods.unstake(o).send({
                                                from: this.address
                                            }).on("transactionHash", (function(e) {
                                                a({
                                                    status: "STAKING_INITIATE_WITHDRAWAL_SUBMIT",
                                                    txID: e
                                                })
                                            })).on("error", (function(e) {
                                                console.log(e), a({
                                                    status: "STAKING_INITIATE_WITHDRAWAL_FAIL"
                                                })
                                            })).then((function(e) {
                                                !0 === e.status ? a({
                                                    status: "STAKING_INITIATE_WITHDRAWAL_SUCCESS",
                                                    txID: e.transactionHash
                                                }) : a({
                                                    status: "STAKING_INITIATE_WITHDRAWAL_FAIL"
                                                })
                                            })).catch((function(e) {
                                                console.log(e), a({
                                                    status: "STAKING_INITIATE_WITHDRAWAL_FAIL"
                                                })
                                            }));
                                        case 7:
                                            return i = e.sent, e.abrupt("return", i);
                                        case 11:
                                            return e.prev = 11, e.t0 = e.catch(4), console.error(e.t0.message), a({
                                                status: "STAKING_INITIATE_WITHDRAWAL_FAIL"
                                            }), e.abrupt("return", e.t0.message);
                                        case 16:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e, this, [
                                    [4, 11]
                                ])
                            })));
                            return function(t, a) {
                                return e.apply(this, arguments)
                            }
                        }()
                    }, {
                        key: "stakingExecuteWithdrawal",
                        value: function() {
                            var e = Object(B.a)(j.a.mark((function e(t) {
                                var a, n;
                                return j.a.wrap((function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            return a = new this.web3.eth.Contract(kt, Ie.STAKING_CONTRACT_ADDRESS), e.prev = 1, e.next = 4, a.methods.withdraw().send({
                                                from: this.address
                                            }).on("transactionHash", (function(e) {
                                                t({
                                                    status: "STAKING_EXECUTE_WITHDRAWAL_SUBMIT",
                                                    txID: e
                                                })
                                            })).on("error", (function(e) {
                                                console.log(e), t({
                                                    status: "STAKING_EXECUTE_WITHDRAWAL_FAIL"
                                                })
                                            })).then((function(e) {
                                                !0 === e.status ? t({
                                                    status: "STAKING_EXECUTE_WITHDRAWAL_SUCCESS",
                                                    txID: e.transactionHash
                                                }) : t({
                                                    status: "STAKING_EXECUTE_WITHDRAWAL_FAIL"
                                                })
                                            })).catch((function(e) {
                                                console.log(e), t({
                                                    status: "STAKING_EXECUTE_WITHDRAWAL_FAIL"
                                                })
                                            }));
                                        case 4:
                                            return n = e.sent, e.abrupt("return", n);
                                        case 8:
                                            return e.prev = 8, e.t0 = e.catch(1), console.error(e.t0.message), t({
                                                status: "STAKING_EXECUTE_WITHDRAWAL_FAIL"
                                            }), e.abrupt("return", e.t0.message);
                                        case 13:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e, this, [
                                    [1, 8]
                                ])
                            })));
                            return function(t) {
                                return e.apply(this, arguments)
                            }
                        }()
                    }, {
                        key: "stakingExecuteWithdrawRewards",
                        value: function() {
                            var e = Object(B.a)(j.a.mark((function e(t) {
                                var a, n;
                                return j.a.wrap((function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            return a = new this.web3.eth.Contract(kt, Ie.STAKING_CONTRACT_ADDRESS), e.prev = 1, e.next = 4, a.methods.withdrawRewards().send({
                                                from: this.address
                                            }).on("transactionHash", (function(e) {
                                                t({
                                                    status: "STAKING_EXECUTE_WITHDRAW_REWARDS_SUBMIT",
                                                    txID: e
                                                })
                                            })).on("error", (function(e) {
                                                console.log(e), t({
                                                    status: "STAKING_EXECUTE_WITHDRAW_REWARDS_FAIL"
                                                })
                                            })).then((function(e) {
                                                !0 === e.status ? t({
                                                    status: "STAKING_EXECUTE_WITHDRAW_REWARDS_SUCCESS",
                                                    txID: e.transactionHash
                                                }) : t({
                                                    status: "STAKING_EXECUTE_WITHDRAW_REWARDS_FAIL"
                                                })
                                            })).catch((function(e) {
                                                console.log(e), t({
                                                    status: "STAKING_EXECUTE_WITHDRAW_REWARDS_FAIL"
                                                })
                                            }));
                                        case 4:
                                            return n = e.sent, e.abrupt("return", n);
                                        case 8:
                                            return e.prev = 8, e.t0 = e.catch(1), console.error(e.t0.message), t({
                                                status: "STAKING_EXECUTE_WITHDRAW_REWARDS_FAIL"
                                            }), e.abrupt("return", e.t0.message);
                                        case 13:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e, this, [
                                    [1, 8]
                                ])
                            })));
                            return function(t) {
                                return e.apply(this, arguments)
                            }
                        }()
                    }, {
                        key: "stakingRewards",
                        value: function() {
                            var e = Object(B.a)(j.a.mark((function e(t) {
                                var a, n;
                                return j.a.wrap((function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            return a = new this.web3.eth.Contract(kt, Ie.STAKING_CONTRACT_ADDRESS), e.prev = 1, e.next = 4, a.methods.stakeRewards().send({
                                                from: this.address
                                            }).on("transactionHash", (function(e) {
                                                t({
                                                    status: "STAKING_REWARDS_SUBMIT",
                                                    txID: e
                                                })
                                            })).on("error", (function(e) {
                                                console.log(e), t({
                                                    status: "STAKING_REWARDS_FAIL"
                                                })
                                            })).then((function(e) {
                                                !0 === e.status ? t({
                                                    status: "STAKING_REWARDS_SUCCESS",
                                                    txID: e.transactionHash
                                                }) : t({
                                                    status: "STAKING_REWARDS_FAIL"
                                                })
                                            })).catch((function(e) {
                                                console.log(e), t({
                                                    status: "STAKING_REWARDS_FAIL"
                                                })
                                            }));
                                        case 4:
                                            return n = e.sent, e.abrupt("return", n);
                                        case 8:
                                            return e.prev = 8, e.t0 = e.catch(1), console.error(e.t0.message), t({
                                                status: "STAKING_REWARDS_FAIL"
                                            }), e.abrupt("return", e.t0.message);
                                        case 13:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e, this, [
                                    [1, 8]
                                ])
                            })));
                            return function(t) {
                                return e.apply(this, arguments)
                            }
                        }()
                    }, {
                        key: "getStakingInfoWallet",
                        value: function() {
                            var e = Object(B.a)(j.a.mark((function e() {
                                var t, a;
                                return j.a.wrap((function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            return t = new this.web3.eth.Contract(kt, Ie.STAKING_CONTRACT_ADDRESS), e.next = 3, t.methods.infoWallet(this.address).call();
                                        case 3:
                                            return a = e.sent, e.abrupt("return", {
                                                stakedAmount: Object(W.BigNumber)(a[0].toString()).dividedBy(Math.pow(10, 18)).toString(),
                                                unstakedAmount: Object(W.BigNumber)(a[1].toString()).dividedBy(Math.pow(10, 18)).toString(),
                                                depositTimestamp: 1e3 * Number(a[2]),
                                                lastUnstakeTimestamp: 1e3 * Number(a[3]),
                                                withdrawTimestamp: 1e3 * Number(a[4]),
                                                rewardAmount: Object(W.BigNumber)(a[5].toString()).dividedBy(Math.pow(10, 18)).toFixed(18).replace(/\.?0+$/, "").toString()
                                            });
                                        case 5:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e, this)
                            })));
                            return function() {
                                return e.apply(this, arguments)
                            }
                        }()
                    }, {
                        key: "setKycTron",
                        value: function() {
                            var e = Object(B.a)(j.a.mark((function e(t, a) {
                                return j.a.wrap((function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            try {
                                                new this.web3.eth.Contract(Ct, Ie.BSC_KYC_ADDRESS).methods.setKyc(t).send({
                                                    from: this.address
                                                }).then((function(e) {
                                                    console.log(e), a({
                                                        status: "SET_KYC_SUCCESS"
                                                    })
                                                }))
                                            } catch (n) {
                                                console.error(n.message), a({
                                                    status: "SET_KYC_FAIL"
                                                })
                                            }
                                        case 1:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e, this)
                            })));
                            return function(t, a) {
                                return e.apply(this, arguments)
                            }
                        }()
                    }, {
                        key: "getKycAddress",
                        value: function() {
                            var e = Object(B.a)(j.a.mark((function e() {
                                var t, a;
                                return j.a.wrap((function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            return e.prev = 0, t = new this.web3.eth.Contract(Ct, Ie.BSC_KYC_ADDRESS), e.next = 4, t.methods.getKyc(this.address).call();
                                        case 4:
                                            return a = e.sent, e.abrupt("return", a);
                                        case 8:
                                            return e.prev = 8, e.t0 = e.catch(0), console.log(e.t0), e.abrupt("return", "0x0000000000000000000000000000000000000000");
                                        case 12:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e, this, [
                                    [0, 8]
                                ])
                            })));
                            return function() {
                                return e.apply(this, arguments)
                            }
                        }()
                    }]), e
                }(),
                Ot = function(e) {
                    console.log("contractInfoAllocation==>", e);
                    var t = [],
                        a = {
                            0: "PENDING",
                            1: "OPEN",
                            2: "CLOSED"
                        },
                        n = e[0],
                        r = e[1],
                        o = e[2],
                        i = e[3],
                        l = e[4];
                    if (n.length >= 2 && 0 === (n[0] ^ n[1])) {
                        for (var s = 0; s < n.length - 1; s++) {
                            var c = n[s];
                            if (c === n[s + 1]) {
                                var u = r[s] === r[s + 1] ? r[s] : "".concat(r[s], "-").concat(r[s + 1]),
                                    m = o[s] === o[s + 1] ? o[s] : "".concat(o[s], "-").concat(o[s + 1]),
                                    d = i[s + 1];
                                t.push({
                                    no: c,
                                    allocationAmount: u,
                                    timestamp: m,
                                    claimedAmount: i[s],
                                    status: a[l[s]],
                                    percentage: d
                                })
                            }
                        }
                        return {
                            layout: 2,
                            infoAllocation: t
                        }
                    }
                    for (var p = 0; p < n.length; p++) t.push({
                        no: n[p],
                        allocationAmount: r[p],
                        timestamp: parseInt(o[p]),
                        claimedAmount: i[p],
                        status: a[l[p]]
                    });
                    return {
                        layout: 1,
                        infoAllocation: t
                    }
                },
                Pt = function(e) {
                    var t = Object($.a)().t,
                        a = Object(s.b)(),
                        n = vt().login,
                        i = He(),
                        l = i.account,
                        c = i.library,
                        u = i.error,
                        m = Object(r.useCallback)((function(e) {
                            try {
                                n(e.connectorId), window.localStorage.setItem("connectorId", e.connectorId)
                            } catch (u) {
                                console.log(u)
                            }
                        }), []);
                    return Object(r.useEffect)((function() {
                        if (!u)
                            if (l && c && c.provider) {
                                var e = new At(c.provider, l);
                                a({
                                    type: D.ENABLE_WALLET_SUCCESS,
                                    data: e
                                })
                            } else;
                    }), [c, l, u]), o.a.createElement(o.a.Fragment, null, o.a.createElement("div", {
                        className: "modal fade",
                        id: "connectWalletModal",
                        tabIndex: "-1",
                        "aria-labelledby": "connectWalletModalLabel",
                        "aria-hidden": "true"
                    }, o.a.createElement("div", {
                        className: "modal-dialog modal-dialog-centered modal-sm"
                    }, o.a.createElement("div", {
                        className: "modal-content"
                    }, o.a.createElement("div", {
                        className: "modal-header"
                    }, o.a.createElement("h6", {
                        className: "modal-title",
                        id: "connectWalletModalLabel"
                    }, t("Connect to wallet")), o.a.createElement("button", {
                        type: "button",
                        className: "btn-close",
                        "data-bs-dismiss": "modal",
                        "aria-label": "Close"
                    })), o.a.createElement("div", {
                        className: "modal-body p-0"
                    }, z.map((function(e, t) {
                        if (!0 === e.enable) return o.a.createElement("div", {
                            key: t,
                            "data-bs-dismiss": "modal",
                            onClick: function() {
                                return m(e)
                            },
                            id: "wallet-connect-".concat(e.title.toLocaleLowerCase()),
                            className: "c-list border-b px-3 py-2 d-flex align-items-center"
                        }, o.a.createElement("img", {
                            src: e.icon,
                            width: "30px",
                            className: "me-2",
                            alt: "bscpad"
                        }), o.a.createElement("div", {
                            className: "text-white"
                        }, e.title))
                    })))))))
                },
                It = a(419),
                xt = a.n(It);
            var Dt = function(e) {
                    var t = Object($.a)().t,
                        a = Object(s.b)(),
                        n = function() {
                            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null,
                                t = o.a.useState(!1),
                                a = Object(de.a)(t, 2),
                                n = a[0],
                                r = a[1],
                                i = o.a.useCallback((function(e) {
                                    "string" === typeof e || "number" == typeof e ? (xt()(e.toString()), r(!0)) : (r(!1), console.error("Cannot copy typeof ".concat(typeof e, " to clipboard, must be a string or number.")))
                                }), []);
                            return o.a.useEffect((function() {
                                var t;
                                return n && e && (t = setTimeout((function() {
                                        return r(!1)
                                    }), e)),
                                    function() {
                                        clearTimeout(t)
                                    }
                            }), [n, e]), [n, i]
                        }(1e3),
                        r = Object(de.a)(n, 2),
                        i = r[0],
                        l = r[1],
                        c = He().account,
                        u = vt(),
                        m = (u.login, u.logout);
                    return o.a.createElement(o.a.Fragment, null, o.a.createElement("div", {
                        className: "modal fade ",
                        id: "walletModal",
                        tabIndex: "-1",
                        "aria-labelledby": "walletModalLabel",
                        "aria-hidden": "true"
                    }, o.a.createElement("div", {
                        className: "modal-dialog modal-md modal-dialog-centered"
                    }, o.a.createElement("div", {
                        className: "modal-content"
                    }, o.a.createElement("div", {
                        className: "modal-header"
                    }, o.a.createElement("h6", {
                        className: "modal-title",
                        id: "walletModalLabel"
                    }, t("Your wallet")), o.a.createElement("button", {
                        type: "button",
                        className: "btn-close",
                        "data-bs-dismiss": "modal",
                        "aria-label": "Close"
                    })), o.a.createElement("div", {
                        className: "modal-body"
                    }, o.a.createElement("div", {
                        className: "mb-3 text-center"
                    }, o.a.createElement("h5", {
                        style: {
                            fontSize: "17px",
                            wordBreak: "break-word"
                        },
                        className: "mb-2"
                    }, o.a.createElement("b", null, c)), o.a.createElement("a", {
                        href: "".concat(Ie.BSC_EXPLORER, "/address/").concat(c),
                        target: "_blank",
                        className: "text-warning d-inline-flex align-items-center me-4",
                        style: {
                            textDecoration: "none"
                        }
                    }, o.a.createElement("span", {
                        className: "me-1"
                    }, t("View on BscScan")), o.a.createElement("i", {
                        className: "mdi mdi-open-in-new"
                    })), o.a.createElement("a", {
                        className: "text-warning d-inline-flex align-items-center",
                        href: "#",
                        onClick: function() {
                            return l(c)
                        },
                        style: {
                            textDecoration: "none"
                        }
                    }, o.a.createElement("span", {
                        className: "me-1"
                    }, t("Copy Address")), i ? o.a.createElement("i", {
                        className: "mdi mdi-check"
                    }) : o.a.createElement("i", {
                        className: "mdi mdi-content-copy"
                    }))), o.a.createElement("div", {
                        className: "text-center mt-4"
                    }, o.a.createElement("a", {
                        href: "#",
                        className: "btn btn-outline-primary",
                        onClick: function() {
                            m(), a({
                                type: D.LOG_OUT_WALLET_SUCCESS
                            }), window.location.reload()
                        },
                        "data-bs-dismiss": "modal"
                    }, t("Logout"))))))))
                },
                _t = function(e) {
                    return o.a.createElement(o.a.Fragment, null, o.a.createElement("div", {
                        className: "modal fade in",
                        id: "helpModal",
                        tabIndex: "-1",
                        "aria-labelledby": "helpModalLabel"
                    }, o.a.createElement("div", {
                        className: "modal-dialog modal-dialog-centered"
                    }, o.a.createElement("div", {
                        className: "modal-content modal-content modal-help"
                    }, o.a.createElement("div", {
                        className: "modal-header"
                    }, o.a.createElement("button", {
                        type: "button",
                        className: "btn-close text-white",
                        "data-bs-dismiss": "modal",
                        "aria-label": "Close"
                    })), o.a.createElement("div", {
                        className: "modal-body"
                    }, o.a.createElement("div", {
                        className: "d-flex mb-3"
                    }, o.a.createElement("a", {
                        className: "btn btn-info me-2 w-100 text-white text-center",
                        href: "https://link.trustwallet.com/open_url?coin_id=56&url=https://bscpad.com/"
                    }, "Open with ", o.a.createElement("img", {
                        src: "/images/trust_platform.png",
                        width: "30px",
                        className: "me-2",
                        alt: "bscpad"
                    }))), o.a.createElement("h2", {
                        className: "text-warning"
                    }, "How to Set Up and Use Trust Wallet for BSCPAD.COM"), o.a.createElement("h5", {
                        className: "mt-3"
                    }, "Setting up your wallet for Binance Smart Chain"), o.a.createElement("ul", {
                        className: "ps-0",
                        style: {
                            listStyle: "none"
                        }
                    }, o.a.createElement("li", null, "1). Download Trust Wallet. If you already have Trust Wallet, make sure your app is up to date."), o.a.createElement("li", null, "2). Complete ", o.a.createElement("a", {
                        href: "https://community.trustwallet.com/t/how-to-create-a-multi-coin-wallet/41",
                        target: "_blank"
                    }, "basic setup of a multi-coin wallet"), ". Remember to save your backup phrases."), o.a.createElement("li", null, "3). Go to your Smart Chain wallet and press receive to find your address"), o.a.createElement("li", null, "4). That\u2019s it! You\u2019re ready to start using Binance Smart Chain")), o.a.createElement("h5", {
                        className: "mt-4"
                    }, "Using BSCPAD.COM in Trust Wallet"), o.a.createElement("ul", {
                        className: "ps-0",
                        style: {
                            listStyle: "none"
                        }
                    }, o.a.createElement("li", null, "5). For this part, iOS users will need the Dapp browser. Android users have the Dapp browser by default."), o.a.createElement("li", null, "6). Once you\u2019ve topped up your wallet, open the Dapp browser by pressing on the four squares at the bottom of the app.")), o.a.createElement("p", {
                        className: "text-center"
                    }, o.a.createElement("img", {
                        style: {
                            maxWidth: "97%"
                        },
                        className: "mx-auto",
                        src: "/images/help-1.png",
                        alt: "pscpad"
                    })), o.a.createElement("ul", {
                        className: "ps-0",
                        style: {
                            listStyle: "none"
                        }
                    }, o.a.createElement("li", null, "7). Input ", o.a.createElement("b", null, "bscpad.com")), o.a.createElement("li", null, "8). Change network to Binance smart chain"), o.a.createElement("li", null, "9). Use the Dapp and have fun!")), o.a.createElement("h5", {
                        className: "mt-5"
                    }, "Enable DApp Browser on Trust Wallet (iOS version)"), o.a.createElement("ul", {
                        className: "ps-0",
                        style: {
                            listStyle: "none"
                        }
                    }, o.a.createElement("li", null, o.a.createElement("p", null, "1). Open\xa0", o.a.createElement("b", null, "Safari Browser"), "\xa0and then type in the URL:\xa0", o.a.createElement("b", null, "trust://browser_enable"), ", then tap on\xa0", o.a.createElement("b", null, "Go")), o.a.createElement("p", null, o.a.createElement("img", {
                        style: {
                            maxWidth: "97%"
                        },
                        className: "mx-auto",
                        src: "/images/help-2.png",
                        alt: ""
                    }))), o.a.createElement("li", null, o.a.createElement("p", null, "2). A prompt will appear that will ask if you want to\xa0", o.a.createElement("b", null, "Open this page in \u201cTrust\u201d?"), ", tap on\xa0", o.a.createElement("b", null, "Open")), o.a.createElement("p", null, o.a.createElement("img", {
                        style: {
                            maxWidth: "97%"
                        },
                        className: "mx-auto",
                        src: "/images/help-3.png",
                        alt: ""
                    })), o.a.createElement("p", null, "The\xa0", o.a.createElement("b", null, "Trust Wallet"), "\xa0app will launch and the\xa0", o.a.createElement("b", null, "DApp\xa0browser"), "\xa0will be enabled"), o.a.createElement("p", null, o.a.createElement("img", {
                        style: {
                            maxWidth: "97%"
                        },
                        className: "mx-auto",
                        src: "/images/help-4.png",
                        alt: ""
                    })))), o.a.createElement("div", {
                        className: "d-flex mt-4"
                    }, o.a.createElement("a", {
                        className: "btn btn-info me-2 w-100 text-white text-center",
                        href: "https://link.trustwallet.com/open_url?coin_id=56&url=https://bscpad.com/"
                    }, "Open with ", o.a.createElement("img", {
                        src: "/images/trust_platform.png",
                        width: "30px",
                        className: "me-2"
                    }))))))))
                },
                jt = new(a(973))({
                    fullHost: "https://api.trongrid.io"
                }),
                Bt = function(e) {
                    var t = Object(s.b)(),
                        a = Object(s.c)((function(e) {
                            return Object(ue.get)(e, "utils.blocking", !1)
                        })),
                        n = Object(s.c)((function(e) {
                            return Object(ue.get)(e, "utils.web3Utils", null)
                        })),
                        i = Object(r.useState)(""),
                        l = Object(de.a)(i, 2),
                        c = l[0],
                        u = l[1],
                        m = Object(r.useState)(""),
                        d = Object(de.a)(m, 2),
                        p = d[0],
                        h = d[1],
                        y = Object(r.useState)(!1),
                        E = Object(de.a)(y, 2),
                        g = E[0],
                        v = E[1],
                        w = Object(r.useState)(2),
                        T = Object(de.a)(w, 2),
                        S = T[0],
                        N = T[1],
                        k = Object(r.useState)(0),
                        C = Object(de.a)(k, 2),
                        A = (C[0], C[1], Object(r.useState)(!0)),
                        O = Object(de.a)(A, 2),
                        P = (O[0], O[1]);
                    Object(r.useEffect)((function() {
                        n && n.getKycAddress().then((function(e) {
                            if ("0x0000000000000000000000000000000000000000" !== e && "" !== e) {
                                var t = jt.address.fromHex(e);
                                console.log(t), u(t), N(1)
                            } else N(2)
                        }))
                    }), [n, a]);
                    return o.a.createElement(o.a.Fragment, null, o.a.createElement("div", {
                        className: "modal fade ",
                        id: "setKycModal",
                        tabIndex: "-1",
                        "aria-labelledby": "walletModalLabel",
                        "aria-hidden": "true"
                    }, o.a.createElement("div", {
                        className: "modal-dialog modal-md modal-dialog-centered modal-md"
                    }, o.a.createElement("div", {
                        className: "modal-content"
                    }, o.a.createElement("div", {
                        className: "modal-header"
                    }, o.a.createElement("h6", {
                        className: "modal-title",
                        id: "walletModalLabel"
                    }, "Synchronize TRONPad KYC"), o.a.createElement("button", {
                        type: "button",
                        className: "btn-close",
                        "data-bs-dismiss": "modal",
                        "aria-label": "Close",
                        onClick: function() {
                            N("0x0000000000000000000000000000000000000000" !== c && "" !== c ? 1 : 2)
                        }
                    })), o.a.createElement("div", {
                        className: "modal-body"
                    }, o.a.createElement("div", {
                        className: "mb-3"
                    }, 2 === S && o.a.createElement("div", null, o.a.createElement("p", null, "Please input your TRON wallet address below to automatically synchronize your KYC approved status to participate in IDOs on TRONPad."), o.a.createElement("div", {
                        className: "p-m-warning d-flex"
                    }, o.a.createElement("i", {
                        className: "fas fa-info-circle "
                    }), o.a.createElement("div", null, "After Synchronizing, please wait up to 5-10 minutes for your KYC status to update on TRONPad. If you have any issues please contact ", o.a.createElement("a", {
                        className: "text-warning",
                        href: "mailto:support@bscpad.com"
                    }, o.a.createElement("span", null, "Support")), ".")), o.a.createElement("input", {
                        type: "text",
                        className: "input-tron-address form-control ms-2 me-1",
                        placeholder: "Input your TRON Address",
                        autoFocus: !0,
                        onChange: function(e) {
                            return function(e) {
                                var t = e.target.value;
                                jt.isAddress(t) ? (h(t), v(!0), P(!1)) : (v(!1), P(!0))
                            }(e)
                        }
                    })), 1 === S && o.a.createElement("div", {
                        className: "tex-center",
                        style: {
                            textAlign: "center"
                        }
                    }, o.a.createElement("p", {
                        className: "mb-2"
                    }, "The TRON address below is currently synchronized to your BSCPAD KYC status."), o.a.createElement("p", {
                        className: "mb-2"
                    }, "Do you wish to update this address?"), o.a.createElement("p", {
                        className: "text-warning"
                    }, c))), 2 === S && o.a.createElement("div", {
                        className: "text-center mt-4 py-3"
                    }, o.a.createElement("button", {
                        disabled: !g,
                        className: "btn btn-primary",
                        onClick: function() {
                            if (n) {
                                t({
                                    type: D.REQUEST_SUBMIT
                                });
                                var e = function(e) {
                                    return ("0x" + jt.address.toHex(e).substring(2)).toLowerCase()
                                }(p);
                                n.setKycTron(e, (function(e) {
                                    "SET_KYC_SUCCESS" == e.status && (v(!1), t({
                                        type: D.REQUEST_DONE
                                    }), t({
                                        type: D.ALERT_SUCCESS,
                                        message: b
                                    }), N(1)), "SET_KYC_FAIL" == e.status && (v(!1), t({
                                        type: D.REQUEST_DONE
                                    }), t({
                                        type: D.ALERT_FAILS,
                                        message: f
                                    }), N(2))
                                }))
                            }
                        },
                        "data-bs-dismiss": "modal"
                    }, "Synchronize")), 1 === S && o.a.createElement("div", {
                        className: "text-center mt-4 py-3"
                    }, o.a.createElement("button", {
                        className: "btn btn-primary",
                        onClick: function() {
                            N(2)
                        }
                    }, "\xa0\xa0\xa0Update\xa0\xa0\xa0")))))))
                };
            var Rt = a(433);

            function Lt() {
                var e = Object($.a)().t,
                    t = (new Date).getFullYear();
                return o.a.createElement(o.a.Fragment, null, o.a.createElement("div", {
                    className: "pp-footer"
                }, o.a.createElement("div", {
                    className: "container"
                }, o.a.createElement("div", {
                    className: "d-flex justify-content-between"
                }, o.a.createElement("div", {
                    className: "text-muted"
                }, " ", e("Copyright \xa9"), " ", t, ". ", e("All Rights Reserved by BSCPad")), o.a.createElement("div", {
                    className: "text-muted"
                }, " v", Rt.version), o.a.createElement("div", {
                    className: "text-end pp-footer-link"
                }, o.a.createElement(V.a, {
                    target: "_blank",
                    to: T
                }, e("Privacy Policy"), " "), o.a.createElement(V.a, {
                    target: "_blank",
                    to: w
                }, e("Terms of Use"), " "))))), o.a.createElement(Pt, null), o.a.createElement(_t, null), o.a.createElement(Dt, null), o.a.createElement(Bt, null))
            }
            var Wt, Ut = a(434),
                Ft = function(e) {
                    var t = e.children,
                        a = (Object(ze.a)(e, ["children"]), Object(s.c)((function(e) {
                            return Object(ue.get)(e, "utils.blocking", !1)
                        })));
                    return o.a.createElement(o.a.Fragment, null, o.a.createElement(Ut.a, {
                        tag: "div",
                        blocking: a
                    }, o.a.createElement(Ze, null), t, o.a.createElement(Lt, null)))
                },
                Mt = function(e) {
                    var t = e.component,
                        a = Object(ze.a)(e, ["component"]);
                    return o.a.createElement(c.a, Object.assign({}, a, {
                        render: function(e) {
                            return o.a.createElement(Ft, null, o.a.createElement(t, e))
                        }
                    }))
                },
                Yt = a(247),
                Gt = (a(1074), a(46)),
                Ht = a.n(Gt),
                Kt = function() {
                    var e = Object(B.a)(j.a.mark((function e() {
                        var t;
                        return j.a.wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    return e.next = 2, ye.a.get("".concat(Ie.BACKEND_URL).concat(u.GET_CALENDAR));
                                case 2:
                                    return t = e.sent, e.abrupt("return", {
                                        status: 200,
                                        data: t.data
                                    });
                                case 4:
                                case "end":
                                    return e.stop()
                            }
                        }), e)
                    })));
                    return function() {
                        return e.apply(this, arguments)
                    }
                }(),
                qt = function(e) {
                    var t = Object($.a)().t,
                        a = null === e || void 0 === e ? void 0 : e.data;
                    return o.a.createElement(o.a.Fragment, null, a ? o.a.createElement("div", {
                        className: "modal fade in",
                        id: "calendarItemModal",
                        tabIndex: "-1",
                        "aria-labelledby": "calendarItemModalLabel"
                    }, o.a.createElement("div", {
                        className: "modal-dialog modal-lg modal-dialog-centered"
                    }, o.a.createElement("div", {
                        className: "modal-content modal-content modal-help",
                        style: {
                            borderRadius: "20px"
                        }
                    }, o.a.createElement("div", {
                        className: "modal-header",
                        style: {
                            borderRadius: "20px 20px 0 0"
                        }
                    }, o.a.createElement("h4", {
                        className: "modal-title d-flex align-items-center",
                        id: "calendarItemModalLabel"
                    }, null === a || void 0 === a ? void 0 : a.name), o.a.createElement("button", {
                        type: "button",
                        className: "btn-close",
                        "data-bs-dismiss": "modal",
                        "aria-label": "Close"
                    })), o.a.createElement("div", {
                        className: "modal-body p-0",
                        style: {
                            borderRadius: "0 0 20px 20px"
                        }
                    }, o.a.createElement("div", {
                        className: "calendar-item mb-0",
                        style: {
                            borderRadius: 0,
                            boxShadow: "none"
                        }
                    }, o.a.createElement("div", {
                        className: "calendar-item-ido mb-3"
                    }, t("IDO Launch"), ": ", o.a.createElement("div", {
                        className: "d-block d-md-none"
                    }), o.a.createElement("b", {
                        className: "text-warning"
                    }, Pe()(a.start).utc().format("YYYY-MM-DD"))), o.a.createElement("div", {
                        className: "row"
                    }, o.a.createElement("div", {
                        className: "col-md-6 col-lg-4"
                    }, o.a.createElement("div", {
                        className: "calendar-item-icon",
                        style: {
                            overflow: "hidden",
                            height: "auto"
                        }
                    }, o.a.createElement("img", {
                        src: null === a || void 0 === a ? void 0 : a.icon,
                        alt: ""
                    }))), o.a.createElement("div", {
                        className: "col-md-6 col-lg-8"
                    }, o.a.createElement("div", {
                        className: "calendar-item-times mt-md-0 mt-3"
                    }, o.a.createElement("div", {
                        className: "calendar-item-time calendar-item-staking"
                    }, o.a.createElement("span", null, o.a.createElement("i", {
                        className: "mdi mdi-calendar-outline me-1"
                    }), t("Staking Eligibility Deadline"), ":"), " ", o.a.createElement("b", null, a.staking)), o.a.createElement("div", {
                        className: "calendar-item-time calendar-item-allocation"
                    }, o.a.createElement("span", null, o.a.createElement("i", {
                        className: "mdi mdi-calendar-outline me-1 text text-capitalize"
                    }), t("Allocation round"), ":"), " ", o.a.createElement("b", null, a.allocation)), o.a.createElement("div", {
                        className: "calendar-item-time calendar-item-fcfs"
                    }, o.a.createElement("span", null, o.a.createElement("i", {
                        className: "mdi mdi-calendar-outline me-1 text-capitalize"
                    }), t("FCFS Round"), ":"), " ", o.a.createElement("b", null, a.fcfs)))))))))) : o.a.createElement(o.a.Fragment, null))
                },
                zt = Object(Yt.b)(Pe.a),
                Jt = function(e) {
                    var t = Object(r.useState)(null),
                        a = Object(de.a)(t, 2),
                        n = a[0],
                        i = a[1],
                        l = Object(r.useState)([]),
                        s = Object(de.a)(l, 2),
                        c = s[0],
                        u = s[1];
                    Object(r.useEffect)((function() {
                        Kt().then((function(e) {
                            u(e.data)
                        }))
                    }), []);
                    var m = function() {
                            var e = Object(r.useState)([0, 0]),
                                t = Object(de.a)(e, 2),
                                a = t[0],
                                n = t[1];
                            return Object(r.useLayoutEffect)((function() {
                                function e() {
                                    n([window.innerWidth, window.innerHeight])
                                }
                                return window.addEventListener("resize", e), e(),
                                    function() {
                                        return window.removeEventListener("resize", e)
                                    }
                            }), []), a
                        }(),
                        d = Object(de.a)(m, 2),
                        p = d[0];
                    d[1];
                    return o.a.createElement("div", {
                        className: "pp-projects-page"
                    }, o.a.createElement("div", {
                        className: "py-4 mt-3"
                    }, o.a.createElement("div", {
                        className: "container"
                    }, o.a.createElement(Yt.a, {
                        components: {
                            event: function(e) {
                                var t = e.event;
                                return o.a.createElement("div", {
                                    className: "d-flex justify-content-center",
                                    style: {
                                        flexDirection: "column"
                                    }
                                }, o.a.createElement("div", {
                                    className: "calendar-item calendar-item-cal p-0 mb-0",
                                    style: {
                                        maxHeight: "155px"
                                    }
                                }, o.a.createElement("a", null, o.a.createElement("div", {
                                    className: "calendar-item-icon h-auto text-center",
                                    style: {
                                        borderRadius: 0
                                    }
                                }, o.a.createElement("img", {
                                    src: null === t || void 0 === t ? void 0 : t.icon,
                                    alt: ""
                                })))))
                            }
                        },
                        showMultiDayTimes: !1,
                        style: {
                            minHeight: p > 1400 ? "1200px" : p > 1200 ? "1150px" : p > 1024 ? "1000px" : p > 992 ? "950px" : p > 768 ? "850px" : "460px"
                        },
                        popup: !0,
                        localizer: zt,
                        culture: "es_us",
                        events: c,
                        startAccessor: "start",
                        endAccessor: "end",
                        onSelectEvent: function(e) {
                            i(e), window.setTimeout((function() {
                                Ht()("#btnViewDetail").trigger("click")
                            }), 400)
                        }
                    }))), o.a.createElement("button", {
                        type: "button",
                        className: "d-none",
                        id: "btnViewDetail",
                        "data-bs-toggle": "modal",
                        "data-bs-target": "#calendarItemModal"
                    }), o.a.createElement(qt, {
                        data: n
                    }))
                },
                Vt = function(e) {
                    var t = Object($.a)().t,
                        a = Object(s.b)(),
                        n = Object(r.useState)(1),
                        i = Object(de.a)(n, 2),
                        l = i[0],
                        c = i[1],
                        u = Object(s.c)((function(e) {
                            return Object(ue.get)(e, "utils.isConnectWallet", !1)
                        })),
                        m = Object(s.c)((function(e) {
                            return Object(ue.get)(e, "utils.web3Utils", null)
                        })),
                        d = He(),
                        p = d.account,
                        h = (d.library, Object(s.c)((function(e) {
                            return Object(ue.get)(e, "wallet.stakingInfo", {})
                        }))),
                        b = Object(s.c)((function(e) {
                            return Object(ue.get)(e, "wallet.stakingWalletInfo", {})
                        })),
                        f = Object(r.useState)(!1),
                        y = Object(de.a)(f, 2),
                        E = y[0],
                        g = y[1],
                        v = Object(r.useState)(!1),
                        T = Object(de.a)(v, 2),
                        S = T[0],
                        N = T[1],
                        k = Object(r.useState)(""),
                        C = Object(de.a)(k, 2),
                        A = C[0],
                        O = C[1],
                        P = Object(r.useState)(0),
                        I = Object(de.a)(P, 2),
                        x = I[0],
                        _ = I[1],
                        j = Object(r.useState)(!1),
                        B = Object(de.a)(j, 2),
                        R = B[0],
                        L = B[1];
                    Object(r.useEffect)((function() {
                        W()
                    }), [W, l]), Object(r.useEffect)((function() {
                        m && p && m.web3.eth.getBalance(p).then((function(e) {
                            _(e / Math.pow(10, 18))
                        }))
                    }), [m, p]), Object(r.useEffect)((function() {
                        E && u && x > 0 && !h.isStakingPaused && b.withdrawTimestamp > 0 && b.withdrawTimestamp <= (new Date).getTime() ? N(!0) : N(!1)
                    }), [E, u, x, h, b]);

                    function W() {
                        Ht()("#withdraw .bs-stepper-header .step").removeClass("active"), Ht()("#withdraw .bs-stepper-header .line").removeClass("active");
                        for (var e = 1; e <= 3; e++) e <= l && (Ht()("#withdraw #withdrawButtonStep" + e).addClass("active"), Ht()("#withdraw #withdrawLineStep" + (e - 1)).addClass("active"));
                        Ht()("#withdraw .bs-stepper-content").hide(), Ht()("#withdraw #WithdrawStep" + l).show()
                    }
                    return o.a.createElement("div", {
                        className: "tab-pane fade",
                        id: "withdraw",
                        role: "tabpanel",
                        "aria-labelledby": "withdraw-tab"
                    }, o.a.createElement("div", {
                        className: "mt-3 mb-4 d-flex justify-content-center align-items-center"
                    }, o.a.createElement("h3", {
                        className: "p-tab-title mb-0"
                    }, t("Withdraw your BSCPAD"))), o.a.createElement("div", {
                        className: "row justify-content-center mb-4"
                    }, o.a.createElement("div", {
                        className: "col-lg-6"
                    }, o.a.createElement("div", {
                        className: "bs-stepper w-100"
                    }, o.a.createElement("div", {
                        className: "bs-stepper-header",
                        role: "tablist"
                    }, o.a.createElement("div", {
                        className: "step active",
                        id: "withdrawButtonStep1"
                    }, o.a.createElement("button", {
                        type: "button",
                        className: "step-trigger"
                    }, o.a.createElement("span", {
                        className: "bs-stepper-circle"
                    }, o.a.createElement("i", {
                        className: "mdi mdi-format-list-checkbox"
                    })), o.a.createElement("span", {
                        className: "bs-stepper-label"
                    }, t("Checkpoints")))), o.a.createElement("div", {
                        className: "line",
                        id: "withdrawLineStep1"
                    }), o.a.createElement("div", {
                        className: "step",
                        id: "withdrawButtonStep2"
                    }, o.a.createElement("button", {
                        type: "button",
                        className: "step-trigger"
                    }, o.a.createElement("span", {
                        className: "bs-stepper-circle"
                    }, o.a.createElement("i", {
                        className: "mdi mdi-currency-usd"
                    })), o.a.createElement("span", {
                        className: "bs-stepper-label"
                    }, t("Initialize Withdrawal")))), o.a.createElement("div", {
                        className: "line",
                        id: "withdrawLineStep2"
                    }), o.a.createElement("div", {
                        className: "step",
                        id: "withdrawButtonStep3"
                    }, o.a.createElement("button", {
                        type: "button",
                        className: "step-trigger"
                    }, o.a.createElement("span", {
                        className: "bs-stepper-circle"
                    }, o.a.createElement("i", {
                        className: "mdi mdi-check"
                    })), o.a.createElement("span", {
                        className: "bs-stepper-label"
                    }, t("Confirmation")))))))), o.a.createElement("div", {
                        className: "row justify-content-center"
                    }, o.a.createElement("div", {
                        className: "col-lg-12"
                    }, o.a.createElement("div", {
                        className: "p-sidebar-card p-sidebar-card-steps"
                    }, o.a.createElement("div", {
                        className: "p-sidebar-card-body"
                    }, o.a.createElement("div", {
                        className: "bs-stepper-content",
                        id: "WithdrawStep1"
                    }, o.a.createElement("div", {
                        className: "text-center"
                    }, o.a.createElement("h4", null, t("Checkpoints")), o.a.createElement("p", null, t("The following conditions must be met to proceed"), ":")), o.a.createElement("div", {
                        className: "row mt-4 d-flex justify-content-center"
                    }, o.a.createElement("div", {
                        className: "col-lg-3 col-md-6 mb-lg-0 mb-3"
                    }, o.a.createElement("div", {
                        className: u ? "p-select-card mb-4 selected" : "p-select-card mb-4"
                    }, o.a.createElement("div", {
                        className: "p-select-card-title"
                    }, o.a.createElement("b", null, t("Connected with MetaMask"))), o.a.createElement("div", {
                        className: "p-select-card-description"
                    }, t('If not connected, click the "Connect Wallet" button in the top right corner')))), o.a.createElement("div", {
                        className: "col-lg-3 col-md-6 mb-lg-0 mb-3"
                    }, o.a.createElement("div", {
                        className: b.withdrawTimestamp > 0 && b.withdrawTimestamp <= (new Date).getTime() ? "p-select-card mb-4 selected" : "p-select-card mb-4"
                    }, o.a.createElement("div", {
                        className: "p-select-card-title"
                    }, o.a.createElement("b", null, t("7 day waiting period elapsed"))), o.a.createElement("div", {
                        className: "p-select-card-description"
                    }))), o.a.createElement("div", {
                        className: "col-lg-3 col-md-6 mb-lg-0 mb-3"
                    }, o.a.createElement("div", {
                        className: x > 0 ? "p-select-card mb-4 selected" : "p-select-card mb-4"
                    }, o.a.createElement("div", {
                        className: "p-select-card-title"
                    }, o.a.createElement("b", null, t("BNB available in wallet"))), o.a.createElement("div", {
                        className: "p-select-card-description"
                    }, t("BNB is required to pay transaction fees on the Binance Smart Chain network."), o.a.createElement("br", null), t("BNB Balance"), ": ", je.formatNumberDownRoundWithExtractMax(x, 4)))), o.a.createElement("div", {
                        className: "col-lg-3 col-md-6 mb-lg-0 mb-3"
                    }, o.a.createElement("div", {
                        className: b.withdrawTimestamp > 0 ? "p-select-card mb-4 selected" : "p-select-card mb-4"
                    }, o.a.createElement("div", {
                        className: "p-select-card-title"
                    }, o.a.createElement("b", null, t("You have Unstaked your BSCPAD"))), o.a.createElement("div", {
                        className: "p-select-card-description"
                    })))), o.a.createElement("div", {
                        className: "mt-4 text-center"
                    }, o.a.createElement("div", {
                        className: "form-check"
                    }, o.a.createElement("input", {
                        className: "form-check-input float-none me-1",
                        type: "checkbox",
                        defaultValue: !0,
                        id: "flexCheckDefault",
                        onChange: function() {
                            return g(!E)
                        }
                    }), o.a.createElement("label", {
                        className: "form-check-label",
                        htmlFor: "flexCheckDefault"
                    }, t("I have read the"), "\xa0", o.a.createElement(V.a, {
                        target: "_blank",
                        to: w
                    }, " ", t("Terms and Conditions"), " "))))), o.a.createElement("div", {
                        className: "bs-stepper-content",
                        id: "WithdrawStep2"
                    }, o.a.createElement("div", {
                        className: "text-center"
                    }, o.a.createElement("h4", null, t("Confirm Withdrawal")), o.a.createElement("p", null, t("In this step, you complete the transaction that withdraws your BSCPAD tokens")))), o.a.createElement("div", {
                        className: "bs-stepper-content",
                        id: "WithdrawStep3"
                    }, o.a.createElement("div", {
                        className: "text-center"
                    }, o.a.createElement("div", {
                        className: "text-warning"
                    }, o.a.createElement("i", {
                        className: "mdi mdi-check",
                        style: {
                            fontSize: "50px"
                        }
                    })), o.a.createElement("h4", null, t("Confirmed")), o.a.createElement("p", null, t("You have withdrawn your BSCPAD tokens."), o.a.createElement("br", null), t("If desired, you may check Binance Smart Chain to confirm the transaction.")), o.a.createElement("p", null, o.a.createElement("a", {
                        className: "p-address",
                        href: "".concat(Ie.BSC_EXPLORER, "/tx/").concat(A),
                        target: "blank"
                    }, A)))))))), o.a.createElement("div", {
                        className: "mb-3 mt-4 text-center step-buttons"
                    }, R ? o.a.createElement(o.a.Fragment, null, o.a.createElement("button", {
                        onClick: function() {
                            return c(1), void L(!1)
                        },
                        type: "button",
                        className: "btn btn-primary btn-round  me-3 px-5"
                    }, t("Done"))) : o.a.createElement(o.a.Fragment, null, o.a.createElement("button", {
                        onClick: function() {
                            1 != l && c(l - 1)
                        },
                        type: "button",
                        disabled: !S || 1 === l,
                        className: "btn btn-primary btn-round btn-back-step me-3 px-5"
                    }, o.a.createElement("i", {
                        className: "mdi mdi-arrow-left me-2"
                    }), t("Previous")), o.a.createElement("button", {
                        onClick: function() {
                            return function() {
                                if (2 === l) m && (a({
                                    type: D.REQUEST_SUBMIT
                                }), m.stakingExecuteWithdrawal((function(e) {
                                    "STAKING_EXECUTE_WITHDRAWAL_SUCCESS" === e.status && (a({
                                        type: D.REQUEST_DONE
                                    }), L(!0), O(e.txID), c(3)), "STAKING_EXECUTE_WITHDRAWAL_FAIL" === e.status && (a({
                                        type: D.REQUEST_DONE
                                    }), a({
                                        type: D.ALERT_FAILS,
                                        message: t("Withdraw stake fail")
                                    }))
                                })));
                                else {
                                    if (3 == l) return;
                                    c(l + 1)
                                }
                            }()
                        },
                        type: "button",
                        disabled: !S || 3 === l,
                        className: "btn btn-primary btn-round btn-next-step px-5"
                    }, t("Next"), o.a.createElement("i", {
                        className: "mdi mdi-arrow-right ms-2"
                    })))))
                },
                Xt = a(1105),
                Qt = function(e) {
                    var t = Object($.a)().t,
                        a = Object(s.b)(),
                        n = Object(s.c)((function(e) {
                            return Object(ue.get)(e, "utils.isConnectWallet", !1)
                        })),
                        i = Object(s.c)((function(e) {
                            return Object(ue.get)(e, "utils.web3Utils", null)
                        })),
                        l = He(),
                        c = l.account,
                        u = (l.library, Object(s.c)((function(e) {
                            return Object(ue.get)(e, "wallet.stakingInfo", {})
                        }))),
                        m = Object(s.c)((function(e) {
                            return Object(ue.get)(e, "wallet.stakingWalletInfo", {})
                        })),
                        d = Object(s.c)((function(e) {
                            return Object(ue.get)(e, "wallet.bnbBalance", 0)
                        })),
                        p = Object(s.c)((function(e) {
                            return Object(ue.get)(e, "wallet.bscpadBalance", 0)
                        })),
                        h = Object(r.useState)(!1),
                        b = Object(de.a)(h, 2),
                        f = b[0],
                        y = b[1],
                        E = Object(r.useState)("0"),
                        g = Object(de.a)(E, 2),
                        v = g[0],
                        T = g[1],
                        S = Object(r.useState)(!1),
                        N = Object(de.a)(S, 2),
                        k = N[0],
                        C = N[1],
                        A = Object(r.useState)(1),
                        O = Object(de.a)(A, 2),
                        P = O[0],
                        I = O[1],
                        x = Object(r.useState)(!1),
                        _ = Object(de.a)(x, 2),
                        R = _[0],
                        L = _[1],
                        U = Object(r.useState)(""),
                        F = Object(de.a)(U, 2),
                        M = F[0],
                        Y = F[1],
                        G = Object(r.useState)(!1),
                        H = Object(de.a)(G, 2),
                        K = H[0],
                        q = H[1];
                    Object(r.useEffect)((function() {
                        1 === P && (f && n && !u.isStakingPaused && parseFloat(p) > 0 && d > 0 && 0 === m.withdrawTimestamp ? L(!0) : L(!1))
                    }), [f, n, d, p, u, m, P]), Object(r.useEffect)((function() {
                        J()
                    }), [P]);
                    var z = function() {
                            var e = Object(B.a)(j.a.mark((function e() {
                                return j.a.wrap((function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            if (5 !== P) {
                                                e.next = 2;
                                                break
                                            }
                                            return e.abrupt("return");
                                        case 2:
                                            if (1 !== P || 0 !== parseFloat(v)) {
                                                e.next = 6;
                                                break
                                            }
                                            return L(!1), I(P + 1), e.abrupt("return");
                                        case 6:
                                            3 === P ? i && (a({
                                                type: D.REQUEST_SUBMIT
                                            }), i.approve({
                                                tokenContractAddress: u.tokenAddr,
                                                contractAddress: Ie.STAKING_CONTRACT_ADDRESS,
                                                amount: k ? p : v
                                            }, (function(e) {
                                                "APPROVED" === e.status && (a({
                                                    type: D.REQUEST_DONE
                                                }), a({
                                                    type: D.ALERT_SUCCESS,
                                                    message: t("Approve Tokens successfully!")
                                                }), I(4)), "APPROVE_FAILS" === e.status && (a({
                                                    type: D.REQUEST_DONE
                                                }), a({
                                                    type: D.ALERT_FAILS,
                                                    message: t("Failed to Approve Tokens!")
                                                }))
                                            }))) : 4 === P ? i && (a({
                                                type: D.REQUEST_SUBMIT
                                            }), i.stakingDeposit({
                                                amount: k ? p : v
                                            }, (function(e) {
                                                "STAKING_DEPOSIT_SUCCESS" === e.status && (a({
                                                    type: D.REQUEST_DONE
                                                }), q(!0), Y(e.txID), I(5)), "STAKING_DEPOSIT_FAIL" === e.status && (a({
                                                    type: D.REQUEST_DONE
                                                }), a({
                                                    type: D.ALERT_FAILS,
                                                    message: t("Deposit stake fail!")
                                                }))
                                            }))) : I(P + 1);
                                        case 7:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e)
                            })));
                            return function() {
                                return e.apply(this, arguments)
                            }
                        }(),
                        J = function() {
                            Ht()("#stake .bs-stepper-header .step").removeClass("active"), Ht()("#stake .bs-stepper-header .line").removeClass("active");
                            for (var e = 1; e <= 5; e++) e <= P && (Ht()("#stake #swapButtonStep" + e).addClass("active"), Ht()("#stake #swapLineStep" + (e - 1)).addClass("active"));
                            Ht()("#stake .bs-stepper-content").hide(), Ht()("#stake #SwapStep" + P).show()
                        };
                    return o.a.createElement("div", {
                        className: "tab-pane fade show active",
                        id: "stake",
                        role: "tabpanel",
                        "aria-labelledby": "stake-tab"
                    }, o.a.createElement("div", {
                        className: "mt-3 mb-4 d-flex justify-content-center align-items-center"
                    }, o.a.createElement("h3", {
                        className: "p-tab-title mb-0"
                    }, t("Stake your BSCPAD"))), o.a.createElement("div", {
                        className: "row justify-content-center mb-4"
                    }, o.a.createElement("div", {
                        className: "col-lg-10"
                    }, o.a.createElement("div", {
                        className: "bs-stepper w-100"
                    }, o.a.createElement("div", {
                        className: "bs-stepper-header",
                        role: "tablist"
                    }, o.a.createElement("div", {
                        className: "step active",
                        id: "swapButtonStep1"
                    }, o.a.createElement("button", {
                        type: "button",
                        className: "step-trigger"
                    }, o.a.createElement("span", {
                        className: "bs-stepper-circle"
                    }, o.a.createElement("i", {
                        className: "mdi mdi-format-list-checkbox"
                    })), o.a.createElement("span", {
                        className: "bs-stepper-label"
                    }, t("Checkpoints")))), o.a.createElement("div", {
                        className: "line",
                        id: "swapLineStep1"
                    }), o.a.createElement("div", {
                        className: "step",
                        id: "swapButtonStep2"
                    }, o.a.createElement("button", {
                        type: "button",
                        className: "step-trigger"
                    }, o.a.createElement("span", {
                        className: "bs-stepper-circle"
                    }, o.a.createElement("i", {
                        className: "mdi mdi-currency-usd"
                    })), o.a.createElement("span", {
                        className: "bs-stepper-label"
                    }, t("Amount to Stake")))), o.a.createElement("div", {
                        className: "line",
                        id: "swapLineStep2"
                    }), o.a.createElement("div", {
                        className: "step",
                        id: "swapButtonStep3"
                    }, o.a.createElement("button", {
                        type: "button",
                        className: "step-trigger"
                    }, o.a.createElement("span", {
                        className: "bs-stepper-circle"
                    }, o.a.createElement("i", {
                        className: "mdi mdi-account-check-outline"
                    })), o.a.createElement("span", {
                        className: "bs-stepper-label"
                    }, t("Pre-authorization")))), o.a.createElement("div", {
                        className: "line",
                        id: "swapLineStep3"
                    }), o.a.createElement("div", {
                        className: "step",
                        id: "swapButtonStep4"
                    }, o.a.createElement("button", {
                        type: "button",
                        className: "step-trigger"
                    }, o.a.createElement("span", {
                        className: "bs-stepper-circle"
                    }, o.a.createElement("i", {
                        className: "mdi mdi-shield-account-outline"
                    })), o.a.createElement("span", {
                        className: "bs-stepper-label"
                    }, t("Confirm")))), o.a.createElement("div", {
                        className: "line",
                        id: "swapLineStep4"
                    }), o.a.createElement("div", {
                        className: "step",
                        id: "swapButtonStep5"
                    }, o.a.createElement("button", {
                        type: "button",
                        className: "step-trigger"
                    }, o.a.createElement("span", {
                        className: "bs-stepper-circle"
                    }, o.a.createElement("i", {
                        className: "mdi mdi-check"
                    })), o.a.createElement("span", {
                        className: "bs-stepper-label"
                    }, t("Confirmation")))))))), o.a.createElement("div", {
                        className: "row justify-content-center"
                    }, o.a.createElement("div", {
                        className: "col-lg-12"
                    }, o.a.createElement("div", {
                        className: "p-sidebar-card p-sidebar-card-steps"
                    }, o.a.createElement("div", {
                        className: "p-sidebar-card-body"
                    }, o.a.createElement("div", {
                        className: "bs-stepper-content",
                        id: "SwapStep1"
                    }, o.a.createElement("div", {
                        className: "text-center"
                    }, o.a.createElement("h4", null, t("Checkpoints")), o.a.createElement("p", null, t("The following conditions must be met to proceed"), ":")), o.a.createElement("div", {
                        className: "row mt-4 d-flex justify-content-center"
                    }, o.a.createElement("div", {
                        className: "col-lg-3 col-md-6 mb-lg-0 mb-3"
                    }, o.a.createElement("div", {
                        className: n ? "p-select-card mb-4 selected" : "p-select-card mb-4"
                    }, o.a.createElement("div", {
                        className: "p-select-card-title"
                    }, o.a.createElement("b", null, t("Connected with MetaMask"))), o.a.createElement("div", {
                        className: "p-select-card-description"
                    }, t('If not connected, click the "Connect Wallet" button in the top right corner')))), o.a.createElement("div", {
                        className: "col-lg-3 col-md-6 mb-lg-0 mb-3"
                    }, o.a.createElement("div", {
                        className: parseFloat(p) > 0 ? "p-select-card mb-4 selected" : "p-select-card mb-4"
                    }, o.a.createElement("div", {
                        className: "p-select-card-title"
                    }, o.a.createElement("b", null, " ", t("BSCPAD available to deposit"))), o.a.createElement("div", {
                        className: "p-select-card-description"
                    }, t("Current Balance"), ": ", je.formatNumberDownRoundWithExtractMax(p, 4)))), o.a.createElement("div", {
                        className: "col-lg-3 col-md-6 mb-lg-0 mb-3"
                    }, o.a.createElement("div", {
                        className: d > 0 ? "p-select-card mb-4 selected" : "p-select-card mb-4"
                    }, o.a.createElement("div", {
                        className: "p-select-card-title"
                    }, o.a.createElement("b", null, t("BNB available in wallet"))), o.a.createElement("div", {
                        className: "p-select-card-description"
                    }, t("BNB is required to pay transaction fees on the Binance Smart Chain network."), o.a.createElement("br", null), t("BNB Balance"), ": ", je.formatNumberDownRoundWithExtractMax(d, 4)))), o.a.createElement("div", {
                        className: "col-lg-3 col-md-6 mb-lg-0 mb-3"
                    }, o.a.createElement("div", {
                        className: 0 === m.withdrawTimestamp ? "p-select-card mb-4 selected" : "p-select-card mb-4"
                    }, o.a.createElement("div", {
                        className: "p-select-card-title"
                    }, o.a.createElement("b", null, t("Eligible to stake"))), o.a.createElement("div", {
                        className: "p-select-card-description"
                    }, t("You cannot stake if you have an active BSCPAD unstake/withdrawal request"))))), o.a.createElement("div", {
                        className: "mt-4 text-center"
                    }, o.a.createElement("div", {
                        className: "form-check"
                    }, o.a.createElement("input", {
                        className: "form-check-input float-none me-1",
                        type: "checkbox",
                        defaultValue: !0,
                        id: "flexCheckDefault",
                        onChange: function() {
                            return y(!f)
                        }
                    }), o.a.createElement("label", {
                        className: "form-check-label",
                        htmlFor: "flexCheckDefault"
                    }, t("I have read the"), "\xa0", o.a.createElement(V.a, {
                        target: "_blank",
                        to: w
                    }, t("Terms and Conditions"), " "))))), o.a.createElement("div", {
                        className: "bs-stepper-content",
                        id: "SwapStep2"
                    }, o.a.createElement("div", {
                        className: "text-center"
                    }, o.a.createElement("h4", null, t("Please enter the amount of BSCPAD you want to stake")), o.a.createElement("div", {
                        className: "mx-auto text-start mt-5",
                        style: {
                            maxWidth: "370px"
                        }
                    }, o.a.createElement("div", {
                        className: "p-form-group mb-1"
                    }, o.a.createElement("label", {
                        className: "form-label p-main-text"
                    }, t("Amount")), o.a.createElement("div", {
                        className: "p-input-group"
                    }, o.a.createElement("input", {
                        type: "number",
                        className: "form-control px-0",
                        placeholder: 0,
                        value: v,
                        onChange: function(e) {
                            return function(e) {
                                C(!1), je.isFloatFormatted(e.target.value, 4) && (T(e.target.value), Object(W.BigNumber)(e.target.value).lte(Object(W.BigNumber)(p)) && Object(W.BigNumber)(e.target.value).gt(Object(W.BigNumber)(0)) ? L(!0) : L(!1))
                            }(e)
                        }
                    }), o.a.createElement(Xt.a, {
                        onClick: function() {
                            T(je.formatNumberDownRound(p, 4)), L(!0), C(!0)
                        }
                    }, t("MAX")))), o.a.createElement("div", {
                        className: "d-flex align-items-start justify-content-between"
                    }, o.a.createElement("div", {
                        className: "font-14"
                    }, t("Balance"), ": ", o.a.createElement("b", {
                        className: "text-warning"
                    }, je.formatNumberDownRound(p, 4))), o.a.createElement("div", null))))), o.a.createElement("div", {
                        className: "bs-stepper-content",
                        id: "SwapStep3"
                    }, o.a.createElement("div", {
                        className: "text-center"
                    }, o.a.createElement("h4", null, t("Pre-authorization")), o.a.createElement("p", null, t("Required transaction 1 of 2")), o.a.createElement("p", null, t("In this step, you grant access to the staking smart contract to accept your BSCPAD"))), o.a.createElement("div", {
                        className: "text-center mt-4"
                    }, o.a.createElement("div", {
                        className: "p-progress-waiting"
                    }, o.a.createElement("div", {
                        className: "p-progress-percent",
                        style: {
                            width: "60%"
                        }
                    })), o.a.createElement("h4", null, t("Waiting for the transaction to complete")), o.a.createElement("p", null, t("Please wait for the transaction to confirm before proceeding.")), o.a.createElement("p", null, o.a.createElement("a", {
                        className: "p-address",
                        href: "".concat(Ie.BSC_EXPLORER, "/address/").concat(c),
                        target: "blank"
                    }, c)))), o.a.createElement("div", {
                        className: "bs-stepper-content",
                        id: "SwapStep4"
                    }, o.a.createElement("div", {
                        className: "text-center"
                    }, o.a.createElement("h4", null, t("Confirm")), o.a.createElement("p", null, t("Required transaction 2 of 2")), o.a.createElement("p", null, t("In this step, you deposit the tokens into the staking contract."), o.a.createElement("br", null), t("After this step, your tokens will be successfully staked.")))), o.a.createElement("div", {
                        className: "bs-stepper-content",
                        id: "SwapStep5"
                    }, o.a.createElement("div", {
                        className: "text-center"
                    }, o.a.createElement("div", {
                        className: "text-warning"
                    }, o.a.createElement("i", {
                        className: "mdi mdi-check",
                        style: {
                            fontSize: "50px"
                        }
                    })), o.a.createElement("h4", null, t("Success")), o.a.createElement("p", null, t("Congratulations! Your tokens are now staked."), o.a.createElement("br", null), t("If desired, you may check Binance Smart Chain to confirm the transaction.")), o.a.createElement("p", null, o.a.createElement("a", {
                        className: "p-address",
                        href: "".concat(Ie.BSC_EXPLORER, "/tx/").concat(M),
                        target: "blank"
                    }, M)))))))), o.a.createElement("div", {
                        className: "mb-3 mt-4 text-center step-buttons"
                    }, K ? o.a.createElement(o.a.Fragment, null, o.a.createElement("button", {
                        onClick: function() {
                            return T("0"), C(!0), I(1), void q(!1)
                        },
                        type: "button",
                        className: "btn btn-primary btn-round  me-3 px-5"
                    }, t("Done"))) : o.a.createElement(o.a.Fragment, null, "                ", o.a.createElement("button", {
                        onClick: function() {
                            1 !== P && I(P - 1)
                        },
                        type: "button",
                        disabled: !R || 1 === P,
                        className: "btn btn-primary btn-round btn-back-step me-3 px-5"
                    }, o.a.createElement("i", {
                        className: "mdi mdi-arrow-left me-2"
                    }), t("Previous")), o.a.createElement("button", {
                        onClick: function() {
                            return z()
                        },
                        type: "button",
                        disabled: !R || 5 === P,
                        className: "btn btn-primary btn-round btn-next-step px-5"
                    }, t("Next"), o.a.createElement("i", {
                        className: "mdi mdi-arrow-right ms-2"
                    })))))
                },
                $t = function(e) {
                    var t = Object($.a)().t,
                        a = Object(s.b)(),
                        n = Object(r.useState)(1),
                        i = Object(de.a)(n, 2),
                        l = i[0],
                        c = i[1],
                        u = Object(s.c)((function(e) {
                            return Object(ue.get)(e, "utils.isConnectWallet", !1)
                        })),
                        m = Object(s.c)((function(e) {
                            return Object(ue.get)(e, "utils.web3Utils", null)
                        })),
                        d = Object(s.c)((function(e) {
                            return Object(ue.get)(e, "wallet.stakingInfo", {})
                        })),
                        p = Object(s.c)((function(e) {
                            return Object(ue.get)(e, "wallet.stakingWalletInfo", {})
                        })),
                        h = Object(s.c)((function(e) {
                            return Object(ue.get)(e, "wallet.bnbBalance", 0)
                        })),
                        b = Object(r.useState)(!1),
                        f = Object(de.a)(b, 2),
                        y = f[0],
                        E = f[1],
                        v = Object(r.useState)(!1),
                        T = Object(de.a)(v, 2),
                        S = T[0],
                        N = T[1],
                        k = Object(r.useState)(""),
                        C = Object(de.a)(k, 2),
                        A = C[0],
                        O = C[1],
                        P = Object(r.useState)("0"),
                        I = Object(de.a)(P, 2),
                        x = I[0],
                        _ = I[1],
                        j = Object(r.useState)(!1),
                        B = Object(de.a)(j, 2),
                        R = B[0],
                        L = B[1],
                        U = Object(r.useState)(!1),
                        F = Object(de.a)(U, 2),
                        M = F[0],
                        Y = F[1];
                    Object(r.useEffect)((function() {
                        ! function() {
                            Ht()("#unStake .bs-stepper-header .step").removeClass("active"), Ht()("#unStake .bs-stepper-header .line").removeClass("active");
                            for (var e = 1; e <= 5; e++) e <= l && (Ht()("#unStake #unStakeButtonStep" + e).addClass("active"), Ht()("#unStake #unStakeLineStep" + (e - 1)).addClass("active"));
                            Ht()("#unStake .bs-stepper-content").hide(), Ht()("#unStake #UnStakeStep" + l).show()
                        }()
                    }), [l]), Object(r.useEffect)((function() {
                        2 === l && (y && u && !d.isStakingPaused && parseFloat(p.stakedAmount) > 0 && h > 0 && 0 === p.withdrawTimestamp ? N(!0) : N(!1)), 1 === l && N(!0)
                    }), [y, u, h, d, p, l]);
                    return o.a.createElement("div", {
                        className: "tab-pane fade",
                        id: "unStake",
                        role: "tabpanel",
                        "aria-labelledby": "unStake-tab"
                    }, o.a.createElement("div", {
                        className: "mt-3 mb-4 d-flex justify-content-center align-items-center"
                    }, o.a.createElement("h3", {
                        className: "p-tab-title mb-0"
                    }, t("Unstake your BSCSPAD"))), o.a.createElement("div", {
                        className: "row justify-content-center mb-4"
                    }, o.a.createElement("div", {
                        className: "col-lg-6"
                    }, o.a.createElement("div", {
                        className: "bs-stepper w-100"
                    }, o.a.createElement("div", {
                        className: "bs-stepper-header",
                        role: "tablist"
                    }, o.a.createElement("div", {
                        className: "step active",
                        id: "unStakeButtonStep1"
                    }, o.a.createElement("button", {
                        type: "button",
                        className: "step-trigger"
                    }, o.a.createElement("span", {
                        className: "bs-stepper-circle"
                    }, o.a.createElement("i", {
                        className: "mdi mdi-exclamation"
                    })), o.a.createElement("span", {
                        className: "bs-stepper-label"
                    }, t("Warning")))), o.a.createElement("div", {
                        className: "line",
                        id: "unStakeLineStep1"
                    }), o.a.createElement("div", {
                        className: "step",
                        id: "unStakeButtonStep2"
                    }, o.a.createElement("button", {
                        type: "button",
                        className: "step-trigger"
                    }, o.a.createElement("span", {
                        className: "bs-stepper-circle"
                    }, o.a.createElement("i", {
                        className: "mdi mdi-format-list-checkbox"
                    })), o.a.createElement("span", {
                        className: "bs-stepper-label"
                    }, t("Checkpoints")))), o.a.createElement("div", {
                        className: "line",
                        id: "unStakeLineStep2"
                    }), o.a.createElement("div", {
                        className: "step",
                        id: "unStakeButtonStep3"
                    }, o.a.createElement("button", {
                        type: "button",
                        className: "step-trigger"
                    }, o.a.createElement("span", {
                        className: "bs-stepper-circle"
                    }, o.a.createElement("i", {
                        className: "mdi mdi-currency-usd"
                    })), o.a.createElement("span", {
                        className: "bs-stepper-label"
                    }, t("Amount to Unstake")))), o.a.createElement("div", {
                        className: "line",
                        id: "unStakeLineStep3"
                    }), o.a.createElement("div", {
                        className: "step",
                        id: "unStakeButtonStep4"
                    }, o.a.createElement("button", {
                        type: "button",
                        className: "step-trigger"
                    }, o.a.createElement("span", {
                        className: "bs-stepper-circle"
                    }, o.a.createElement("i", {
                        className: "mdi mdi-currency-usd"
                    })), o.a.createElement("span", {
                        className: "bs-stepper-label"
                    }, t("Initialize Unstake")))), o.a.createElement("div", {
                        className: "line",
                        id: "unStakeLineStep4"
                    }), o.a.createElement("div", {
                        className: "step",
                        id: "unStakeButtonStep5"
                    }, o.a.createElement("button", {
                        type: "button",
                        className: "step-trigger"
                    }, o.a.createElement("span", {
                        className: "bs-stepper-circle"
                    }, o.a.createElement("i", {
                        className: "mdi mdi-check"
                    })), o.a.createElement("span", {
                        className: "bs-stepper-label"
                    }, t("Confirmation")))))))), o.a.createElement("div", {
                        className: "row justify-content-center"
                    }, o.a.createElement("div", {
                        className: "col-lg-12"
                    }, o.a.createElement("div", {
                        className: "p-sidebar-card p-sidebar-card-steps"
                    }, o.a.createElement("div", {
                        className: "p-sidebar-card-body"
                    }, o.a.createElement("div", {
                        className: "bs-stepper-content",
                        id: "UnStakeStep1"
                    }, o.a.createElement("div", {
                        className: "warning d-flex justify-content-center"
                    }, o.a.createElement("div", null, o.a.createElement("i", {
                        className: "fas fa-exclamation-triangle fa-4x"
                    })), o.a.createElement("div", null, o.a.createElement("p", null, t("After Unstaking, you must wait 7 days before you can withdraw your BSCPAD and rewards.")), o.a.createElement("p", null, t("The amount of tokens you Unstake will not count towards your tier level for upcoming"), " ", o.a.createElement(V.a, {
                        target: "_blank",
                        className: "text-warning",
                        to: g
                    }, t("Projects")), ".")))), o.a.createElement("div", {
                        className: "bs-stepper-content",
                        id: "UnStakeStep2"
                    }, o.a.createElement("div", {
                        className: "text-center"
                    }, o.a.createElement("h4", null, t("Checkpoints")), o.a.createElement("p", null, t("The following conditions must be met to proceed"), ":")), o.a.createElement("div", {
                        className: "row mt-4 d-flex justify-content-center"
                    }, o.a.createElement("div", {
                        className: "col-lg-3 col-md-6 mb-lg-0 mb-3"
                    }, o.a.createElement("div", {
                        className: u ? "p-select-card mb-4 selected" : "p-select-card mb-4"
                    }, o.a.createElement("div", {
                        className: "p-select-card-title"
                    }, o.a.createElement("b", null, t("Connected with MetaMask"))), o.a.createElement("div", {
                        className: "p-select-card-description"
                    }, t('If not connected, click the "Connect Wallet" button in the top right corner')))), o.a.createElement("div", {
                        className: "col-lg-3 col-md-6 mb-lg-0 mb-3"
                    }, o.a.createElement("div", {
                        className: parseFloat(p.stakedAmount) > 0 ? "p-select-card mb-4 selected" : "p-select-card mb-4"
                    }, o.a.createElement("div", {
                        className: "p-select-card-title"
                    }, o.a.createElement("b", null, t("Have an active BSCPAD stake"))), o.a.createElement("div", {
                        className: "p-select-card-description"
                    }, t("You currently have"), " ", je.formatNumberDownRound(p.stakedAmount, 2), " ", t("BSCPad staked")))), o.a.createElement("div", {
                        className: "col-lg-3 col-md-6 mb-lg-0 mb-3"
                    }, o.a.createElement("div", {
                        className: h > 0 ? "p-select-card mb-4 selected" : "p-select-card mb-4"
                    }, o.a.createElement("div", {
                        className: "p-select-card-title"
                    }, o.a.createElement("b", null, t("BNB available in wallet"))), o.a.createElement("div", {
                        className: "p-select-card-description"
                    }, t("BNB is required to pay transaction fees on the Binance Smart Chain network."), o.a.createElement("br", null), t("BNB Balance"), ": ", je.formatNumberDownRoundWithExtractMax(h, 4)))), o.a.createElement("div", {
                        className: "col-lg-3 col-md-6 mb-lg-0 mb-3"
                    }, o.a.createElement("div", {
                        className: 0 === p.withdrawTimestamp ? "p-select-card mb-4 selected" : "p-select-card mb-4"
                    }, o.a.createElement("div", {
                        className: "p-select-card-title"
                    }, o.a.createElement("b", null, t("Eligible to initiate unstake"))), o.a.createElement("div", {
                        className: "p-select-card-description"
                    }, t("You cannot unstake if you already have an active BSCPAD unstake/withdrawal request"))))), o.a.createElement("div", {
                        className: "mt-4 text-center"
                    }, o.a.createElement("div", {
                        className: "form-check"
                    }, o.a.createElement("input", {
                        className: "form-check-input float-none me-1",
                        type: "checkbox",
                        defaultValue: !0,
                        id: "flexCheckDefault",
                        onChange: function() {
                            return E(!y)
                        }
                    }), o.a.createElement("label", {
                        className: "form-check-label",
                        htmlFor: "flexCheckDefault"
                    }, t("I have read the"), "\xa0", o.a.createElement(V.a, {
                        target: "_blank",
                        to: w
                    }, t("Terms and Conditions"), " "))))), o.a.createElement("div", {
                        className: "bs-stepper-content",
                        id: "UnStakeStep3"
                    }, o.a.createElement("div", {
                        className: "text-center"
                    }, o.a.createElement("h4", null, t("Please enter the amount of BSCPAD you want to unstake")), o.a.createElement("div", {
                        className: "mx-auto text-start mt-5",
                        style: {
                            maxWidth: "370px"
                        }
                    }, o.a.createElement("div", {
                        className: "p-form-group mb-1"
                    }, o.a.createElement("label", {
                        className: "form-label p-main-text"
                    }, t("Amount")), o.a.createElement("div", {
                        className: "p-input-group"
                    }, o.a.createElement("input", {
                        type: "number",
                        className: "form-control px-0",
                        placeholder: 0,
                        value: x,
                        onChange: function(e) {
                            return function(e) {
                                L(!1), je.isFloatFormatted(e.target.value, 4) && (_(e.target.value), Object(W.BigNumber)(e.target.value).lte(Object(W.BigNumber)(p.stakedAmount)) && Object(W.BigNumber)(e.target.value).gt(Object(W.BigNumber)(0)) ? N(!0) : N(!1))
                            }(e)
                        }
                    }), o.a.createElement(Xt.a, {
                        onClick: function() {
                            _(je.formatNumberDownRound(p.stakedAmount, 4)), N(!0), L(!0)
                        }
                    }, t("MAX"))))))), o.a.createElement("div", {
                        className: "bs-stepper-content",
                        id: "UnStakeStep4"
                    }, o.a.createElement("div", {
                        className: "text-center"
                    }, o.a.createElement("h4", null, t("Confirm Unstaking Process")), o.a.createElement("p", null, t("In this step, you initiate the unstaking process. After a 7 day waiting period, you will be allowed to withdraw your BSCPAD")))), o.a.createElement("div", {
                        className: "bs-stepper-content",
                        id: "UnStakeStep5"
                    }, o.a.createElement("div", {
                        className: "text-center"
                    }, o.a.createElement("div", {
                        className: "text-warning"
                    }, o.a.createElement("i", {
                        className: "mdi mdi-check",
                        style: {
                            fontSize: "50px"
                        }
                    })), o.a.createElement("h4", null, t("Confirmed")), o.a.createElement("p", null, t("You have initiated the unstaking process and started the 7 day timer."), o.a.createElement("br", null), t("If desired, you may check Binance Smart Chain to confirm the transaction.")), o.a.createElement("p", null, o.a.createElement("a", {
                        className: "p-address",
                        href: "".concat(Ie.BSC_EXPLORER, "/tx/").concat(A),
                        target: "blank"
                    }, A)))))))), o.a.createElement("div", {
                        className: "mb-3 mt-4 text-center step-buttons"
                    }, M ? o.a.createElement(o.a.Fragment, null, o.a.createElement("button", {
                        onClick: function() {
                            return _("0"), L(!0), c(1), void Y(!1)
                        },
                        type: "button",
                        className: "btn btn-primary btn-round  me-3 px-5"
                    }, t("Done"))) : o.a.createElement(o.a.Fragment, null, o.a.createElement("button", {
                        onClick: function() {
                            1 !== l && c(l - 1)
                        },
                        type: "button",
                        disabled: !S || 1 === l,
                        className: "btn btn-primary btn-round btn-back-step me-3 px-5"
                    }, o.a.createElement("i", {
                        className: "mdi mdi-arrow-left me-2"
                    }), t("Previous")), o.a.createElement("button", {
                        onClick: function() {
                            return function() {
                                if (1 === l) return N(!1), void c(l + 1);
                                if (2 === l && 0 === parseFloat(x)) return N(!1), void c(l + 1);
                                if (4 === l) m && (a({
                                    type: D.REQUEST_SUBMIT
                                }), m.stakingInitiateWithdrawal({
                                    amount: R ? p.stakedAmount : x
                                }, (function(e) {
                                    "STAKING_INITIATE_WITHDRAWAL_SUCCESS" === e.status && (a({
                                        type: D.REQUEST_DONE
                                    }), Y(!0), O(e.txID), c(5)), "STAKING_INITIATE_WITHDRAWAL_FAIL" === e.status && (a({
                                        type: D.REQUEST_DONE
                                    }), a({
                                        type: D.ALERT_FAILS,
                                        message: "INIT Unstake fails"
                                    }))
                                })));
                                else {
                                    if (5 === l) return;
                                    c(l + 1)
                                }
                            }()
                        },
                        type: "button",
                        disabled: !S || 5 === l,
                        className: "btn btn-primary btn-round btn-next-step px-5"
                    }, t("Next"), o.a.createElement("i", {
                        className: "mdi mdi-arrow-right ms-2"
                    })))))
                },
                Zt = a(183),
                ea = Ie.BSC_NODE_URL[me.a.random(0, Ie.BSC_NODE_URL.length - 1)],
                ta = function() {
                    var e = Object(B.a)(j.a.mark((function e(t) {
                        var a;
                        return j.a.wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    return a = {}, e.prev = 1, console.log("provider URI==>", ea), e.next = 5, ye.a.post(ea);
                                case 5:
                                    200 === e.sent.status || (ea = Ie.BSC_NODE_URL[me.a.random(0, Ie.BSC_NODE_URL.length - 1)]), Wt = new Tt.a(ea), e.next = 13;
                                    break;
                                case 9:
                                    e.prev = 9, e.t0 = e.catch(1), ea = Ie.BSC_NODE_URL[me.a.random(0, Ie.BSC_NODE_URL.length - 1)], Wt = new Tt.a(ea);
                                case 13:
                                    return e.next = 15, Promise.all(t.filter((function(e) {
                                        return "TBA" !== e
                                    })).map(function() {
                                        var e = Object(B.a)(j.a.mark((function e(t) {
                                            var n, r, o, i, l, s, c, u, m, d, p, h, b, f, y, E, g;
                                            return j.a.wrap((function(e) {
                                                for (;;) switch (e.prev = e.next) {
                                                    case 0:
                                                        if ("TBA" !== t) {
                                                            e.next = 4;
                                                            break
                                                        }
                                                        a["".concat(t)] = {
                                                            state: "P",
                                                            symbol: "TBA",
                                                            rate: 0,
                                                            totalCountWallet: 0,
                                                            totalCountUserParticipated: 0,
                                                            totalFundParticipated: 0,
                                                            maxSingleParticipationAllocated: 0,
                                                            maxTotalParticipationAllocated: 0
                                                        }, e.next = 26;
                                                        break;
                                                    case 4:
                                                        return n = new Wt.eth.Contract(Nt, t), e.next = 7, n.methods.info().call();
                                                    case 7:
                                                        return r = e.sent, e.next = 10, n.methods.infoRounds().call();
                                                    case 10:
                                                        for (o = e.sent, i = r[0], l = r[1], s = parseInt(r[2]), c = parseFloat(r[3] / Math.pow(10, 6)), u = parseInt(r[4]), m = parseInt(r[5]), d = parseInt(r[6]), p = r[7], h = r[8], b = r[9], f = Zt.div(r[10], Math.pow(10, s)), y = Zt.div(r[11], Math.pow(10, s)), E = [], g = 0; g < o[0].length; g++) E.push({
                                                            round: o[0][g],
                                                            opens: o[1][g],
                                                            closes: o[2][g]
                                                        });
                                                        a["".concat(t)] = {
                                                            tokenAddress: i,
                                                            symbol: l,
                                                            decimal: s,
                                                            rate: c,
                                                            openTime: u,
                                                            fcfsOpenTime: m,
                                                            closeTime: d,
                                                            totalCountWallet: p,
                                                            totalCountUserParticipated: b,
                                                            totalFundParticipated: f,
                                                            maxTotalParticipationAllocated: y,
                                                            state: h,
                                                            infoRound: E
                                                        };
                                                    case 26:
                                                    case "end":
                                                        return e.stop()
                                                }
                                            }), e)
                                        })));
                                        return function(t) {
                                            return e.apply(this, arguments)
                                        }
                                    }()));
                                case 15:
                                    return e.abrupt("return", a);
                                case 16:
                                case "end":
                                    return e.stop()
                            }
                        }), e, null, [
                            [1, 9]
                        ])
                    })));
                    return function(t) {
                        return e.apply(this, arguments)
                    }
                }();

            function aa() {
                return na.apply(this, arguments)
            }

            function na() {
                return (na = Object(B.a)(j.a.mark((function e() {
                    var t, a, n, r;
                    return j.a.wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return t = Ie.BSC_NODE_URL[me.a.random(0, Ie.BSC_NODE_URL.length - 1)], a = new Tt.a(t), n = new a.eth.Contract(kt, Ie.STAKING_CONTRACT_ADDRESS), e.prev = 3, e.next = 6, n.methods.info().call();
                            case 6:
                                return r = e.sent, e.abrupt("return", {
                                    tokenAddr: r[0],
                                    tokenSymbol: r[1],
                                    tokenDecimals: Number(r[2]),
                                    stakerCount: Number(r[3]),
                                    totalStakedAmount: Object(W.BigNumber)(r[4]).dividedBy(Math.pow(10, 18)).toString(),
                                    apyPercentage: Number(r[5]),
                                    unstakePeriod: Number(r[6]),
                                    isStakingPaused: r[7],
                                    totalRewardsDistributed: Object(W.BigNumber)(r[8]).dividedBy(Math.pow(10, 18)).toString()
                                });
                            case 10:
                                return e.prev = 10, e.t0 = e.catch(3), console.log(e.t0), e.abrupt("return", {
                                    tokenAddr: 0,
                                    tokenSymbol: 0,
                                    tokenDecimals: 0,
                                    stakerCount: 0,
                                    totalStakedAmount: 0,
                                    apyPercentage: 0,
                                    unstakePeriod: 0,
                                    isStakingPaused: 0,
                                    totalRewardsDistributed: 0
                                });
                            case 14:
                            case "end":
                                return e.stop()
                        }
                    }), e, null, [
                        [3, 10]
                    ])
                })))).apply(this, arguments)
            }

            function ra() {
                return (ra = Object(B.a)(j.a.mark((function e() {
                    var t, a;
                    return j.a.wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return t = Ie.BSC_NODE_URL[me.a.random(0, Ie.BSC_NODE_URL.length - 1)], a = new Tt.a(t), e.abrupt("return", a.eth.getBlockNumber());
                            case 3:
                            case "end":
                                return e.stop()
                        }
                    }), e)
                })))).apply(this, arguments)
            }
            var oa = function(e) {
                    var t = Object($.a)().t,
                        a = Object(s.b)();
                    var n = Object(s.c)((function(e) {
                            return Object(ue.get)(e, "utils.isConnectWallet", !1)
                        })),
                        i = Object(s.c)((function(e) {
                            return Object(ue.get)(e, "utils.latestBlock", 0)
                        })),
                        l = He(),
                        c = l.account,
                        u = (l.library, Object(s.c)((function(e) {
                            return Object(ue.get)(e, "utils.web3Utils", null)
                        }))),
                        m = Object(r.useState)("0"),
                        d = Object(de.a)(m, 2),
                        p = d[0],
                        h = d[1],
                        b = Object(r.useState)("0"),
                        f = Object(de.a)(b, 2),
                        y = f[0],
                        E = f[1],
                        g = Object(r.useState)("0"),
                        v = Object(de.a)(g, 2),
                        w = v[0],
                        T = v[1],
                        S = Object(r.useState)(0),
                        N = Object(de.a)(S, 2),
                        k = N[0],
                        C = N[1],
                        A = Object(s.c)((function(e) {
                            return Object(ue.get)(e, "utils.blocking", !1)
                        }));
                    Object(r.useEffect)((function() {
                        u && u.getStakingInfoWallet().then((function(e) {
                            h(e.stakedAmount), E(e.unstakedAmount), T(e.rewardAmount);
                            var t = (new Date).getTime();
                            e.withdrawTimestamp > t && C(e.withdrawTimestamp), a({
                                type: D.GET_STAKING_WALLET_INFO,
                                data: e
                            })
                        }))
                    }), [u, A, k, i, c]), Object(r.useEffect)((function() {
                        k > 0 && pe("".concat(c, "-endtime"), k, (function(e) {
                            a({
                                type: D.SET_JOB_COUNTDOWN_STAKE_TIME,
                                data: e
                            })
                        }), (function(e) {
                            C(0)
                        }))
                    }), [a, c, k]);
                    var O = function() {
                        var e = Object(B.a)(j.a.mark((function e() {
                            return j.a.wrap((function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        u && (a({
                                            type: D.REQUEST_SUBMIT
                                        }), u.stakingRewards((function(e) {
                                            "STAKING_REWARDS_SUCCESS" === e.status && (a({
                                                type: D.REQUEST_DONE
                                            }), a({
                                                type: D.ALERT_SUCCESS,
                                                message: t("Stake rewards successfully")
                                            })), "STAKING_REWARDS_FAIL" === e.status && (a({
                                                type: D.REQUEST_DONE
                                            }), a({
                                                type: D.ALERT_FAILS,
                                                message: t("Stake rewards fail")
                                            }))
                                        })));
                                    case 1:
                                    case "end":
                                        return e.stop()
                                }
                            }), e)
                        })));
                        return function() {
                            return e.apply(this, arguments)
                        }
                    }();
                    return o.a.createElement(o.a.Fragment, null, o.a.createElement("div", {
                        className: "p-sidebar"
                    }, o.a.createElement("div", null, o.a.createElement("div", {
                        className: "p-sidebar-close mb-2"
                    }, o.a.createElement("button", {
                        className: "btn btn-link text-warning",
                        type: "button",
                        onClick: function() {
                            Ht()(".p-sidebar").toggleClass("active")
                        }
                    }, o.a.createElement("i", {
                        className: "mdi mdi-arrow-right"
                    }))), o.a.createElement("div", {
                        className: "p-sidebar-card mt-md-3"
                    }, o.a.createElement("div", {
                        className: "p-sidebar-card-title"
                    }, t("Staked")), o.a.createElement("div", {
                        className: "p-sidebar-card-body"
                    }, o.a.createElement("div", {
                        className: "p-sidebar-card-value"
                    }, je.formatNumberDownRoundWithExtractMax(p, 4)))), o.a.createElement("div", {
                        className: "p-sidebar-card mt-md-4 mt-3"
                    }, o.a.createElement("div", {
                        className: "p-sidebar-card-title"
                    }, t("Unstaked")), o.a.createElement("div", {
                        className: "p-sidebar-card-body"
                    }, o.a.createElement("div", {
                        className: "p-sidebar-card-value"
                    }, je.formatNumberDownRoundWithExtractMax(y, 4)), parseFloat(y) > 0 && k > 0 && o.a.createElement("div", null, t("Withdrawable in"), ":", o.a.createElement("div", {
                        className: "p-sidebar-card-title",
                        id: "".concat(c, "-endtime")
                    })), parseFloat(y) > 0 && 0 === k && o.a.createElement("div", null, t("Withdrawable Now")))), o.a.createElement("div", {
                        className: "p-sidebar-card mt-md-4 mt-3"
                    }, o.a.createElement("div", {
                        className: "p-sidebar-card-title"
                    }, t("Rewards")), o.a.createElement("div", {
                        className: "p-sidebar-card-body"
                    }, o.a.createElement("div", {
                        className: "p-sidebar-card-value"
                    }, je.formatNumberDownRoundWithExtractMax(w, 4)), o.a.createElement("div", {
                        className: "p-sidebar-card-actions"
                    }, o.a.createElement("button", {
                        className: "btn btn-primary btn-round btn-sm",
                        style: {
                            fontSize: "16px"
                        },
                        disabled: !n || 0 === parseFloat(w) || parseFloat(y) > 0,
                        onClick: function() {
                            return O()
                        }
                    }, t("Stake Rewards")), o.a.createElement("button", {
                        className: "btn btn-primary btn-round btn-sm",
                        style: {
                            fontSize: "16px"
                        },
                        disabled: !n || 0 === parseFloat(w) || parseFloat(y) > 0,
                        onClick: function() {
                            u && (a({
                                type: D.REQUEST_SUBMIT
                            }), u.stakingExecuteWithdrawRewards((function(e) {
                                "STAKING_EXECUTE_WITHDRAW_REWARDS_SUCCESS" === e.status && (a({
                                    type: D.REQUEST_DONE
                                }), a({
                                    type: D.ALERT_SUCCESS,
                                    message: t("Withdraw stake successfully")
                                })), "STAKING_EXECUTE_WITHDRAW_REWARDS_FAIL" === e.status && (a({
                                    type: D.REQUEST_DONE
                                }), a({
                                    type: D.ALERT_FAILS,
                                    message: t("Withdraw stake fail")
                                }))
                            })))
                        }
                    }, t("Withdraw Rewards"))))))), o.a.createElement("div", {
                        className: "p-sidebar-backdrop"
                    }))
                },
                ia = function(e) {
                    var t = Object($.a)().t,
                        a = Object(s.b)(),
                        n = Object(r.useState)(0),
                        i = Object(de.a)(n, 2),
                        l = i[0],
                        c = i[1],
                        u = Object(r.useState)(0),
                        m = Object(de.a)(u, 2),
                        d = m[0],
                        p = m[1],
                        h = Object(r.useState)(0),
                        b = Object(de.a)(h, 2),
                        f = b[0],
                        y = b[1],
                        E = Object(s.c)((function(e) {
                            return Object(ue.get)(e, "wallet.stakingInfo", {})
                        })),
                        g = Object(s.c)((function(e) {
                            return Object(ue.get)(e, "utils.blocking", !1)
                        }));
                    return Object(r.useEffect)((function() {
                        try {
                            aa().then((function(e) {
                                c(e.stakerCount), p(e.totalStakedAmount), y(e.apyPercentage), a({
                                    type: D.GET_STAKING_INFO,
                                    data: e
                                })
                            }))
                        } catch (t) {
                            console.log(t)
                        }
                        var e = setInterval((function() {
                            aa().then((function(e) {
                                c(e.stakerCount), p(e.totalStakedAmount), y(e.apyPercentage), a({
                                    type: D.GET_STAKING_INFO,
                                    data: e
                                })
                            }))
                        }), 1e4);
                        a({
                            type: D.SET_JOB_GET_STAKING_INFO,
                            job: e
                        })
                    }), [a, g]), o.a.createElement(o.a.Fragment, null, E.isStakingPaused && o.a.createElement("div", {
                        className: "container mt-4 text-center d-md-block d-none"
                    }, o.a.createElement("span", {
                        className: "pp-banner-top"
                    }, o.a.createElement("i", {
                        className: "mdi mdi-alert-outline me-2 text-danger"
                    }), " ", t("All staking functions are temporarily paused. Please check back again later."))), o.a.createElement("div", {
                        className: "page-container"
                    }, E.isStakingPaused && o.a.createElement("div", {
                        className: "container mt-4 text-center d-md-none d-block pp-notice"
                    }, o.a.createElement("span", {
                        className: "pp-banner-top"
                    }, o.a.createElement("i", {
                        className: "mdi mdi-alert-outline me-2 text-danger"
                    }), " ", t("All staking functions are temporarily paused. Please check back again later."))), o.a.createElement("div", {
                        className: "p-content"
                    }, o.a.createElement("div", {
                        className: "container-fluid mt-4 p-scroll"
                    }, o.a.createElement("div", {
                        className: "p-content-tabs"
                    }, o.a.createElement("div", {
                        className: "row align-items-start"
                    }, o.a.createElement("div", {
                        className: "col-xl-4"
                    }, o.a.createElement("ul", {
                        className: "nav nav-tabs",
                        id: "myTab",
                        role: "tablist"
                    }, o.a.createElement("li", {
                        className: "nav-item",
                        role: "presentation"
                    }, o.a.createElement("button", {
                        className: "nav-link active",
                        id: "stake-tab",
                        "data-bs-toggle": "tab",
                        "data-bs-target": "#stake",
                        type: "button",
                        role: "tab",
                        "aria-controls": "stake",
                        "aria-selected": "true"
                    }, t("Stake"))), o.a.createElement("li", {
                        className: "nav-item",
                        role: "presentation"
                    }, o.a.createElement("button", {
                        className: "nav-link",
                        id: "unStake-tab",
                        "data-bs-toggle": "tab",
                        "data-bs-target": "#unStake",
                        type: "button",
                        role: "tab",
                        "aria-controls": "unStake",
                        "aria-selected": "false"
                    }, t("Unstake"))), o.a.createElement("li", {
                        className: "nav-item",
                        role: "presentation"
                    }, o.a.createElement("button", {
                        className: "nav-link",
                        id: "withdraw-tab",
                        "data-bs-toggle": "tab",
                        "data-bs-target": "#withdraw",
                        type: "button",
                        role: "tab",
                        "aria-controls": "withdraw",
                        "aria-selected": "false"
                    }, t("Withdraw"))))), o.a.createElement("div", {
                        className: "col-xl-8 mt-xl-0 mt-3"
                    }, o.a.createElement("div", {
                        className: "p-cards-top d-flex justify-content-xl-end justify-content-lg-center justify-content-md-center justify-content-start"
                    }, o.a.createElement("div", {
                        className: "p-sidebar-card p-card-top text-center mb-0 py-2 px-3 me-md-3 me-2"
                    }, o.a.createElement("div", {
                        className: "p-sidebar-card-title"
                    }, t("Number of Stakers")), o.a.createElement("div", {
                        className: "p-sidebar-card-body mt-0"
                    }, o.a.createElement("b", {
                        className: "text-warning font-24"
                    }, l))), o.a.createElement("div", {
                        className: "p-sidebar-card p-card-top text-center mb-0 py-2 px-3 me-md-3 me-2"
                    }, o.a.createElement("div", {
                        className: "p-sidebar-card-title"
                    }, t("Total BSCPAD Staked")), o.a.createElement("div", {
                        className: "p-sidebar-card-body mt-0"
                    }, o.a.createElement("b", {
                        className: "text-warning font-24"
                    }, je.formatNumberDownRound(d, 2)))), o.a.createElement("div", {
                        className: "p-sidebar-card p-card-top text-center mb-0 py-2 px-3"
                    }, o.a.createElement("div", {
                        className: "p-sidebar-card-title"
                    }, t("APY")), o.a.createElement("div", {
                        className: "p-sidebar-card-body mt-0"
                    }, o.a.createElement("b", {
                        className: "text-warning font-24"
                    }, je.formatNumberDownRound((f / 100).toString(), 2), "%")))))), o.a.createElement("div", {
                        className: "tab-content",
                        id: "myTabContent"
                    }, o.a.createElement(Qt, null), o.a.createElement($t, null), o.a.createElement(Vt, null))))), o.a.createElement(oa, null)))
                },
                la = function(e) {
                    return o.a.createElement(o.a.Fragment, null, o.a.createElement("div", {
                        className: "container py-5"
                    }, o.a.createElement("div", {
                        className: "d-flex align-items-start tab-term"
                    }, o.a.createElement("div", {
                        className: "nav nav-pills-policy flex-column nav-pills me-4",
                        id: "v-pills-tab",
                        role: "tablist",
                        "aria-orientation": "vertical"
                    }, o.a.createElement(V.a, {
                        to: w,
                        className: "nav-link text-start",
                        id: "v-pills-terms-tab"
                    }, "Terms of Use "), o.a.createElement(V.a, {
                        to: T,
                        className: "nav-link text-start",
                        id: "v-pills-privacy-policy-tab"
                    }, "Privacy Policy"), o.a.createElement(V.a, {
                        to: S,
                        className: "nav-link text-start active",
                        id: "v-pills-cookies-policy-tab"
                    }, "Cookies Policy"), o.a.createElement(V.a, {
                        to: N,
                        className: "nav-link text-start",
                        id: "v-pills-staking-policy-tab"
                    }, "Staking Policy"), o.a.createElement(V.a, {
                        to: k,
                        className: "nav-link text-start",
                        id: "v-pills-clickwrap-acceptance-tab"
                    }, "Clickwrap Acceptance")), o.a.createElement("div", {
                        className: "tab-content",
                        id: "v-pills-policy-tabContent"
                    }, o.a.createElement("div", {
                        className: "tab-pane fade show active",
                        id: "v-pills-cookies-policy",
                        role: "tabpanel",
                        "aria-labelledby": "v-pills-cookies-policy-tab"
                    }, o.a.createElement(o.a.Fragment, null, o.a.createElement("p", {
                        className: "mb-2",
                        style: {
                            textAlign: "center"
                        }
                    }, o.a.createElement("b", null, "BSCP DIGITAL LIMITED")), o.a.createElement("p", {
                        className: "mb-2",
                        style: {
                            textAlign: "center"
                        }
                    }, o.a.createElement("b", null, "Cookies Policy of ", o.a.createElement("a", {
                        href: "https://bscpad.com/"
                    }, "https://bscpad.com/"))), o.a.createElement("p", {
                        style: {
                            textAlign: "center"
                        }
                    }, o.a.createElement("small", null, "Last revised Date: 9", o.a.createElement("sup", null, "th"), " September 2021")), o.a.createElement(o.a.Fragment, null, o.a.createElement("h3", null, "Cookies Information"), o.a.createElement("p", null, "These Cookies Policy (herein referred as ", o.a.createElement("b", null, '"Cookies"'), ") govern the use and the utilization of ", o.a.createElement("a", {
                        href: "https://bscpad.com/"
                    }, "https://bscpad.com/"), " ", "website (herein referred as ", o.a.createElement("b", null, '"website"'), "), provided by BSCP Digital Limited (herein referred to as ", o.a.createElement("b", null, "\u201cBSCPAD\u201d"), ", ", o.a.createElement("b", null, "\u201cWe\u201d"), ", ", o.a.createElement("b", null, "\u201cOur\u201d"), ", and ", o.a.createElement("b", null, "\u201cUs\u201d"), "), Cookies are small text files that are placed on your computer by the websites that you visit. They are widely used in order to make websites work, or work more efficiently, as well as to provide information to the owners of the site. The use of cookies is now standard for most websites. If you are uncomfortable with the use of cookies, you can manage and control them through your browser, including removing cookies by deleting them from your \u2018browser history\u2019 when you leave the site. If you do not comfortable to the cookies utilization, please do not access or use the website and the Services."), o.a.createElement("p", null, 'In order to improve our Service to you, we will occasionally use a "cookie" and/or other similar files or programs which may place certain information on your computer\'s hard drive when you visit our website. A cookie is a small amount of data that our web server sends to your web browser when you visit certain parts of our site. We may use cookies to:'), o.a.createElement("ul", null, o.a.createElement("li", null, "allow us to recognise the PC you are using when you return to our website so that we can understand your interest in our website and tailor its content to match your interests (This type of cookie may be stored permanently on your PC but does not contain any information that can identify you personally.);"), o.a.createElement("li", null, "identify you after you have logged in by storing a temporary reference number in the cookie so that our web server can conduct a dialogue with you while simultaneously dealing with other User (Your browser keeps this type of cookie until you log off or close down your browser when these types of cookie are normally deleted. No other information is stored in this type of cookie.);"), o.a.createElement("li", null, "allow you to carry information across pages of our site and avoid having to re-enter that information;"), o.a.createElement("li", null, "allow you access to stored information if you register for any of our on-line services;"), o.a.createElement("li", null, "enable us to produce statistical information (anonymous) which helps us to improve the structure and content of our website, to improve our Service;"), o.a.createElement("li", null, "enable us to evaluate the effectiveness of our advertising and promotions.")), o.a.createElement("p", null, "By using BSCPAD website or application you consent to the deployment of cookies. You can control and manage cookies using your browser (see below). Please note that removing or blocking cookies can impact your user experience and some functionality may no longer be available. Cookies do not enable us to gather personal information about you unless you give the information to our Service. Most Internet browser software allows the blocking of all cookies or enables you to receive a warning before a cookie is stored. For further information, please refer to your Internet browser software instructions or help screen."), o.a.createElement("h3", null, "Controlling Cookies by your browser"), o.a.createElement("p", null, "Most browsers allow you to view, manage, delete and block cookies for a website. Be aware that if you delete all cookies then any preferences you have set will be lost, including the ability to opt-out from cookies as this function itself requires placement of an opt out cookie on your device. Guidance on how to control cookies for common browsers is linked below."), o.a.createElement("p", null, o.a.createElement("b", null, "Google Chrome"), o.a.createElement("br", null), o.a.createElement("a", {
                        href: "https://support.google.com/chrome/answer/95647?co=GENIE.Platform%3DDesktop&hl=en",
                        target: "_blank"
                    }, "https://support.google.com/chrome/answer/95647?co=GENIE.Platform%3DDesktop&hl=en")), o.a.createElement("p", null, o.a.createElement("b", null, "Mozilla Firefox"), o.a.createElement("br", null), o.a.createElement("a", {
                        href: "https://support.mozilla.org/en-US/kb/enhanced-tracking-protection-firefox-desktop?redirectslug=enable-and-disable-cookies-website-preferences&redirectlocale=en-US",
                        target: "_blank"
                    }, "https://support.mozilla.org/en-US/kb/enhanced-tracking-protection-firefox-desktop?redirectslug=enable-and-disable-cookies-website-preferences&redirectlocale=en-US")), o.a.createElement("p", null, o.a.createElement("b", null, "Safari web and iOS"), o.a.createElement("br", null), o.a.createElement("a", {
                        href: "https://support.apple.com/en-us/HT201265",
                        target: "_blank"
                    }, "https://support.apple.com/en-us/HT201265")), o.a.createElement("p", null, o.a.createElement("b", null, "Microsoft Internet Explorer"), o.a.createElement("br", null), o.a.createElement("a", {
                        href: "https://support.microsoft.com/en-us/windows/delete-and-manage-cookies-168dab11-0753-043d-7c16-ede5947fc64d",
                        target: "_blank"
                    }, "https://support.microsoft.com/en-us/windows/delete-and-manage-cookies-168dab11-0753-043d-7c16-ede5947fc64d")), o.a.createElement("p", null, "Alternatively, information on deleting or controlling cookies is available at", " ", o.a.createElement("a", {
                        href: "http://www.allaboutcookies.org",
                        target: "_blank"
                    }, "http://www.allaboutcookies.org"), "."), o.a.createElement("p", null, "For information on additional browsers and device type please see", " ", o.a.createElement("a", {
                        href: "http://www.aboutcookies.org/",
                        target: "_blank"
                    }, "http://www.aboutcookies.org/"), " ", "or", " ", o.a.createElement("a", {
                        href: "http://www.cookiecentral.com/faq/",
                        target: "_blank"
                    }, "http://www.cookiecentral.com/faq/"), "."), o.a.createElement("h3", null, "Type of Cookies"), o.a.createElement("p", null, o.a.createElement("u", null, "Strictly Necessary Cookies"), ": These cookies are essential to enable you to log in, navigate a website, and use its features or to provide a service requested by you. We will not need to obtain your consent in order to use these cookies."), o.a.createElement("p", null, o.a.createElement("u", null, "Functionality Cookies"), ": These cookies allow the website to remember choices you make (such as your username, language, or the region you reside in) and provide enhanced, more personal features. The information these cookies collect remains anonymous, and they cannot track your browsing activity on other websites."), o.a.createElement("p", null, o.a.createElement("u", null, "Performance cookies"), ": These cookies collect information about how you use a website, for example, which pages you go to most often, how much time you spend on a page, record difficulties you may experience while using the website such as error messages. All information collected by these cookies is aggregated and therefore anonymous. It is only used to improve the efficiency of the website."), o.a.createElement("p", null, o.a.createElement("u", null, "Targeting Cookies or Advertising Cookies"), ": These cookies are used to deliver advertisements tailored to you and your interests specifically. They are also used to limit the number of times you see an advertisement as well as help measure the effectiveness of the advertising campaign. These cookies remember that you have visited a website, and this information is shared with other organizations such as advertisers. Quite often targeting or advertising cookies will be linked to the sites' functionality provided by the other organizations."), o.a.createElement("p", null, "For any questions regarding this Cookies Policy, your Cookies management or if you would like to contact is about the cookies, please email", " ", o.a.createElement("a", {
                        href: "mailto:support@bscpad.com"
                    }, "support@bscpad.com"), " and visit Our website at ", o.a.createElement("a", {
                        href: "https://bscpad.com/"
                    }, "https://bscpad.com/"), "."), o.a.createElement("p", null, "BSCPAD reserves the right to amend its prevailing Cookies Policy at any time and will place any such amendments at", " ", o.a.createElement("a", {
                        href: "https://bscpad.com/"
                    }, "https://bscpad.com/"), ". This Cookies Policy is not intended to, nor does it, create any contractual rights whatsoever or any other legal rights, nor does it create any obligations on BSCPAD in respect of any other party or on behalf of any party."))))))))
                },
                sa = function(e) {
                    return o.a.createElement(o.a.Fragment, null, o.a.createElement("div", {
                        className: "container py-5"
                    }, o.a.createElement("div", {
                        className: "d-flex align-items-start tab-term"
                    }, o.a.createElement("div", {
                        className: "nav nav-pills-policy flex-column nav-pills me-4",
                        id: "v-pills-tab",
                        role: "tablist",
                        "aria-orientation": "vertical"
                    }, o.a.createElement(V.a, {
                        to: w,
                        className: "nav-link text-start",
                        id: "v-pills-terms-tab"
                    }, "Terms of Use "), o.a.createElement(V.a, {
                        to: T,
                        className: "nav-link text-start",
                        id: "v-pills-privacy-policy-tab"
                    }, "Privacy Policy"), o.a.createElement(V.a, {
                        to: S,
                        className: "nav-link text-start",
                        id: "v-pills-cookies-policy-tab"
                    }, "Cookies Policy"), o.a.createElement(V.a, {
                        to: N,
                        className: "nav-link text-start",
                        id: "v-pills-staking-policy-tab"
                    }, "Staking Policy"), o.a.createElement(V.a, {
                        to: k,
                        className: "nav-link text-start active",
                        id: "v-pills-clickwrap-acceptance-tab"
                    }, "Clickwrap Acceptance")), o.a.createElement("div", {
                        className: "tab-content",
                        id: "v-pills-policy-tabContent"
                    }, o.a.createElement("div", {
                        className: "tab-pane fade show active",
                        id: "v-pills-cookies-policy",
                        role: "tabpanel",
                        "aria-labelledby": "v-pills-cookies-policy-tab"
                    }, o.a.createElement(o.a.Fragment, null, o.a.createElement("p", {
                        className: "mb-2",
                        style: {
                            textAlign: "center"
                        }
                    }, o.a.createElement("b", null, "BSCP DIGITAL LIMITED")), o.a.createElement("p", {
                        className: "mb-2",
                        style: {
                            textAlign: "center"
                        }
                    }, o.a.createElement("b", null, "Clickwrap Acceptance of ", o.a.createElement("a", {
                        href: "https://bscpad.com/"
                    }, "https://bscpad.com/"))), o.a.createElement("p", {
                        style: {
                            textAlign: "center"
                        }
                    }, o.a.createElement("b", null, "Last revised Date 7"), o.a.createElement("b", null, "th"), o.a.createElement("b", null, " May 2021")), o.a.createElement("h1", null, "Clickwrap Acceptance"), o.a.createElement("p", null, o.a.createElement("span", {
                        style: {
                            fontWeight: 400
                        }
                    }, "By clicking on the \u201cI Agree\u201d"), " ", o.a.createElement("span", {
                        style: {
                            fontWeight: 400
                        }
                    }, "button below, I acknowledge that I have read the ", o.a.createElement(V.a, {
                        to: w
                    }, "[Terms and Conditions]"), " and ", o.a.createElement(V.a, {
                        to: T
                    }, "[Privacy Policy]"), ", and that I agree to their terms. I understand that the Privacy Policy contain Cookie Policy.\xa0")), o.a.createElement("p", null, o.a.createElement("span", {
                        style: {
                            fontWeight: 400
                        }
                    }, "We use cookies to personalise content and to provide you with an improved user experience. By continuing to browse this site you consent to the use of cookies. You can find out more in our privacy policy and ", o.a.createElement(V.a, {
                        to: S
                    }, "Cookie Policy"), ", and manage the choices available to you at any time by following the instruction of your device preferences.")), o.a.createElement("p", null, o.a.createElement("span", {
                        style: {
                            fontWeight: 400
                        }
                    }, "[\xa0 ] I AGREE, and continue with the Service"))))))))
                },
                ca = function(e) {
                    return o.a.createElement(o.a.Fragment, null, o.a.createElement("div", {
                        className: "container py-5"
                    }, o.a.createElement("div", {
                        className: "d-flex align-items-start tab-term"
                    }, o.a.createElement("div", {
                        className: "nav nav-pills-policy flex-column nav-pills me-4",
                        id: "v-pills-tab",
                        role: "tablist",
                        "aria-orientation": "vertical"
                    }, o.a.createElement(V.a, {
                        to: w,
                        className: "nav-link text-start",
                        id: "v-pills-terms-tab"
                    }, "Terms of Use "), o.a.createElement(V.a, {
                        to: T,
                        className: "nav-link text-start",
                        id: "v-pills-privacy-policy-tab"
                    }, "Privacy Policy"), o.a.createElement(V.a, {
                        to: S,
                        className: "nav-link text-start",
                        id: "v-pills-cookies-policy-tab"
                    }, "Cookies Policy"), o.a.createElement(V.a, {
                        to: N,
                        className: "nav-link text-start active",
                        id: "v-pills-staking-policy-tab"
                    }, "Staking Policy"), o.a.createElement(V.a, {
                        to: k,
                        className: "nav-link text-start",
                        id: "v-pills-clickwrap-acceptance-tab"
                    }, "Clickwrap Acceptance")), o.a.createElement("div", {
                        className: "tab-content",
                        id: "v-pills-policy-tabContent"
                    }, o.a.createElement("div", {
                        className: "tab-pane fade show active",
                        id: "v-pills-cookies-policy",
                        role: "tabpanel",
                        "aria-labelledby": "v-pills-cookies-policy-tab"
                    }, o.a.createElement("p", {
                        className: "mb-2",
                        style: {
                            textAlign: "center"
                        }
                    }, o.a.createElement("b", null, "BSCP DIGITAL LIMITED")), o.a.createElement("p", {
                        className: "mb-2",
                        style: {
                            textAlign: "center"
                        }
                    }, o.a.createElement("b", null, "Staking Policy of ", o.a.createElement("a", {
                        href: "https://bscpad.com/"
                    }, "https://bscpad.com/"))), o.a.createElement("p", {
                        style: {
                            textAlign: "center"
                        }
                    }, o.a.createElement("b", null, "Last revised Date 7"), o.a.createElement("b", null, "th"), o.a.createElement("b", null, " May 2021")), o.a.createElement("h1", null, "Staking Policy"), o.a.createElement("p", null, o.a.createElement("span", {
                        style: {
                            fontWeight: 400
                        }
                    }, "BACPad provides Staking Service to Users for purposes of delegating (also referred to as \u201cstake\u201d or \u201cstaking\u201d) the User\u2019s BSCPad tokens in exchange fora share of Net Staking Rewards. You can provide instructions, such as delegate and undelegate through the Platform. Once the instructions are received, the system will record the instructions and you will not be able to cancel or edit those instructions. You acknowledge and agree that BACPad holds the right to reject your participation in Staking, in the event that you are unable to fulfill your identity verification requirements or for any other suspicious activity detected while participating in the services provided by BSCPad. The Tokens being staked are limited to tokens to BSCPAD tokens only. You acknowledge and agree that the estimated reward yield displayed on BSCPad is an estimation and not a guaranteed or promised actual yield. The actual yield you receive may not meet or may be lower than the estimated yield and subject to yield compression or expansion. BSCPad does not promise or guarantee the actual yield or Staking rewards you will receive. You acknowledge and agree that when you undelegate your Tokens, the delivery of such Tokens into your BEP-20 compatible wallet is 7 days and the timing may vary based on time of day of request and execution. BSCPad may levy a withdrawal fee or minimum transaction amount at its sole discretion and vary from time-to-time. BSCPas shall not be liable for any losses caused by timing differences associated with the actual delivery of the Tokens. You acknowledge and agree that BSCPad reserves the right to amend any terms related to any specific Staking program at any time in its sole discretion. BSCPad shall not be liable for any losses due to your misunderstanding of the Staking program terms and changes to such term\u2019s rules")))))))
                },
                ua = a(249),
                ma = a(154);
            a(1075);

            function da(e) {
                var t = e.children,
                    a = Object(Ye.d)().active,
                    n = Object(Ye.d)("NETWORK"),
                    o = n.active,
                    i = n.error,
                    l = n.activate,
                    s = new ft({
                        urls: Object(x.a)({}, K, q)
                    }),
                    c = function() {
                        var e = Object(Ye.d)(),
                            t = e.activate,
                            a = e.active,
                            n = Object(r.useState)(!1),
                            o = Object(de.a)(n, 2),
                            i = o[0],
                            l = o[1];
                        return Object(r.useEffect)((function() {
                            Ke.isAuthorized().then((function(e) {
                                var a = window.localStorage.getItem("connectorId");
                                e && a || Fe.isMobile && window.ethereum && a ? t(Ke, void 0, !0).catch((function() {
                                    l(!0)
                                })) : l(!0)
                            }))
                        }), [t]), Object(r.useEffect)((function() {
                            a && l(!0)
                        }), [a]), i
                    }();
                Object(r.useEffect)((function() {
                        !c || o || i || a || l(s)
                    }), [c, o, i, l, a]),
                    function() {
                        var e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0],
                            t = Object(Ye.d)(),
                            a = t.active,
                            n = t.error,
                            o = t.activate;
                        Object(r.useEffect)((function() {
                            var t = window.ethereum;
                            if (t && t.on && !a && !n && !e) {
                                var r = function() {
                                        o(Ke, void 0, !0).catch((function(e) {
                                            console.error("Failed to activate after chain changed", e)
                                        }))
                                    },
                                    i = function(e) {
                                        e.length > 0 && o(Ke, void 0, !0).catch((function(e) {
                                            console.error("Failed to activate after accounts changed", e)
                                        }))
                                    };
                                return t.on("chainChanged", r), t.on("accountsChanged", i),
                                    function() {
                                        t.removeListener && (t.removeListener("chainChanged", r), t.removeListener("accountsChanged", i))
                                    }
                            }
                        }), [a, n, e, o])
                    }(!c);
                var u = Object(r.useState)(!1),
                    m = Object(de.a)(u, 2),
                    d = (m[0], m[1]);
                return Object(r.useEffect)((function() {
                    var e = setTimeout((function() {
                        d(!0)
                    }), 600);
                    return function() {
                        clearTimeout(e)
                    }
                }), []), c ? t : null
            }
            var pa = {
                en: {
                    translation: a(439)
                },
                cn: {
                    translation: a(440)
                }
            };
            ua.a.use(ma.e).init({
                resources: pa,
                lng: "en",
                fallbackLng: "en",
                interpolation: {
                    escapeValue: !1
                }
            });
            var ha = function(e) {
                var t = Object(s.c)((function(e) {
                        return Object(ue.get)(e, "language.language", null)
                    })),
                    a = Object(s.c)((function(e) {
                        return e
                    })),
                    n = a.utils,
                    i = a.alert,
                    l = Object(s.b)();
                return ba(!0), window.setTimeout((function() {
                    ba(!1), i && JSON.stringify(i) != JSON.stringify({}) && l({
                        type: D.ALERT_CLEAR
                    }), n.alertLink && n.alertLink.type.trim().length > 0 && l(et())
                }), 5e3), Object(r.useEffect)((function() {
                    var e = localStorage.getItem("TRONPAD_LANGUAGE");
                    l($e(e || "en"))
                }), []), Object(r.useEffect)((function() {
                    t && ua.a.use(ma.e).init({
                        resources: pa,
                        lng: t,
                        fallbackLng: "en",
                        interpolation: {
                            escapeValue: !1
                        }
                    })
                }), [t]), Object(r.useEffect)((function() {
                    var e = new URL(document.location).searchParams.get("lang");
                    !e || "cn" !== e.toLocaleLowerCase() && "en" !== e.toLocaleLowerCase() || l($e(e))
                }), []), Object(r.useEffect)((function() {
                    setInterval((function() {
                        (function() {
                            return ra.apply(this, arguments)
                        })().then((function(e) {
                            l({
                                type: D.SET_BLOCK_LATEST,
                                data: e
                            })
                        })).catch((function(e) {
                            console.log(e)
                        }))
                    }), 9e3)
                }), []), o.a.createElement(o.a.Fragment, null, i.message && o.a.createElement("div", {
                    id: "toast-container",
                    className: "toast-top-right"
                }, o.a.createElement("div", {
                    id: "toast-id",
                    className: "toast toast-".concat(i.type)
                }, o.a.createElement("div", {
                    className: "toast-message"
                }, o.a.createElement("div", null, o.a.createElement("div", null, i.message))))), n.alertLink.url.length > 0 && o.a.createElement("a", {
                    onClick: function() {
                        return l(et())
                    },
                    href: n.alertLink.url,
                    target: "_blank",
                    rel: "noopener noreferrer"
                }, o.a.createElement("div", {
                    id: "toast-container",
                    className: "toast-top-right"
                }, o.a.createElement("div", {
                    id: "toast-id",
                    className: "toast toast-".concat(n.alertLink.type)
                }, o.a.createElement("div", {
                    className: "toast-message"
                }, o.a.createElement("div", null, o.a.createElement("div", null, n.alertLink.message)))))), o.a.createElement(c.b, {
                    history: Ae
                }, o.a.createElement(da, null, o.a.createElement(c.c, null, o.a.createElement(Mt, {
                    exact: !0,
                    path: E,
                    component: oe
                }), o.a.createElement(Mt, {
                    exact: !0,
                    path: g,
                    component: ke
                }), o.a.createElement(Mt, {
                    exact: !0,
                    path: v,
                    component: qe
                }), o.a.createElement(Mt, {
                    exact: !0,
                    path: w,
                    component: le
                }), o.a.createElement(Mt, {
                    exact: !0,
                    path: T,
                    component: ie
                }), o.a.createElement(Mt, {
                    exact: !0,
                    path: S,
                    component: la
                }), o.a.createElement(Mt, {
                    exact: !0,
                    path: N,
                    component: ca
                }), o.a.createElement(Mt, {
                    exact: !0,
                    path: k,
                    component: sa
                }), o.a.createElement(Mt, {
                    exact: !0,
                    path: C,
                    component: Jt
                }), o.a.createElement(Mt, {
                    exact: !0,
                    path: A,
                    component: ia
                })))))
            };

            function ba(e) {
                var t = document.getElementById("toast-container"),
                    a = document.getElementById("toast-id");
                t && "A" === t.parentElement.nodeName || (t && (t.style.display = e ? "block" : "none"), a && (a.style.opacity = e ? 1 : 0))
            }
            Boolean("localhost" === window.location.hostname || "[::1]" === window.location.hostname || window.location.hostname.match(/^127(?:\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)){3}$/));
            var fa = a(64),
                ya = (a(1077), a(1108)),
                Ea = a(248),
                ga = a(441),
                va = a.n(ga),
                wa = a(442),
                Ta = a.n(wa),
                Sa = alert = function() {
                    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                        t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {
                            type: ""
                        };
                    switch (t.type) {
                        case D.ALERT_SUCCESS:
                            return {
                                type: "success",
                                message: t.message
                            };
                        case D.ALERT_FAILS:
                            return {
                                type: "error",
                                message: t.message
                            };
                        case D.ALERT_WARNING:
                            return {
                                type: "warning",
                                message: t.message
                            };
                        case D.ALERT_CLEAR:
                            return {};
                        default:
                            return e
                    }
                },
                Na = a(19),
                ka = {
                    blocking: !1,
                    leftBarActive: !0,
                    isConnectWallet: !1,
                    walletAddress: null,
                    web3Utils: null,
                    showModalHelp: !1,
                    alertLink: {
                        type: "",
                        url: "",
                        message: ""
                    },
                    latestBlock: 0
                },
                Ca = {
                    projects: [],
                    openingProjects: [],
                    waitingProjects: [],
                    closedProjects: [],
                    selectedProject: null,
                    currentWalletInfo: null,
                    contractsInfo: [],
                    currentSelectedContractAddress: null,
                    jobGetProjects: 0,
                    jobGetProjectSelected: 0,
                    jobGetWalletInfo: 0,
                    jobCountDownOpen: 0,
                    jobCountDownClose: 0,
                    jobCountDownRoundTime: 0,
                    jobCountDownFcfsTime: 0
                },
                Aa = {
                    walletInfo: {},
                    kycStatus: null,
                    kycURL: "",
                    jobKyc: 0,
                    stakingInfo: {},
                    stakingWalletInfo: {},
                    jobUnStakeTime: 0,
                    bscpadBalance: 0,
                    bnbBalance: 0,
                    jobGetBalance: 0,
                    jobStakingStatus: 0
                },
                Oa = {
                    language: "cn"
                },
                Pa = Object(fa.c)({
                    alert: Sa,
                    utils: function() {
                        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : ka,
                            t = arguments.length > 1 ? arguments[1] : void 0;
                        switch (t.type) {
                            case D.REQUEST_SUBMIT:
                                return Object(Na.a)(Object(Na.a)({}, e), {}, {
                                    blocking: !0
                                });
                            case D.REQUEST_DONE:
                                return Object(Na.a)(Object(Na.a)({}, e), {}, {
                                    blocking: !1
                                });
                            case D.CLICK_LEFT_BAR_ACTIVE:
                                return Object(Na.a)(Object(Na.a)({}, e), {}, {
                                    leftBarActive: !e.leftBarActive
                                });
                            case D.ALERT_LINK:
                                return Object(Na.a)(Object(Na.a)({}, e), {}, {
                                    alertLink: {
                                        type: t.alertType,
                                        url: t.alertUrl,
                                        message: t.alertMessage
                                    }
                                });
                            case D.ALERT_LINK_CLEAR:
                                return Object(Na.a)(Object(Na.a)({}, e), {}, {
                                    alertLink: {
                                        type: "",
                                        url: "",
                                        message: ""
                                    }
                                });
                            case D.CONNECT_WALLET_SUCCESS:
                                return Object(Na.a)(Object(Na.a)({}, e), {}, {
                                    isConnectWallet: !0,
                                    walletAddress: t.data
                                });
                            case D.ENABLE_WALLET_SUCCESS:
                                return Object(Na.a)(Object(Na.a)({}, e), {}, {
                                    isConnectWallet: !0,
                                    web3Utils: t.data
                                });
                            case D.LOG_OUT_WALLET_SUCCESS:
                                return localStorage.removeItem("connectorId"), Object(Na.a)(Object(Na.a)({}, e), {}, {
                                    isConnectWallet: !1,
                                    walletAddress: null,
                                    web3Utils: null
                                });
                            case D.SET_SHOW_MODAL_HELP:
                                return Object(Na.a)(Object(Na.a)({}, e), {}, {
                                    showModalHelp: !0
                                });
                            case D.SET_BLOCK_LATEST:
                                return Object(Na.a)(Object(Na.a)({}, e), {}, {
                                    latestBlock: t.data
                                });
                            default:
                                return e
                        }
                    },
                    project: function() {
                        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : Ca,
                            t = arguments.length > 1 ? arguments[1] : void 0;
                        switch (t.type) {
                            case D.GET_PROJECTS_SUCCESS:
                                return Object(Na.a)(Object(Na.a)({}, e), {}, {
                                    projects: t.data.projects,
                                    openingProjects: t.data.openingProjects,
                                    waitingProjects: t.data.waitingProjects,
                                    closedProjects: t.data.closedProjects
                                });
                            case D.GET_LIST_CONTRACTS_INFO:
                                return Object(Na.a)(Object(Na.a)({}, e), {}, {
                                    contractsInfo: t.data
                                });
                            case D.GET_PROJECT_SELECTED:
                                return Object(Na.a)(Object(Na.a)({}, e), {}, {
                                    selectedProject: t.data
                                });
                            case D.SET_CURRENT_CONTRACT_SELECTED:
                                return Object(Na.a)(Object(Na.a)({}, e), {}, {
                                    currentSelectedContractAddress: t.data
                                });
                            case D.SET_JOB_PROJECT_SELECTED:
                                return clearInterval(e.jobGetProjectSelected), Object(Na.a)(Object(Na.a)({}, e), {}, {
                                    jobGetProjectSelected: t.data
                                });
                            case D.SET_JOB_GET_WALLET_INFO:
                                return clearInterval(e.jobGetWalletInfo), Object(Na.a)(Object(Na.a)({}, e), {}, {
                                    jobGetWalletInfo: t.data
                                });
                            case D.SET_JOB_COUNT_DOWN_OPEN:
                                return clearInterval(e.jobCountDownOpen), Object(Na.a)(Object(Na.a)({}, e), {}, {
                                    jobCountDownOpen: t.data
                                });
                            case D.SET_JOB_COUNT_DOWN_CLOSE:
                                return clearInterval(e.jobCountDownClose), Object(Na.a)(Object(Na.a)({}, e), {}, {
                                    jobCountDownClose: t.data
                                });
                            case D.SET_JOB_COUNT_DOWN_ROUND:
                                return clearInterval(e.jobCountDownRoundTime), Object(Na.a)(Object(Na.a)({}, e), {}, {
                                    jobCountDownRoundTime: t.data
                                });
                            case D.SET_JOB_COUNT_DOWN_FCFS_TIME:
                                return clearInterval(e.jobCountDownFcfsTime), Object(Na.a)(Object(Na.a)({}, e), {}, {
                                    jobCountDownFcfsTime: t.data
                                });
                            case D.SET_JOB_GET_PROJECTS:
                                return clearInterval(e.jobGetProjects), Object(Na.a)(Object(Na.a)({}, e), {}, {
                                    jobGetProjects: t.data
                                });
                            case D.CLEAR_INTERVAL_PROJECTS_JOB:
                                return clearInterval(e.jobGetProjectSelected), clearInterval(e.jobGetWalletInfo), clearInterval(e.jobGetProjects), Object(Na.a)(Object(Na.a)({}, e), {}, {
                                    jobGetProjectSelected: 0,
                                    jobGetWalletInfo: 0,
                                    jobGetProjects: 0
                                });
                            default:
                                return e
                        }
                    },
                    wallet: function() {
                        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : Aa,
                            t = arguments.length > 1 ? arguments[1] : void 0;
                        switch (t.type) {
                            case D.GET_INFO_WALLET:
                                return Object(Na.a)(Object(Na.a)({}, e), {}, {
                                    walletInfo: t.data
                                });
                            case D.GET_KYC_INFO:
                                return Object(Na.a)(Object(Na.a)({}, e), {}, {
                                    kycStatus: t.data
                                });
                            case D.GET_KYC_3RD:
                                return Object(Na.a)(Object(Na.a)({}, e), {}, {
                                    kycURL: t.data
                                });
                            case D.SET_JOB_GET_KYC:
                                return clearInterval(e.jobKyc), Object(Na.a)(Object(Na.a)({}, e), {}, {
                                    jobKyc: t.data
                                });
                            case D.CLEAR_KYC_STATE:
                                return clearInterval(e.jobKyc), Object(Na.a)(Object(Na.a)({}, e), {}, {
                                    kycStatus: null
                                });
                            case D.GET_STAKING_INFO:
                                return Object(Na.a)(Object(Na.a)({}, e), {}, {
                                    stakingInfo: t.data
                                });
                            case D.GET_STAKING_WALLET_INFO:
                                return Object(Na.a)(Object(Na.a)({}, e), {}, {
                                    stakingWalletInfo: t.data
                                });
                            case D.SET_JOB_COUNTDOWN_STAKE_TIME:
                                return clearInterval(e.jobUnStakeTime), Object(Na.a)(Object(Na.a)({}, e), {}, {
                                    jobUnStakeTime: t.data
                                });
                            case D.GET_BSCPAD_BALANCE:
                                return Object(Na.a)(Object(Na.a)({}, e), {}, {
                                    bscpadBalance: t.data
                                });
                            case D.GET_BNB_BALANCE:
                                return Object(Na.a)(Object(Na.a)({}, e), {}, {
                                    bnbBalance: t.data
                                });
                            case D.SET_JOB_GET_BALANCE:
                                return clearInterval(e.jobGetBalance), Object(Na.a)(Object(Na.a)({}, e), {}, {
                                    jobGetBalance: t.data
                                });
                            case D.CLEAR_INTERVAL_PROJECTS_JOB:
                                return clearInterval(e.jobUnStakeTime), clearInterval(e.stakingWalletInfo), Object(Na.a)(Object(Na.a)({}, e), {}, {
                                    jobUnStakeTime: 0,
                                    stakingWalletInfo: 0
                                });
                            case D.SET_JOB_GET_STAKING_STATUS:
                                return clearInterval(e.jobStakingStatus), Object(Na.a)(Object(Na.a)({}, e), {}, {
                                    jobStakingStatus: t.data
                                });
                            default:
                                return e
                        }
                    },
                    language: function() {
                        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : Oa,
                            t = arguments.length > 1 ? arguments[1] : void 0;
                        switch (t.type) {
                            case D.LANGUAGE_CHANGE:
                                return localStorage.setItem("TRONPAD_LANGUAGE", t.language), Object(Na.a)(Object(Na.a)({}, e), {}, {
                                    language: t.language
                                });
                            default:
                                return e
                        }
                    }
                }),
                Ia = a(443),
                xa = a(62),
                Da = function() {
                    var e = Object(B.a)(j.a.mark((function e() {
                        var t, a;
                        return j.a.wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    return e.prev = 0, e.next = 3, ye.a.get("".concat(Ie.BACKEND_URL).concat(u.GET_PROJECTS));
                                case 3:
                                    if (t = e.sent, console.log(t), 200 !== t.status) {
                                        e.next = 7;
                                        break
                                    }
                                    return e.abrupt("return", t.data);
                                case 7:
                                    return e.abrupt("return", []);
                                case 10:
                                    return e.prev = 10, e.t0 = e.catch(0), a = e.t0.response, console.log(a), e.abrupt("return", []);
                                case 15:
                                case "end":
                                    return e.stop()
                            }
                        }), e, null, [
                            [0, 10]
                        ])
                    })));
                    return function() {
                        return e.apply(this, arguments)
                    }
                }(),
                _a = function() {
                    var e = Object(B.a)(j.a.mark((function e(t) {
                        var a, n;
                        return j.a.wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    return e.prev = 0, e.next = 3, ye.a.get("".concat(Ie.BACKEND_URL).concat(u.GET_PROJECT_DETAILS.replace(":id", t)));
                                case 3:
                                    if (200 !== (a = e.sent).status) {
                                        e.next = 8;
                                        break
                                    }
                                    return e.abrupt("return", {
                                        status: 200,
                                        data: a.data
                                    });
                                case 8:
                                    return e.abrupt("return", {
                                        status: 404,
                                        data: null
                                    });
                                case 9:
                                    e.next = 16;
                                    break;
                                case 11:
                                    return e.prev = 11, e.t0 = e.catch(0), n = e.t0.response, console.log(n), e.abrupt("return", {
                                        status: 404,
                                        data: null
                                    });
                                case 16:
                                case "end":
                                    return e.stop()
                            }
                        }), e, null, [
                            [0, 11]
                        ])
                    })));
                    return function(t) {
                        return e.apply(this, arguments)
                    }
                }(),
                ja = j.a.mark(Wa),
                Ba = j.a.mark(Ua),
                Ra = j.a.mark(Fa),
                La = j.a.mark(Ma);

            function Wa() {
                var e, t, a, n;
                return j.a.wrap((function(r) {
                    for (;;) switch (r.prev = r.next) {
                        case 0:
                            return r.prev = 0, r.next = 3, Object(xa.b)(Da);
                        case 3:
                            if (e = r.sent, t = [], e.forEach((function(e) {
                                    "string" === typeof e.contract && "C" !== e.state && t.push(e.contract)
                                })), !(t.length > 0)) {
                                r.next = 26;
                                break
                            }
                            return a = [], n = [], r.prev = 9, r.next = 12, Object(xa.b)(ta, t);
                        case 12:
                            n = r.sent, r.next = 21;
                            break;
                        case 15:
                            return r.prev = 15, r.t0 = r.catch(9), console.log(r.t0), r.next = 20, Object(xa.b)(ta, t);
                        case 20:
                            n = r.sent;
                        case 21:
                            return e.forEach((function(t) {
                                var r = t,
                                    o = n[t.contract],
                                    i = Object.assign(r, o),
                                    l = e.find((function(e) {
                                        return e.symbol === t.projectTokenSymbol
                                    }));
                                i.athMultiplier = l ? l.ath_multiplier : null, a.push(i)
                            })), r.next = 24, Object(xa.d)({
                                type: D.GET_PROJECTS_SUCCESS,
                                data: {
                                    projects: a,
                                    openingProjects: a.filter((function(e) {
                                        return "O" == e.state || "F" == e.state
                                    })),
                                    waitingProjects: a.filter((function(e) {
                                        return "P" == e.state
                                    })),
                                    closedProjects: a.filter((function(e) {
                                        return "C" == e.state
                                    }))
                                }
                            });
                        case 24:
                            r.next = 28;
                            break;
                        case 26:
                            return r.next = 28, Object(xa.d)({
                                type: D.GET_PROJECTS_SUCCESS,
                                data: {
                                    projects: e,
                                    openingProjects: e.filter((function(e) {
                                        return "O" == e.state
                                    })),
                                    waitingProjects: e.filter((function(e) {
                                        return "P" == e.state
                                    })),
                                    closedProjects: e.filter((function(e) {
                                        return "C" == e.state
                                    }))
                                }
                            });
                        case 28:
                            r.next = 35;
                            break;
                        case 30:
                            return r.prev = 30, r.t1 = r.catch(0), console.log("==============Get project error==========="), console.log(r.t1), r.abrupt("return", null);
                        case 35:
                        case "end":
                            return r.stop()
                    }
                }), ja, null, [
                    [0, 30],
                    [9, 15]
                ])
            }

            function Ua(e) {
                var t, a, n, r;
                return j.a.wrap((function(o) {
                    for (;;) switch (o.prev = o.next) {
                        case 0:
                            return t = e.data, o.next = 3, Object(xa.b)(_a, t);
                        case 3:
                            if (200 != (a = o.sent).status) {
                                o.next = 11;
                                break
                            }
                            return o.next = 7, Object(xa.b)(ta, [t]);
                        case 7:
                            return n = o.sent, r = Object.assign(a.data, n[t]), o.next = 11, Object(xa.d)({
                                type: D.GET_PROJECT_SELECTED,
                                data: r
                            });
                        case 11:
                        case "end":
                            return o.stop()
                    }
                }), Ba)
            }

            function Fa() {
                return j.a.wrap((function(e) {
                    for (;;) switch (e.prev = e.next) {
                        case 0:
                            return e.next = 2, Object(xa.e)(D.SUBMIT_GET_PROJECTS, Wa);
                        case 2:
                        case "end":
                            return e.stop()
                    }
                }), Ra)
            }

            function Ma() {
                return j.a.wrap((function(e) {
                    for (;;) switch (e.prev = e.next) {
                        case 0:
                            return e.next = 2, Object(xa.e)(D.SUBMIT_PROJECT_SELECTED, Ua);
                        case 2:
                        case "end":
                            return e.stop()
                    }
                }), La)
            }
            var Ya = j.a.mark(Ga);

            function Ga() {
                return j.a.wrap((function(e) {
                    for (;;) switch (e.prev = e.next) {
                        case 0:
                            return e.next = 2, Object(xa.a)([Object(xa.c)(Fa), Object(xa.c)(Ma)]);
                        case 2:
                        case "end":
                            return e.stop()
                    }
                }), Ya)
            }
            var Ha = {
                key: "root",
                storage: va.a,
                blacklist: ["alert", "utils", "systemInfo"],
                stateReconciler: Ta.a
            };

            function Ka(e) {
                var t = new nt.a(e);
                return t.pollingInterval = 15e3, t
            }
            var qa = function() {
                    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                        t = arguments.length > 1 ? arguments[1] : void 0,
                        a = fa.d,
                        n = {},
                        r = Object(Ia.a)(n),
                        o = [r, Object(ya.a)(t)],
                        i = [fa.a.apply(void 0, o)],
                        l = (Object(Ea.a)(Ha, Pa), Object(fa.e)(Pa, e, a.apply(void 0, i))),
                        s = Object(Ea.b)(l);
                    return r.run(Ga), {
                        store: l,
                        persistor: s
                    }
                }({}, Ae),
                za = qa.store,
                Ja = (qa.persistor, Object(Ye.c)("NETWORK"));
            l.a.render(o.a.createElement(s.a, {
                store: za
            }, o.a.createElement(Ye.b, {
                getLibrary: Ka
            }, o.a.createElement(Ja, {
                getLibrary: Ka
            }, o.a.createElement(ha, null)))), document.getElementById("root")), "serviceWorker" in navigator && navigator.serviceWorker.ready.then((function(e) {
                e.unregister()
            })).catch((function(e) {
                console.error(e.message)
            }))
        },
        120: function(e) {
            e.exports = JSON.parse('[{"inputs":[{"internalType":"address","name":"raiseToken","type":"address"},{"internalType":"uint256","name":"rate","type":"uint256"},{"internalType":"uint256","name":"openTimestamp","type":"uint256"},{"internalType":"uint256","name":"closeTimestamp","type":"uint256"},{"internalType":"uint256","name":"cap","type":"uint256"},{"internalType":"uint256","name":"fcfsDurationSeconds","type":"uint256"},{"internalType":"string[]","name":"tierNames","type":"string[]"},{"internalType":"uint256[]","name":"tierBalances","type":"uint256[]"},{"internalType":"uint256[]","name":"tierWeights","type":"uint256[]"},{"internalType":"uint256[]","name":"tierFCFSOpenSeconds","type":"uint256[]"},{"internalType":"uint256[]","name":"tierFCFSMultipliers","type":"uint256[]"}],"stateMutability":"nonpayable","type":"constructor"},{"anonymous":false,"inputs":[{"indexed":false,"internalType":"address","name":"destination","type":"address"},{"indexed":false,"internalType":"uint256","name":"amount","type":"uint256"}],"name":"Claimed","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"previousOwner","type":"address"},{"indexed":true,"internalType":"address","name":"newOwner","type":"address"}],"name":"OwnershipTransferred","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"internalType":"address","name":"destination","type":"address"},{"indexed":false,"internalType":"uint256","name":"amount","type":"uint256"}],"name":"Participated","type":"event"},{"inputs":[],"name":"_cap","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"_closeTimestamp","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"_closed","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"_fcfsDurationSeconds","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"_openTimestamp","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"_participationAmount","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"_participationCount","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"","type":"address"}],"name":"_qualifierCompetition","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"","type":"address"}],"name":"_qualifierTier","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"","type":"uint256"}],"name":"_qualifierTierCount","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"_qualifierToken","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"_raiseToken","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"_rate","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"_releaseToken","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"","type":"uint256"}],"name":"_releases","outputs":[{"internalType":"uint256","name":"timestamp","type":"uint256"},{"internalType":"uint256","name":"percent","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"","type":"uint256"}],"name":"_roundCloseTimestamps","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"","type":"uint256"}],"name":"_roundNames","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"","type":"uint256"}],"name":"_roundOpenTimestamps","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"","type":"uint256"}],"name":"_tierBalances","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"","type":"uint256"}],"name":"_tierFCFSMultipliers","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"","type":"uint256"}],"name":"_tierFCFSOpenSeconds","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"","type":"uint256"}],"name":"_tierNames","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"","type":"uint256"}],"name":"_tierWeights","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"buildRounds","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"tierIndex","type":"uint256"}],"name":"calculateAllocation","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"percent","type":"uint256"},{"internalType":"uint256","name":"raiseTokenDecimals","type":"uint256"},{"internalType":"uint256","name":"releaseTokenDecimals","type":"uint256"}],"name":"calculateClaimAllocation","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"index","type":"uint256"}],"name":"claim","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"index","type":"uint256"},{"internalType":"address[]","name":"addresses","type":"address[]"}],"name":"claimMulti","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"fcfsOneRound","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"info","outputs":[{"internalType":"address","name":"","type":"address"},{"internalType":"string","name":"","type":"string"},{"internalType":"uint256","name":"","type":"uint256"},{"internalType":"uint256","name":"","type":"uint256"},{"internalType":"uint256","name":"","type":"uint256"},{"internalType":"uint256","name":"","type":"uint256"},{"internalType":"uint256","name":"","type":"uint256"},{"internalType":"uint256","name":"","type":"uint256"},{"internalType":"string","name":"","type":"string"},{"internalType":"uint256","name":"","type":"uint256"},{"internalType":"uint256","name":"","type":"uint256"},{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"infoAllocations","outputs":[{"internalType":"uint256[]","name":"","type":"uint256[]"},{"internalType":"uint256[]","name":"","type":"uint256[]"},{"internalType":"uint256[]","name":"","type":"uint256[]"},{"internalType":"uint256[]","name":"","type":"uint256[]"},{"internalType":"uint256[]","name":"","type":"uint256[]"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"wallet","type":"address"}],"name":"infoAllocations","outputs":[{"internalType":"uint256[]","name":"","type":"uint256[]"},{"internalType":"uint256[]","name":"","type":"uint256[]"},{"internalType":"uint256[]","name":"","type":"uint256[]"},{"internalType":"uint256[]","name":"","type":"uint256[]"},{"internalType":"uint256[]","name":"","type":"uint256[]"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"infoRounds","outputs":[{"internalType":"string[]","name":"","type":"string[]"},{"internalType":"uint256[]","name":"","type":"uint256[]"},{"internalType":"uint256[]","name":"","type":"uint256[]"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"infoTiers","outputs":[{"internalType":"string[]","name":"","type":"string[]"},{"internalType":"uint256[]","name":"","type":"uint256[]"},{"internalType":"uint256[]","name":"","type":"uint256[]"},{"internalType":"uint256[]","name":"","type":"uint256[]"},{"internalType":"uint256[]","name":"","type":"uint256[]"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"wallet","type":"address"}],"name":"infoWallet","outputs":[{"internalType":"uint256","name":"","type":"uint256"},{"internalType":"uint256","name":"","type":"uint256"},{"internalType":"string","name":"","type":"string"},{"internalType":"uint256","name":"","type":"uint256"},{"internalType":"string","name":"","type":"string"},{"internalType":"uint256","name":"","type":"uint256"},{"internalType":"uint256","name":"","type":"uint256"},{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"infoWallet","outputs":[{"internalType":"uint256","name":"","type":"uint256"},{"internalType":"uint256","name":"","type":"uint256"},{"internalType":"string","name":"","type":"string"},{"internalType":"uint256","name":"","type":"uint256"},{"internalType":"string","name":"","type":"string"},{"internalType":"uint256","name":"","type":"uint256"},{"internalType":"uint256","name":"","type":"uint256"},{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"owner","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"token","type":"address"},{"internalType":"uint256","name":"amount","type":"uint256"}],"name":"participate","outputs":[],"stateMutability":"payable","type":"function"},{"inputs":[],"name":"qualifierTokenBalance","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"raiseTokenBalance","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"raiseTokenDecimals","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"raiseTokenSymbol","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"releaseTokenDecimals","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"renounceOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"cap","type":"uint256"}],"name":"setCap","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"bool","name":"closed","type":"bool"}],"name":"setClosed","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256[]","name":"tierFCFSOpenSeconds","type":"uint256[]"},{"internalType":"uint256[]","name":"tierFCFSMultipliers","type":"uint256[]"}],"name":"setFCFS","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"amount","type":"uint256"},{"internalType":"uint256","name":"count","type":"uint256"}],"name":"setParticipation","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"qualifierToken","type":"address"}],"name":"setQualifierToken","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"rate","type":"uint256"}],"name":"setRate","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"openTimestamp","type":"uint256"},{"internalType":"uint256","name":"closeTimestamp","type":"uint256"},{"internalType":"uint256","name":"fcfsDurationSeconds","type":"uint256"}],"name":"setTimestamps","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address[]","name":"qualifierAddresses","type":"address[]"},{"internalType":"uint256[]","name":"qualifierTiers","type":"uint256[]"},{"internalType":"bool[]","name":"qualifierCompetition","type":"bool[]"}],"name":"setup","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"index","type":"uint256"},{"internalType":"uint256","name":"timestamp","type":"uint256"},{"internalType":"address[]","name":"addresses","type":"address[]"},{"internalType":"uint256[]","name":"allocations","type":"uint256[]"},{"internalType":"bool","name":"clearClaimed","type":"bool"}],"name":"setupRelease","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"token","type":"address"}],"name":"setupReleaseToken","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256[]","name":"releaseTimestamps","type":"uint256[]"},{"internalType":"uint256[]","name":"releasePercents","type":"uint256[]"}],"name":"setupReleases","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"amount","type":"uint256"},{"internalType":"address payable","name":"to","type":"address"}],"name":"transferBNB","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"newOwner","type":"address"}],"name":"transferOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"token","type":"address"},{"internalType":"uint256","name":"amount","type":"uint256"},{"internalType":"address","name":"to","type":"address"}],"name":"transferToken","outputs":[],"stateMutability":"nonpayable","type":"function"}]')
        },
        194: function(e) {
            e.exports = JSON.parse('[{"inputs":[],"stateMutability":"nonpayable","type":"constructor"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"owner","type":"address"},{"indexed":true,"internalType":"address","name":"spender","type":"address"},{"indexed":false,"internalType":"uint256","name":"value","type":"uint256"}],"name":"Approval","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"from","type":"address"},{"indexed":true,"internalType":"address","name":"to","type":"address"},{"indexed":false,"internalType":"uint256","name":"value","type":"uint256"}],"name":"Transfer","type":"event"},{"inputs":[{"internalType":"address","name":"owner","type":"address"},{"internalType":"address","name":"spender","type":"address"}],"name":"allowance","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"spender","type":"address"},{"internalType":"uint256","name":"amount","type":"uint256"}],"name":"approve","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"account","type":"address"}],"name":"balanceOf","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"decimals","outputs":[{"internalType":"uint8","name":"","type":"uint8"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"spender","type":"address"},{"internalType":"uint256","name":"subtractedValue","type":"uint256"}],"name":"decreaseAllowance","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"spender","type":"address"},{"internalType":"uint256","name":"addedValue","type":"uint256"}],"name":"increaseAllowance","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"name","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"symbol","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"totalSupply","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"recipient","type":"address"},{"internalType":"uint256","name":"amount","type":"uint256"}],"name":"transfer","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"sender","type":"address"},{"internalType":"address","name":"recipient","type":"address"},{"internalType":"uint256","name":"amount","type":"uint256"}],"name":"transferFrom","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"}]')
        },
        246: function(e) {
            e.exports = JSON.parse('[{"anonymous":false,"inputs":[{"indexed":false,"internalType":"address","name":"bscAddress","type":"address"},{"indexed":false,"internalType":"address","name":"tronAddress","type":"address"}],"name":"kycSet","type":"event"},{"inputs":[{"internalType":"address","name":"tron","type":"address"}],"name":"setKyc","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"bsc","type":"address"}],"name":"getKyc","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function","constant":true}]')
        },
        31: function(e, t, a) {
            console.log("evn", "production"), e.exports = a(723)
        },
        433: function(e) {
            e.exports = JSON.parse('{"name":"bsc-pad-frontend","version":"1.3.4","private":true,"dependencies":{"@binance-chain/bsc-connector":"^1.0.0","@fortawesome/fontawesome-svg-core":"^1.2.34","@fortawesome/react-fontawesome":"^0.1.14","@rumess/react-flip-countdown":"^1.1.2","@testing-library/jest-dom":"^4.2.4","@testing-library/react":"^9.3.2","@testing-library/user-event":"^7.1.2","@web3-react/core":"^6.1.9","@web3-react/injected-connector":"^6.0.7","@web3-react/walletconnect-connector":"^6.2.0","aos":"^2.3.4","axios":"^0.19.2","babel-polyfill":"^6.26.0","big-number":"^2.0.0","bignumber.js":"^9.0.1","bip39":"^3.0.2","chart.js":"^2.9.4","connected-react-router":"^6.8.0","crypto":"^1.0.1","ethereumjs-wallet":"^0.6.0","exact-math":"^2.2.3","fraction.js":"^4.0.13","global":"^4.4.0","history":"^4.10.1","http-status-codes":"^1.4.0","i":"^0.3.6","i18next":"^20.3.2","jquery":"^3.5.1","js-sha3":"^0.8.0","keccak":"^3.0.1","lodash":"^4.17.20","md5":"^2.2.1","moment":"^2.24.0","npm":"^6.14.11","public-ip":"^4.0.0","qrcode.react":"^1.0.0","query-string":"^6.14.1","react":"^16.12.0","react-big-calendar":"^0.33.2","react-block-ui":"^1.3.3","react-bootstrap":"^1.4.3","react-copy-to-clipboard":"^5.0.2","react-device-detect":"^1.17.0","react-dom":"^16.12.0","react-flip-counter":"^0.4.0","react-hook-form":"^6.0.4","react-i18next":"^11.11.0","react-particles-js":"^3.4.1","react-redux":"^7.2.0","react-router-dom":"^5.1.2","react-scripts":"3.4.0","react-share":"^4.3.1","react-timeago":"^5.2.0","redux":"^4.0.5","redux-logger":"^3.0.6","redux-persist":"^6.0.0","redux-saga":"^1.1.3","scrypt-js":"^3.0.1","socket.io-client":"^2.3.0","styled-components":"^5.0.1","tronweb":"^3.2.6","uuid":"^8.3.1","validator":"^12.2.0","web3":"^1.3.3","web3modal":"^1.9.3"},"scripts":{"start":"react-scripts start","build":"react-scripts build","test":"react-scripts test","eject":"react-scripts eject"},"eslintConfig":{"extends":"react-app"},"browserslist":{"production":[">0.2%","not dead","not op_mini all"],"development":["last 1 chrome version","last 1 firefox version","last 1 safari version"]}}')
        },
        439: function(e) {
            e.exports = JSON.parse('{"Connect to wallet":"Connect to wallet","Your wallet":"Your wallet","Copy Address":"Copy Address","View on BscScan":"View on BscScan","Logout":"Logout","Connect Wallet":"Connect Wallet","How to connect wallet":"How to connect wallet","KYC Help":"KYC Help","KYC":"KYC","Sync KYC":"Sync KYC","Projects":"Projects","Staking":"Staking","Copyright \xa9":"Copyright \xa9","All Rights Reserved by BSCPad":"All Rights Reserved by BSCPad","Privacy Policy":"Privacy Policy","Terms of Use":"Terms of Use","BSCPAD is the first decentralized IDO platform for the Binance Smart Chain Network.":"BSCPAD is the first decentralized IDO platform for the Binance Smart Chain Network.","BSCPad will empower crypto currency projects with the ability to distribute tokens and raise liquidity.":"BSCPad will empower crypto currency projects with the ability to distribute tokens and raise liquidity.","View all Projects":"View all Projects","Buy on":"Buy on","Apply for IDO":"Apply for IDO","White Paper":"White Paper","Join us on Telegram":"Join us on Telegram","Follow our Medium":"Follow our Medium","Follow our Twitter":"Follow our Twitter","Our Partners":"Our Partners","ABOUT US":"ABOUT US","What and Why":"What and Why","WHAT IS BSCPAD?":"WHAT IS BSCPAD?","The BSC Launch Pad is the first decentralized IDO platform for the Binance Smart Chain Network.":"The BSC Launch Pad is the first decentralized IDO platform for the Binance Smart Chain Network.","WHY CHOOSE US?":"WHY CHOOSE US?","BSCPad has found a solution to incentivize and reward all token stakers in a way that is inclusive and with a low barrier to entry.":"BSCPad has found a solution to incentivize and reward all token stakers in a way that is inclusive and with a low barrier to entry.","The fundamental flaws of existing launchpads is that acquiring enough tokens to participate in the ecosystem is prohibitive, and even if you do stake the tokens, you are not guaranteed an allocation spot. They are based on a first come first serve basis where automated bots can fill the whitelist spots in a matter of seconds. BSCPad is creating fair decentralized launches, you can choose between a lottery tier or a guaranteed allocation tier and if you win the lottery you get a guaranteed allocation in the first round (Allocation round).":"The fundamental flaws of existing launchpads is that acquiring enough tokens to participate in the ecosystem is prohibitive, and even if you do stake the tokens, you are not guaranteed an allocation spot. They are based on a first come first serve basis where automated bots can fill the whitelist spots in a matter of seconds. BSCPad is creating fair decentralized launches, you can choose between a lottery tier or a guaranteed allocation tier and if you win the lottery you get a guaranteed allocation in the first round (Allocation round).","The hallmark of the BSCPad is a two-round system that makes every tier level guaranteed an allocation. There is no first come first serve or bots; only fair distributed rewards for all participants.":"The hallmark of the BSCPad is a two-round system that makes every tier level guaranteed an allocation. There is no first come first serve or bots; only fair distributed rewards for all participants.","Tiered System":"Tiered System","THE BSCPAD TIERED SYSTEM":"THE BSCPAD TIERED SYSTEM","BSCPad will showcase a fixed tier system based on the number of tokens staked. Lottery Tiers will share 20% of total raise and rest 80% of the raise is assigned for guaranteed allocation tiers based on the pool weights assigned.":"BSCPad will showcase a fixed tier system based on the number of tokens staked. Lottery Tiers will share 20% of total raise and rest 80% of the raise is assigned for guaranteed allocation tiers based on the pool weights assigned.","Round 1 - Allocation Round":"Round 1 - Allocation Round","In the first round, called the \u201cAllocation Round\u201d, users can purchase the amount allotted to them based on their tier.":"In the first round, called the \u201cAllocation Round\u201d, users can purchase the amount allotted to them based on their tier.","Round 2 - FCFS ROUND":"Round 2 - FCFS ROUND","In round 2, the unsold tokens from the first round are made available on a FCFS basis, only to guaranteed tiers (Platinum and above). These members can purchase an additional amount that is determined by a tier-based formula. This round is open until all tokens are sold, typically lasting for only a few minutes. After all the tokens are sold, the IDO is concluded.":"In round 2, the unsold tokens from the first round are made available on a FCFS basis, only to guaranteed tiers (Platinum and above). These members can purchase an additional amount that is determined by a tier-based formula. This round is open until all tokens are sold, typically lasting for only a few minutes. After all the tokens are sold, the IDO is concluded.","We will be collecting both data and feedback on the IDO structure in order to optimize the system over time as well as taking into consideration community feedback and potential DAO proposals.":"We will be collecting both data and feedback on the IDO structure in order to optimize the system over time as well as taking into consideration community feedback and potential DAO proposals.","Our system is a predictable and provably fair system giving our users the proper incentives to accumulate and hold tokens and support each and every project launched.  Over time, we will tweak weights, add new tiers and change other parameters as necessary to keep the system functional, competitive and rewarding for all community members.":"Our system is a predictable and provably fair system giving our users the proper incentives to accumulate and hold tokens and support each and every project launched.  Over time, we will tweak weights, add new tiers and change other parameters as necessary to keep the system functional, competitive and rewarding for all community members.","$BSCPAD is the next evolution of blockchain launchpads solving the fundamental flaws that plague existing launchpads. This platform benefits all holders of the token and allows for fair launches giving traders of all sizes the opportunity to invest in the best upcoming Binance Smart Chain projects.":"$BSCPAD is the next evolution of blockchain launchpads solving the fundamental flaws that plague existing launchpads. This platform benefits all holders of the token and allows for fair launches giving traders of all sizes the opportunity to invest in the best upcoming Binance Smart Chain projects.","ADVISORS":"ADVISORS","Our mentors are a great part of our team.":"Our mentors are a great part of our team.","Founder at X21 Digital":"Founder at X21 Digital","Lester is the founder of X21 Digital. He incubates and supports promising projects via his marketing experience & vast connections within the blockchain ecosystem. His latest incubation projects include Blank Wallet, DAOventures and Vortex Defi.":"Lester is the founder of X21 Digital. He incubates and supports promising projects via his marketing experience & vast connections within the blockchain ecosystem. His latest incubation projects include Blank Wallet, DAOventures and Vortex Defi.","He focuses on strategic directions, token metrics, and connecting the dots as a Strategic Advisor to other projects by bringing in the RIGHT connections and resources to shortcut their success.":"He focuses on strategic directions, token metrics, and connecting the dots as a Strategic Advisor to other projects by bringing in the RIGHT connections and resources to shortcut their success.","Also Strategic Advisor to PolkaFoundry, Oddz, Project Inverse, MahaDao & Finxflo.":"Also Strategic Advisor to PolkaFoundry, Oddz, Project Inverse, MahaDao & Finxflo.","The BSCPAD team and Lester both share a common love of Blockchain Technology \u2013 and are excited to leverage his vast connections to bring mass exposure to BSCPAD. We are excited to be a part of the exclusive X21 Digital portfolio and join the other prestigious projects who have benefited from Lester\u2019s guidance.":"The BSCPAD team and Lester both share a common love of Blockchain Technology \u2013 and are excited to leverage his vast connections to bring mass exposure to BSCPAD. We are excited to be a part of the exclusive X21 Digital portfolio and join the other prestigious projects who have benefited from Lester\u2019s guidance.","Co-Founder and COO at Ferrum Network":"Co-Founder and COO at Ferrum Network","Ian Friend is the Co-Founder and COO at Ferrum Network.":"Ian Friend is the Co-Founder and COO at Ferrum Network.","CEO at Bitcoin.com Exchange \u2013 Entrepreneur, Startup Advisor, Mentor and Investor":"CEO at Bitcoin.com Exchange \u2013 Entrepreneur, Startup Advisor, Mentor and Investor","Danish Chaudhry is the CEO of Bitcoin.com Exchange, an up and coming exchange that focuses on bringing the most promising projects to market. He is an active investor and advisor, having backed some of the most prominent projects out there from an early stage such as matic (now polygon), marlin, cere, moonbeam, sifchain, flow, graph and the list goes on.":"Danish Chaudhry is the CEO of Bitcoin.com Exchange (https://exchange.bitcoin.com/), an up and coming exchange that focuses on bringing the most promising projects to market. He is an active investor and advisor, having backed some of the most prominent projects out there from an early stage such as matic (now polygon), marlin, cere, moonbeam, sifchain, flow, graph and the list goes on.","Danish has been in the blockchain space since the early days. He has a background in finance where he was a PM at Blackrock for a number of years, having founded and successfully exited two startups, he\'s built fintech and insurtech incubators at his previous VC that have produced startups valued at over $2bn.":"Danish has been in the blockchain space since the early days. He has a background in finance where he was a PM at Blackrock for a number of years, having founded and successfully exited two startups, he\'s built fintech and insurtech incubators at his previous VC that have produced startups valued at over $2bn.","EXNETWORK CAPITAL":"EXNETWORK CAPITAL","Exnetwork Capital is an investment firm focused on funding and incubating blockchain projects.":"Exnetwork Capital is an investment firm focused on funding and incubating blockchain projects.","Exnetwork Capital is an investment firm focused on funding and incubating blockchain projects. It is composed of a DAO of different investors all helping out to ensure the portfolio companies\' success.":"Exnetwork Capital is an investment firm focused on funding and incubating blockchain projects. It is composed of a DAO of different investors all helping out to ensure the portfolio companies\' success.","Exnetwork Capital\'s incubator program will help mentor BSCPAD and provide support from their network of entrepreneurs who will help take the BSC Launch Pad to new levels. Exnetwork primarily focuses on the decentralized market and can assist with many areas such as token design, fundraising, and marketing. New projects entering the launchpad will be able to glean much knowledge from the Exnetwork Capital team.":"Exnetwork Capital\'s incubator program will help mentor BSCPAD and provide support from their network of entrepreneurs who will help take the BSC Launch Pad to new levels. Exnetwork primarily focuses on the decentralized market and can assist with many areas such as token design, fundraising, and marketing. New projects entering the launchpad will be able to glean much knowledge from the Exnetwork Capital team.","We are aligned in supporting the creation and launching of new projects. We aim to help these new BSC projects to succeed and garner the same attention, hype and love as their erc counterparts.":"We are aligned in supporting the creation and launching of new projects. We aim to help these new BSC projects to succeed and garner the same attention, hype and love as their erc counterparts.","CEO and Co-founder \\r of YIELD App":"CEO and Co-founder \\r of YIELD App","Tim Frost is CEO and co-founder of YIELD App which is one of the fastest growing fintech companies in the crypto space. He has extensive experience in FinTech, marketing, business development, and operations. YIELD App is the third digital finance platform Tim has brought to the market. He was a founding member of the Wirex team and supported operations, business development, and marketing for the first 18 months. Tim also helped bring EQI Bank to the global market as a digital challenger to conventional banking, with an average client AUM of $250,000. Tim\'s experience in blockchain technology includes early involvement with numerous successful projects including QTUM, NEO, Paxful, Polymath, Selfkey and Everex. Tim has been building crypto and fintech companies since 2014.":"Tim Frost is CEO and co-founder of YIELD App which is one of the fastest growing fintech companies in the crypto space. He has extensive experience in FinTech, marketing, business development, and operations. YIELD App is the third digital finance platform Tim has brought to the market. He was a founding member of the Wirex team and supported operations, business development, and marketing for the first 18 months. Tim also helped bring EQI Bank to the global market as a digital challenger to conventional banking, with an average client AUM of $250,000. Tim\'s experience in blockchain technology includes early involvement with numerous successful projects including QTUM, NEO, Paxful, Polymath, Selfkey and Everex. Tim has been building crypto and fintech companies since 2014.","Adding Tim Frost as a strategic partner and advisor reinforces our commitment to aggressive growth for BSCPAD. Tim will help lead our efforts with his vast experience in FinTech, marketing, business development, and operations. We will be utilizing his expertise in these areas to help lead to even higher customer adoption and expansion into new industry verticals with BSCPAD.":"Adding Tim Frost as a strategic partner and advisor reinforces our commitment to aggressive growth for BSCPAD. Tim will help lead our efforts with his vast experience in FinTech, marketing, business development, and operations. We will be utilizing his expertise in these areas to help lead to even higher customer adoption and expansion into new industry verticals with BSCPAD.","Innovion has built a prestigious reputation with a unique approach to guerilla marketing, collaborating with over 200 blockchain projects.":"Innovion has built a prestigious reputation with a unique approach to guerilla marketing, collaborating with over 200 blockchain projects.","Innovion will strengthen our Public reach and further grow our client base.":"Innovion will strengthen our Public reach and further grow our client base.","Legal Partner":"Legal Partner","Silk Legal is a boutique law firm specializing in FinTech and Cryptocurrency.  We combine a deep understanding of blockchain technology with an expert knowledge of international regulations to analyze issues, risks and opportunities. Silk Legal is a proud member of Global Digital Finance, the leading global association of digital asset companies advocating for and accelerating the adoption of best practices for digital assets.":"Silk Legal is a boutique law firm specializing in FinTech and Cryptocurrency.  We combine a deep understanding of blockchain technology with an expert knowledge of international regulations to analyze issues, risks and opportunities. Silk Legal is a proud member of Global Digital Finance, the leading global association of digital asset companies advocating for and accelerating the adoption of best practices for digital assets.","CONTACT US":"CONTACT US","CONTACT":"CONTACT","Bronze":"Bronze","Silver":"Silver","Gold":"Gold","Platinum":"Platinum","Diamond":"Diamond","Blue Diamond":"Blue Diamond","Staking Requirement":"Staking Requirement","Staking Length Required":"Staking Length Required","3 hours before Allocation Round opens":"3 hours before Allocation Round opens","Whitelist Requirement Twitter":"Whitelist Requirement Twitter","Like, Comment & Retweet":"Like, Comment & Retweet","Guaranteed Allocation":"Guaranteed Allocation","Yes":"Yes","No":"No","None":"None","Pool Weight":"Pool Weight","700 + Private allocations":"700 + Private allocations","Learn more":"Learn more","Projects Closed":"Projects Closed","Projects Open Now":"Projects Open Now","Projects Coming soon":"Projects Coming soon","ATH":"ATH","Open":"Open","Closed":"Closed","Swap rate":"Swap rate","Cap":"Cap","Access":"Access","Progress":"Progress","Allocation round":"Allocation round","Participants":"Participants","No projects currently open":"No projects currently open","Opens in TBA":"Opens in TBA","Opens in":"Opens in","No projects currently coming soon":"No projects currently coming soon","Join":"Join","Pool":"Pool","Your balance":"Your balance","amount":"amount","Max":"Max","APPROVE":"APPROVE","Join Pool":"Join Pool","Your approved amount":"Your approved amount","Your tier":"Your tier","ROUND CLOSED":"ROUND CLOSED","First Come First Serve":"First Come First Serve","Closing in":"Closing in","CLOSED":"CLOSED","Swapped":"Swapped","Remaining Allocation":"Remaining Allocation","Swap progress":"Swap progress","Project details":"Project details","Schedule":"Schedule","Your Allocation":"Your Allocation","Pool information":"Pool information","Opens":"Opens","Closes":"Closes","FCFS Opens":"FCFS Opens","Swap Rate":"Swap Rate","Total Users Participated":"Total Users Participated","Total Funds Swapped":"Total Funds Swapped","Access Type":"Access Type","Token information":"Token information","Name":"Name","Token Symbol":"Token Symbol","Total Supply":"Total Supply","Token allocation":"Token allocation","Date":"Date","Token(s) claimed":"Token(s) claimed","Action":"Action","Round":"Round","Claim Tokens":"Claim Tokens","DEX Listing":"DEX Listing","Add token to <b>MetaMask</b>":"Add token to <b>MetaMask</b>","Staking Eligibility Deadline":"Staking Eligibility Deadline","IDO Launch":"IDO Launch","FCFS Round":"FCFS Round","All staking functions are temporarily paused. Please check back again later.":"All staking functions are temporarily paused. Please check back again later.","Stake":"Stake","Unstake":"Unstake","Withdraw":"Withdraw","Number of Stakers":"Number of Stakers","Total BSCPAD Staked":"Total BSCPAD Staked","APY":"APY","Staked":"Staked","Unstaked":"Unstaked","Withdrawable in":"Withdrawable in","Withdrawable Now":"Withdrawable Now","Rewards":"Rewards","Stake Rewards":"Stake Rewards","Withdraw Rewards":"Withdraw Rewards","Withdraw stake successfully":"Withdraw stake successfully","Withdraw stake fail":"Withdraw stake fail","Stake rewards successfully":"Stake rewards successfully","Stake rewards fail":"Stake rewards fail","Approve Tokens successfully!":"Approve Tokens successfully!","Failed to Approve Tokens!":"Failed to Approve Tokens!","Deposit stake fail!":"Deposit stake fail!","Stake your BSCPAD":"Stake your BSCPAD","Checkpoints":"Checkpoints","Amount to Stake":"Amount to Stake","Pre-authorization":"Pre-authorization","Confirm":"Confirm","Confirmation":"Confirmation","The following conditions must be met to proceed":"The following conditions must be met to proceed","Connected with MetaMask":"Connected with MetaMask","If not connected, click the \\"Connect Wallet\\" button in the top right corner":"If not connected, click the \\"Connect Wallet\\" button in the top right corner","BSCPAD available to deposit":"BSCPAD available to deposit","Current Balance":"Current Balance","BNB available in wallet":"BNB available in wallet","BNB is required to pay transaction fees on the Binance Smart Chain network.":"BNB is required to pay transaction fees on the Binance Smart Chain network.","BNB Balance":"BNB Balance","Eligible to stake":"Eligible to stake","You cannot stake if you have an active BSCPAD unstake/withdrawal request":"You cannot stake if you have an active BSCPAD unstake/withdrawal request","I have read the":"I have read the","Terms and Conditions":"Terms and Conditions","Please enter the amount of BSCPAD you want to stake":"Please enter the amount of BSCPAD you want to stake","Amount":"Amount","MAX":"MAX","Balance":"Balance","Required transaction 1 of 2":"Required transaction 1 of 2","In this step, you grant access to the staking smart contract to accept your BSCPAD":"In this step, you grant access to the staking smart contract to accept your BSCPAD","Waiting for the transaction to complete":"Waiting for the transaction to complete","Please wait for the transaction to confirm before proceeding.":"Please wait for the transaction to confirm before proceeding.","Required transaction 2 of 2":"Required transaction 2 of 2","In this step, you deposit the tokens into the staking contract.":"In this step, you deposit the tokens into the staking contract.","After this step, your tokens will be successfully staked.":"After this step, your tokens will be successfully staked.","Success":"Success","Congratulations! Your tokens are now staked.":"Congratulations! Your tokens are now staked.","If desired, you may check Binance Smart Chain to confirm the transaction.":"If desired, you may check Binance Smart Chain to confirm the transaction.","Previous":"Previous","Next":"Next","Done":"Done","Unstake your BSCSPAD":"Unstake your BSCSPAD","Warning":"Warning","Amount to Unstake":"Amount to Unstake","Initialize Unstake":"Initialize Unstake","After Unstaking, you must wait 7 days before you can withdraw your BSCPAD and rewards.":"After Unstaking, you must wait 7 days before you can withdraw your BSCPAD and rewards.","The amount of tokens you Unstake will not count towards your tier level for upcoming":"The amount of tokens you Unstake will not count towards your tier level for upcoming","Have an active BSCPAD stake":"Have an active BSCPAD stake","You currently have":"You currently have","BSCPad staked":"BSCPad staked","Eligible to initiate unstake":"Eligible to initiate unstake","You cannot unstake if you already have an active BSCPAD unstake/withdrawal request":"You cannot unstake if you already have an active BSCPAD unstake/withdrawal request","Please enter the amount of BSCPAD you want to unstake":"Please enter the amount of BSCPAD you want to unstake","Confirm Unstaking Process":"Confirm Unstaking Process","In this step, you initiate the unstaking process. After a 7 day waiting period, you will be allowed to withdraw your BSCPAD":"In this step, you initiate the unstaking process. After a 7 day waiting period, you will be allowed to withdraw your BSCPAD","Confirmed":"Confirmed","You have initiated the unstaking process and started the 7 day timer.":"You have initiated the unstaking process and started the 7 day timer.","Withdraw your BSCPAD":"Withdraw your BSCPAD","Initialize Withdrawal":"Initialize Withdrawal","7 day waiting period elapsed":"7 day waiting period elapsed","You have Unstaked your BSCPAD":"You have Unstaked your BSCPAD","Confirm Withdrawal":"Confirm Withdrawal","In this step, you complete the transaction that withdraws your BSCPAD tokens":"In this step, you complete the transaction that withdraws your BSCPAD tokens","You have withdrawn your BSCPAD tokens.":"You have withdrawn your BSCPAD tokens."}')
        },
        440: function(e) {
            e.exports = JSON.parse('{"Connect to wallet":"\u8fde\u63a5\u94b1\u5305","Your wallet":"Your wallet","Copy Address":"Copy Address","View on BscScan":"View on BscScan","Logout":"\u767b\u51fa","Connect Wallet":"\u5173\u8054\u94b1\u5305","How to connect wallet":"How to connect wallet","KYC Help":"KYC Help","KYC":"KYC","Sync KYC":"Sync KYC","Projects":"\u9879\u76ee","Staking":"\u653e\u6837","Copyright \xa9":"\u7248\u6743\u6240\u6709 \xa9","All Rights Reserved by BSCPad":"BSCPad \u4fdd\u7559\u6240\u6709\u6743\u5229\u3002","Privacy Policy":"\u9690\u79c1\u653f\u7b56","Terms of Use":"\u4f7f\u7528\u6761\u6b3e","BSCPAD is the first decentralized IDO platform for the Binance Smart Chain Network.":"BSCPad\u662f\u9996\u4e2a\u5728\u5e01\u5b89\u667a\u80fd\u94fe\u4e0a\u7684IDO\u53d1\u884c\u5e73\u53f0\u3002","BSCPad will empower crypto currency projects with the ability to distribute tokens and raise liquidity.":"BSCPad\u66ff\u6295\u8d44\u8005\u3001\u52a0\u5bc6\u8d27\u5e01\u9879\u76ee\u65b9\u4e3a\u65b0\u7684DeFi \u9879\u76ee\u63d0\u4f9b\u4ee3\u5e01\u9500\u552e","View all Projects":"\u67e5\u770b\u5168\u90e8\u9879\u76ee","Buy on":"Buy on","Apply for IDO":"\u7533\u8bf7 IDO","White Paper":"White Paper","Join us on Telegram":"\u5728 Telegram \u4e0a\u52a0\u5165\u6211\u4eec","Follow our Medium":"\u5173\u6ce8\u6211\u4eec\u7684 Medium","Follow our Twitter":"\u5173\u6ce8\u6211\u4eec\u7684 Twitter","Our Partners":"Our Partners","ABOUT US":"\u5173\u4e8e\u6211\u4eec","What and Why":"\u6df1\u5165\u4e86\u89e3","WHAT IS BSCPAD?":"\u4ec0\u4e48\u662f BSCPAD?","The BSC Launch Pad is the first decentralized IDO platform for the Binance Smart Chain Network.":"BSCPad\u662f\u9996\u4e2a\u5728\u5e01\u5b89\u667a\u80fd\u94fe\u4e0a\u7684IDO\u53d1\u884c\u5e73\u53f0","WHY CHOOSE US?":"\u4e3a\u4f55\u9009\u62e9\u6211\u4eec\uff1f","BSCPad has found a solution to incentivize and reward all token stakers in a way that is inclusive and with a low barrier to entry.":" BSCPad \u63d0\u4f9b\u4e00\u79cd\u5305\u5bb9\u6027\u548c\u4f4e\u51c6\u5165\u95e8\u69db\u7684\u65b9\u5f0f\u6765\u6fc0\u52b1\u548c\u5956\u52b1\u6240\u6709\u4ee3\u5e01\u6301\u6709\u8005","The fundamental flaws of existing launchpads is that acquiring enough tokens to participate in the ecosystem is prohibitive, and even if you do stake the tokens, you are not guaranteed an allocation spot. They are based on a first come first serve basis where automated bots can fill the whitelist spots in a matter of seconds. BSCPad is creating fair decentralized launches, you can choose between a lottery tier or a guaranteed allocation tier and if you win the lottery you get a guaranteed allocation in the first round (Allocation round).":"\u73b0\u6709IDO\u5e73\u53f0\u7684\u7f3a\u70b9\u662f\uff0c\u6301\u6709\u8db3\u591f\u7684\u4ee3\u5e01\u53c2\u4e0e\u751f\u6001\u7cfb\u7edf\u662f\u6602\u8d35\u4e14\u9ad8\u95e8\u574e\u7684\uff0c\u5373\u4f7f\u4f60\u6301\u6709\u4ee3\u5e01\uff0c\u6700\u7ec8\u4e5f\u4e0d\u80fd\u4fdd\u8bc1\u4f60\u80fd\u83b7\u5f97\u5206\u53d1\u91cf\u3002\u8fd9\u4e9b\u5e73\u53f0\u673a\u5236\u662f\u91c7\u53d6\u5148\u5230\u5148\u5f97\u7684\u57fa\u7840\u4e0a\uff0c\u5bb9\u6613\u5f15\u53d1\u673a\u5668\u4eba\u4e8e\u51e0\u79d2\u949f\u5185\u586b\u8865\u767d\u540d\u5355\u91cf\u3002<b><i>BSCPad\u6b63\u5728\u521b\u5efa\u516c\u5e73\u7684\u53d1\u884c\u4e0e\u5206\u914d\u673a\u5236\u3002</i></b>","The hallmark of the BSCPad is a two-round system that makes every tier level guaranteed an allocation. There is no first come first serve or bots; only fair distributed rewards for all participants.":"BSCPad \u7684\u7279\u70b9\u662f\u91c7\u53d6\u4e86\u53cc\u56de\u5408\u7684\u7cfb\u7edf\uff0c \u8fd9\u5c31\u7ed9\u4e86\u6bcf\u4e2a\u5c42\u7ea7\u4e00\u4e2a\u6709\u4fdd\u969c\u7684\u5206\u914d\u91cf\u3002\u65e0\u9700\u8fd0\u6c14\u3001\u5f69\u7968\uff0c\u4e5f\u6ca1\u6709\u673a\u5668\u4eba\u7684\u53c2\u4e0e; \u5c06\u4fdd\u969c\u6240\u6709\u5c42\u7ea7\u53c2\u4e0e\u8005\u5747\u80fd\u516c\u5e73\u83b7\u5f97\u5206\u914d\u5956\u52b1\u3002","Tiered System":"\u5206\u5c42\u4f53\u7cfb","THE BSCPAD TIERED SYSTEM":"BSCPAD \u5206\u5c42\u4f53\u7cfb","BSCPad will showcase a fixed tier system based on the number of tokens staked. Lottery Tiers will share 20% of total raise and rest 80% of the raise is assigned for guaranteed allocation tiers based on the pool weights assigned.":"BSCPad\u662f\u57fa\u4e8e\u6301\u6709\u7684\u4ee3\u5e01\u6570\u91cf\u5c55\u793a\u53c2\u4e0e\u5c42\u7ea7\u3002","Round 1 - Allocation Round":"\u7b2c1\u8f6e-\u5206\u914d\u8f6e","In the first round, called the \u201cAllocation Round\u201d, users can purchase the amount allotted to them based on their tier.":"\u5728\u7b2c\u4e00\u8f6e\uff0c\u79f0\u4e3a\u201c\u5206\u914d\u8f6e\u201d\uff0c\u7528\u6237\u6839\u636e\u4ed6\u4eec\u7684\u5c42\u7ea7\u8d2d\u4e70\u53ef\u5206\u914d\u7684\u6570\u91cf\u3002","Round 2 - FCFS ROUND":"\u7b2c 2 \u8f6e - \u5148\u5230\u5148\u5f97\u8f6e","In round 2, the unsold tokens from the first round are made available on a FCFS basis, only to guaranteed tiers (Platinum and above). These members can purchase an additional amount that is determined by a tier-based formula. This round is open until all tokens are sold, typically lasting for only a few minutes. After all the tokens are sold, the IDO is concluded.":"\u7b2c 2 \u8f6e\u4ec5\u5411\u4fdd\u8bc1\u7ea7\u522b\uff08\u767d\u91d1\u53ca\u66f4\u9ad8\uff09\u6309\u5148\u5230\u5148\u5f97\u7684\u987a\u5e8f\u51fa\u552e\u7b2c\u4e00\u8f6e\u4e2d\u672a\u552e\u51fa\u7684\u4ee3\u5e01\u3002\u8fd9\u4e9b\u4f1a\u5458\u53ef\u8d2d\u4e70\u989d\u5916\u7684\u6570\u989d\uff0c\u6570\u989d\u7531\u4e0e\u7ea7\u522b\u76f8\u5173\u7684\u516c\u5f0f\u786e\u5b9a\u3002\u6b64\u8f6e\u5c06\u5f00\u653e\u81f3\u6240\u6709\u4ee3\u5e01\u5168\u90e8\u552e\u51fa\u4e3a\u6b62\uff0c\u901a\u5e38\u53ea\u4f1a\u6301\u7eed\u51e0\u5206\u949f\u3002\u5168\u90e8\u4ee3\u5e01\u552e\u51fa\u540e\uff0cIDO \u5373\u5ba3\u544a\u7ed3\u675f\u3002","We will be collecting both data and feedback on the IDO structure in order to optimize the system over time as well as taking into consideration community feedback and potential DAO proposals.":"\u6211\u4eec\u5c06\u6536\u96c6IDO\u7ed3\u6784\u7684\u6570\u636e\u548c\u53cd\u9988\uff0c\u4ee5\u4fbf\u968f\u7740\u65f6\u95f4\u7684\u63a8\u79fb\u4f18\u5316\u7cfb\u7edf\uff0c\u540c\u65f6\u8003\u8651\u793e\u533a\u53cd\u9988\u548c\u6f5c\u5728\u7684DAO\u5efa\u8bae\u3002","Our system is a predictable and provably fair system giving our users the proper incentives to accumulate and hold tokens and support each and every project launched.  Over time, we will tweak weights, add new tiers and change other parameters as necessary to keep the system functional, competitive and rewarding for all community members.":"\u201c\u6211\u4eec\u7684\u5236\u5ea6\u662f\u4e00\u4e2a\u53ef\u9884\u6d4b\u548c\u53ef\u8bc1\u660e\u7684\u516c\u5e73\u5236\u5ea6 \u6211\u4eec\u7684\u7528\u6237\u80fd\u83b7\u5f97\u516c\u5e73\u7684\u5956\u52b1\uff0c\u6765\u79ef\u7d2f\u548c\u6301\u6709\u4ee3\u5e01\uff0c\u540c\u65f6\u652f\u6301\u6bcf\u4e2a\u65b0\u9879\u76ee\u3002\u968f\u7740\u65f6\u95f4\uff0c\u6211\u4eec\u5c06\u8c03\u6574\u6743\u91cd\uff0c\u6dfb\u52a0\u65b0\u7684\u5c42\u7ea7\uff0c\u5e76\u6839\u636e\u9700\u8981\u66f4\u6539\u5176\u4ed6\u53c2\u6570\uff0c\u4ee5\u4fdd\u6301\u7cfb\u7edf\u7684\u529f\u80fd\u6027\u3001\u7ade\u4e89\u529b\u548c\u5bf9\u6240\u6709\u793e\u533a\u6210\u5458\u7684\u5956\u52b1\u3002\u201d","$BSCPAD is the next evolution of blockchain launchpads solving the fundamental flaws that plague existing launchpads. This platform benefits all holders of the token and allows for fair launches giving traders of all sizes the opportunity to invest in the best upcoming Binance Smart Chain projects.":"$BSCPAD\u662f\u533a\u5757\u94fe\u542f\u52a8\u5e73\u53f0\u7684\u4e0b\u4e00\u4e2a\u6f14\u8fdb\uff0c\u5b83\u89e3\u51b3\u4e86\u56f0\u6270\u73b0\u6709\u542f\u52a8\u5e73\u53f0\u7684\u6839\u672c\u7f3a\u9677\u3002\u8be5\u5e73\u53f0\u4f7f\u4ee3\u5e01\u7684\u6240\u6709\u6301\u6709\u4eba\u53d7\u76ca\uff0c\u5e76\u5141\u8bb8\u516c\u5e73\u63a8\u51fa\uff0c\u4f7f\u5404\u79cd\u89c4\u6a21\u7684\u4ea4\u6613\u5458\u6709\u673a\u4f1a\u6295\u8d44\u4e8e\u5373\u5c06\u63a8\u51fa\u7684\u6700\u4f73Binance\u667a\u80fd\u94fe\u9879\u76ee\u3002","ADVISORS":"\u987e\u95ee","Our mentors are a great part of our team.":"\u6211\u4eec\u7684\u5bfc\u5e08\u662f\u6211\u4eec\u56e2\u961f\u7684\u91cd\u8981\u7ec4\u6210\u90e8\u5206\u3002","Founder at X21 Digital":"X21 Digital\u521b\u59cb\u4eba","Lester is the founder of X21 Digital. He incubates and supports promising projects via his marketing experience & vast connections within the blockchain ecosystem. His latest incubation projects include Blank Wallet, DAOventures and Vortex Defi.":"Lester is the founder of X21 Digital. He incubates and supports promising projects via his marketing experience & vast connections within the blockchain ecosystem. His latest incubation projects include Blank Wallet, DAOventures and Vortex Defi.","He focuses on strategic directions, token metrics, and connecting the dots as a Strategic Advisor to other projects by bringing in the RIGHT connections and resources to shortcut their success.":"He focuses on strategic directions, token metrics, and connecting the dots as a Strategic Advisor to other projects by bringing in the RIGHT connections and resources to shortcut their success.","Also Strategic Advisor to PolkaFoundry, Oddz, Project Inverse, MahaDao & Finxflo.":"Also Strategic Advisor to PolkaFoundry, Oddz, Project Inverse, MahaDao & Finxflo.","The BSCPAD team and Lester both share a common love of Blockchain Technology \u2013 and are excited to leverage his vast connections to bring mass exposure to BSCPAD. We are excited to be a part of the exclusive X21 Digital portfolio and join the other prestigious projects who have benefited from Lester\u2019s guidance.":"The BSCPAD team and Lester both share a common love of Blockchain Technology \u2013 and are excited to leverage his vast connections to bring mass exposure to BSCPAD. We are excited to be a part of the exclusive X21 Digital portfolio and join the other prestigious projects who have benefited from Lester\u2019s guidance.","Co-Founder and COO at Ferrum Network":"Ferrum Network\u8054\u5408\u521b\u59cb\u4eba\u517c\u9996\u5e2d\u8fd0\u8425\u5b98","Ian Friend is the Co-Founder and COO at Ferrum Network.":"Ian Friend is the Co-Founder and COO at Ferrum Network.","CEO at Bitcoin.com Exchange \u2013 Entrepreneur, Startup Advisor, Mentor and Investor":"\u6bd4\u7279\u5e01\u4ea4\u6613\u6240\u9996\u5e2d\u6267\u884c\u5b98\u2014\u2014\u4f01\u4e1a\u5bb6\u3001\u521b\u4e1a\u987e\u95ee\u3001\u5bfc\u5e08\u548c\u6295\u8d44\u8005","Danish Chaudhry is the CEO of Bitcoin.com Exchange, an up and coming exchange that focuses on bringing the most promising projects to market. He is an active investor and advisor, having backed some of the most prominent projects out there from an early stage such as matic (now polygon), marlin, cere, moonbeam, sifchain, flow, graph and the list goes on.":"Danish Chaudhry is the CEO of Bitcoin.com Exchange, an up and coming exchange that focuses on bringing the most promising projects to market. He is an active investor and advisor, having backed some of the most prominent projects out there from an early stage such as matic (now polygon), marlin, cere, moonbeam, sifchain, flow, graph and the list goes on.","Danish has been in the blockchain space since the early days. He has a background in finance where he was a PM at Blackrock for a number of years, having founded and successfully exited two startups, he\'s built fintech and insurtech incubators at his previous VC that have produced startups valued at over $2bn.":"Danish has been in the blockchain space since the early days. He has a background in finance where he was a PM at Blackrock for a number of years, having founded and successfully exited two startups, he\'s built fintech and insurtech incubators at his previous VC that have produced startups valued at over $2bn.","EXNETWORK CAPITAL":"EXNETWORK \u8d44\u672c","Exnetwork Capital is an investment firm focused on funding and incubating blockchain projects.":"Exnetwork \u8d44\u672c\u662f\u4e00\u5bb6\u4e13\u6ce8\u4e8e\u4e3a\u533a\u5757\u94fe\u9879\u76ee\u878d\u8d44\u548c\u5b75\u5316\u7684\u6295\u8d44\u516c\u53f8\u3002\u201d","Exnetwork Capital is an investment firm focused on funding and incubating blockchain projects. It is composed of a DAO of different investors all helping out to ensure the portfolio companies\' success.":"Exnetwork Capital is an investment firm focused on funding and incubating blockchain projects. It is composed of a DAO of different investors all helping out to ensure the portfolio companies\' success.","Exnetwork Capital\'s incubator program will help mentor BSCPAD and provide support from their network of entrepreneurs who will help take the BSC Launch Pad to new levels. Exnetwork primarily focuses on the decentralized market and can assist with many areas such as token design, fundraising, and marketing. New projects entering the launchpad will be able to glean much knowledge from the Exnetwork Capital team.":"Exnetwork Capital\'s incubator program will help mentor BSCPAD and provide support from their network of entrepreneurs who will help take the BSC Launch Pad to new levels. Exnetwork primarily focuses on the decentralized market and can assist with many areas such as token design, fundraising, and marketing. New projects entering the launchpad will be able to glean much knowledge from the Exnetwork Capital team.","We are aligned in supporting the creation and launching of new projects. We aim to help these new BSC projects to succeed and garner the same attention, hype and love as their erc counterparts.":"We are aligned in supporting the creation and launching of new projects. We aim to help these new BSC projects to succeed and garner the same attention, hype and love as their erc counterparts.","CEO and Co-founder \\r of YIELD App":"YIELD App\u9996\u5e2d\u6267\u884c\u5b98\u517c\u8054\u5408\u521b\u59cb\u4eba","Tim Frost is CEO and co-founder of YIELD App which is one of the fastest growing fintech companies in the crypto space. He has extensive experience in FinTech, marketing, business development, and operations. YIELD App is the third digital finance platform Tim has brought to the market. He was a founding member of the Wirex team and supported operations, business development, and marketing for the first 18 months. Tim also helped bring EQI Bank to the global market as a digital challenger to conventional banking, with an average client AUM of $250,000. Tim\'s experience in blockchain technology includes early involvement with numerous successful projects including QTUM, NEO, Paxful, Polymath, Selfkey and Everex. Tim has been building crypto and fintech companies since 2014.":"Tim Frost is CEO and co-founder of YIELD App which is one of the fastest growing fintech companies in the crypto space. He has extensive experience in FinTech, marketing, business development, and operations. YIELD App is the third digital finance platform Tim has brought to the market. He was a founding member of the Wirex team and supported operations, business development, and marketing for the first 18 months. Tim also helped bring EQI Bank to the global market as a digital challenger to conventional banking, with an average client AUM of $250,000. Tim\'s experience in blockchain technology includes early involvement with numerous successful projects including QTUM, NEO, Paxful, Polymath, Selfkey and Everex. Tim has been building crypto and fintech companies since 2014.","Adding Tim Frost as a strategic partner and advisor reinforces our commitment to aggressive growth for BSCPAD. Tim will help lead our efforts with his vast experience in FinTech, marketing, business development, and operations. We will be utilizing his expertise in these areas to help lead to even higher customer adoption and expansion into new industry verticals with BSCPAD.":"Adding Tim Frost as a strategic partner and advisor reinforces our commitment to aggressive growth for BSCPAD. Tim will help lead our efforts with his vast experience in FinTech, marketing, business development, and operations. We will be utilizing his expertise in these areas to help lead to even higher customer adoption and expansion into new industry verticals with BSCPAD.","Innovion has built a prestigious reputation with a unique approach to guerilla marketing, collaborating with over 200 blockchain projects.":"Innovion has built a prestigious reputation with a unique approach to guerilla marketing, collaborating with over 200 blockchain projects.","Innovion will strengthen our Public reach and further grow our client base.":"Innovion will strengthen our Public reach and further grow our client base.","Legal Partner":"\u6cd5\u5f8b\u5408\u4f5c\u4f19\u4f34","Silk Legal is a boutique law firm specializing in FinTech and Cryptocurrency.  We combine a deep understanding of blockchain technology with an expert knowledge of international regulations to analyze issues, risks and opportunities. Silk Legal is a proud member of Global Digital Finance, the leading global association of digital asset companies advocating for and accelerating the adoption of best practices for digital assets.":"Silk Legal \u662f\u4e00\u5bb6\u4e13\u6ce8\u4e8e\u91d1\u878d\u79d1\u6280\u548c\u52a0\u5bc6\u8d27\u5e01\u7684\u9ad8\u7ea7\u5f8b\u5e08\u4e8b\u52a1\u6240\u3002\u6211\u4eec\u7ed3\u5408\u5bf9\u533a\u5757\u94fe\u6280\u672f\u7684\u77e5\u8bc6\u548c\u4e13\u5bb6\uff0c\u53c2\u8003\u56fd\u9645\u6cd5\u89c4\u5206\u6790\u95ee\u9898\u3001\u98ce\u9669\u548c\u673a\u4f1a\u3002 Silk Legal \u662fGlobal Digital Finance\u534f\u4f1a\u7684\u9ad8\u9636\u6210\u5458\uff0c\u5b83\u662f\u5168\u7403\u9886\u5148\u7684\u6570\u5b57\u8d44\u4ea7\u516c\u53f8\u534f\u4f1a\uff0c\u63d0\u5021\u5e76\u52a0\u901f\u91c7\u7528\u6570\u5b57\u8d44\u4ea7\u3002\u201d","CONTACT US":"\u8054\u7cfb\u6211\u4eec","CONTACT":"\u8054\u7cfb\u65b9\u5f0f","Bronze":"\u9752\u94dc\u4f1a\u5458","Silver":"\u767d\u94f6\u4f1a\u5458","Gold":"\u9ec4\u91d1\u4f1a\u5458","Platinum":"\u767d\u91d1\u4f1a\u5458","Diamond":"\u94bb\u77f3\u4f1a\u5458","Blue Diamond":"B\u84dd\u94bb","Staking Requirement":"\u8d28\u62bc\u8981\u6c42","Staking Length Required":"\u8d28\u62bc\u65f6\u957f\u8981\u6c42","3 hours before Allocation Round opens":"\u5206\u914d\u8f6e\u524d3\u5c0f\u65f6","Whitelist Requirement Twitter":"Twitter\u7684\u767d\u540d\u5355\u4efb\u52a1","Like, Comment & Retweet":"\u559c\u6b22\u3001\u8bc4\u8bba\u548c\u8f6c\u53d1","Guaranteed Allocation":"\u4efd\u4fdd\u8bc1\u989d\u5ea6","Yes":"\u662f","No":"No","None":"None","Pool Weight":"\u6743\u91cd","700 + Private allocations":"700\u4e2a\u4ee5\u4e0a\u79c1\u4eba\u5206\u914d\u91cf","Learn more":"\u4e86\u89e3\u8be6\u60c5","Projects Closed":"\u9879\u76ee\u5173\u95ed","Projects Open Now":"\u9879\u76ee\u73b0\u5728\u5f00\u653e","Projects Coming soon":"\u5373\u5c06\u63a8\u51fa\u9879\u76ee","ATH":"ATH","Open":"Open","Closed":"Closed","Swap rate":"Swap rate","Cap":"Cap","Access":"Access","Progress":"Progress","Allocation round":"Allocation round","Participants":"Participants","No projects currently open":"No projects currently open","Opens in TBA":"Opens in TBA","Opens in":"Opens in","No projects currently coming soon":"No projects currently coming soon","Join":"Join","Pool":"Pool","Your balance":"Your balance","amount":"amount","Max":"Max","APPROVE":"APPROVE","Join Pool":"Join Pool","Your approved amount":"Your approved amount","Your tier":"Your tier","ROUND CLOSED":"ROUND CLOSED","First Come First Serve":"First Come First Serve","Closing in":"Closing in","CLOSED":"CLOSED","Swapped":"Swapped","Remaining Allocation":"Remaining Allocation","Swap progress":"Swap progress","Project details":"Project details","Schedule":"Schedule","Your Allocation":"Your Allocation","Pool information":"Pool information","Opens":"\u5f00\u653e","Closes":"Closes","FCFS Opens":"FCFS \u5f00\u653e","Total Users Participated":"Total Users Participated","Total Funds Swapped":"Total Funds Swapped","Access Type":"Access Type","Token information":"Token information","Name":"Name","Token Symbol":"Token Symbol","Total Supply":"Total Supply","No.":"No.","Token allocation":"Token allocation","Date":"Date","Token(s) claimed":"Token(s) claimed","Action":"Action","Round":"Round","Claim Tokens":"Claim Tokens","DEX Listing":"DEX Listing","Add token to <b>MetaMask</b>":"Add token to <b>MetaMask</b>","Staking Eligibility Deadline":"Staking Eligibility Deadline","IDO Launch":"IDO Launch","FCFS Round":"FCFS Round","All staking functions are temporarily paused. Please check back again later.":"All staking functions are temporarily paused. Please check back again later.","Stake":"\u8d28\u62bc","Unstake":"\u672a\u8d28\u62bc","Withdraw":"\u63d0\u73b0","Number of Stakers":"\u8d28\u62bc\u91cf","Total BSCPAD Staked":"\u603bBSCPAD\u8d28\u62bc\u91cf","APY":"APY\u94b1\u5305","Staked":"\u5df2\u8d28\u62bc","Unstaked":"\u672a\u8d28\u62bc","Withdrawable in":"Withdrawable in","Withdrawable Now":"Withdrawable Now","Rewards":"\u5956\u52b1","Stake Rewards":"\u80a1\u6743\u5956\u52b1","Withdraw Rewards":"\u63d0\u53d6\u5956\u52b1","Withdraw stake successfully":"Withdraw stake successfully","Withdraw stake fail":"Withdraw stake fail","Stake rewards successfully":"Stake rewards successfully","Stake rewards fail":"Stake rewards fail","Approve Tokens successfully!":"Approve Tokens successfully!","Failed to Approve Tokens!":"Failed to Approve Tokens!","Deposit stake fail!":"Deposit stake fail!","Stake your BSCPAD":"\u5728BSCPAD\u5e73\u53f0\u4e0a\u8d28\u62bc","Checkpoints":"\u68c0\u67e5\u7ad9","Amount to Stake":"\u53c2\u4e0e\u8d28\u62bc\u91cf","Pre-authorization":"\u9884\u6388\u6743","Confirm":"\u786e\u8ba4","Confirmation":"\u786e\u8ba4","The following conditions must be met to proceed":"\u5fc5\u987b\u6ee1\u8db3\u4ee5\u4e0b\u6761\u4ef6\u624d\u80fd\u7ee7\u7eed","Connected with MetaMask":"\u8fde\u63a5MetaMask\u94b1\u5305","If not connected, click the \\"Connect Wallet\\" button in the top right corner":"\u5982\u679c\u672a\u8fde\u63a5, \u8bf7\u70b9\u51fb\u53f3\u4e0a\u89d2 \\"\u8fde\u63a5\u94b1\u5305\\" \u6309\u94ae","BSCPAD available to deposit":"BSCPAD\u53ef\u5b58\u5165","Current Balance":"\u5f53\u524d\u4f59\u989d","BNB available in wallet":"BNB\u94b1\u5305\u4f59\u989d","BNB is required to pay transaction fees on the Binance Smart Chain network.":"BNB\u9700\u8981\u5728\u5e01\u5b89\u667a\u80fd\u94fe\u7f51\u7edc\u4e0a\u652f\u4ed8\u4ea4\u6613\u8d39\u7528\u3002","BNB Balance":"BNB\u4f59\u989d","Eligible to stake":"\u53c2\u4e0e\u8d28\u62bc\u8d44\u683c","You cannot stake if you have an active BSCPAD unstake/withdrawal request":"\u9700\u6301\u6709\u5df2\u6fc0\u6d3b\u7684BSCPAD\u8d26\u6237\u624d\u80fd\u53c2\u4e0e\u8d28\u62bc","I have read the":"\u6761\u6b3e\u548c\u6761\u4ef6","Terms and Conditions":"\u6761\u6b3e\u548c\u6761\u4ef6","Please enter the amount of BSCPAD you want to stake":"Please enter the amount of BSCPAD you want to stake","Amount":"\u6570\u91cf","MAX":"\u6700\u5927\u503c","Balance":"Balance","Required transaction 1 of 2":"Required transaction 1 of 2","In this step, you grant access to the staking smart contract to accept your BSCPAD":"In this step, you grant access to the staking smart contract to accept your BSCPAD","Waiting for the transaction to complete":"Waiting for the transaction to complete","Please wait for the transaction to confirm before proceeding.":"Please wait for the transaction to confirm before proceeding.","Required transaction 2 of 2":"Required transaction 2 of 2","In this step, you deposit the tokens into the staking contract.":"In this step, you deposit the tokens into the staking contract.","After this step, your tokens will be successfully staked.":"After this step, your tokens will be successfully staked.","Success":"\u6210\u529f","Congratulations! Your tokens are now staked.":"Congratulations! Your tokens are now staked.","If desired, you may check Binance Smart Chain to confirm the transaction.":"If desired, you may check Binance Smart Chain to confirm the transaction.","Previous":"\u4e0a\u4e00\u9875","Next":"\u4e0b\u4e00\u9875","Done":"\u5b8c\u6bd5","Unstake your BSCSPAD":"\u89e3\u4ed3\u4f60\u7684BSCPAD","Warning":"\u8b66\u544a","Amount to Unstake":"\u89e3\u4ed3\u6570\u91cf","Initialize Unstake":"\u521d\u59cb\u89e3\u4ed3\u91cf","After Unstaking, you must wait 7 days before you can withdraw your BSCPAD and rewards.":"\u89e3\u4ed3\u540e\uff0c\u60a8\u5fc5\u987b\u7b49\u5f857\u5929\u624d\u80fd\u63d0\u53d6\u60a8\u7684BSCPAD\u548c\u5956\u52b1","The amount of tokens you Unstake will not count towards your tier level for upcoming":"\u60a8\u89e3\u4ed3\u7684\u4ee3\u5e01\u6570\u91cf\u4e0d\u4f1a\u8ba1\u5165\u60a8\u5373\u5c06\u8fdb\u884c\u7684\u9879\u76ee\u5c42\u7ea7\u3002","Have an active BSCPAD stake":"Have an active BSCPAD stake","You currently have":"You currently have","BSCPad staked":"BSCPad staked","Eligible to initiate unstake":"Eligible to initiate unstake","You cannot unstake if you already have an active BSCPAD unstake/withdrawal request":"You cannot unstake if you already have an active BSCPAD unstake/withdrawal request","Please enter the amount of BSCPAD you want to unstake":"Please enter the amount of BSCPAD you want to unstake","Confirm Unstaking Process":"Confirm Unstaking Process","In this step, you initiate the unstaking process. After a 7 day waiting period, you will be allowed to withdraw your BSCPAD":"In this step, you initiate the unstaking process. After a 7 day waiting period, you will be allowed to withdraw your BSCPAD","Confirmed":"Confirmed","You have initiated the unstaking process and started the 7 day timer.":"You have initiated the unstaking process and started the 7 day timer.","Withdraw your BSCPAD":"\u63d0\u51fa\u4f60\u7684BSCPAD","Initialize Withdrawal":"\u521d\u59cb\u9501\u4ed3\u63d0\u73b0","7 day waiting period elapsed":"7\u5929\u7b49\u5f85\u671f\u5df2\u8fc7","You have Unstaked your BSCPAD":"\u4f60\u5df2\u89e3\u4ed3\u4f60\u7684BSCPAD","Confirm Withdrawal":"Confirm Withdrawal","In this step, you complete the transaction that withdraws your BSCPAD tokens":"In this step, you complete the transaction that withdraws your BSCPAD tokens","You have withdrawn your BSCPAD tokens.":"You have withdrawn your BSCPAD tokens."}')
        },
        466: function(e, t, a) {
            e.exports = a(1081)
        },
        723: function(e, t, a) {
            a(724).config(), e.exports = {
                BLOCKCHAIN_NETWORK: "MAINNET",
                BSC_EXPLORER: "https://bscscan.com",
                BSC_NODE_URL: ["https://bsc-dataseed1.ninicoin.io/", "https://bsc-dataseed.binance.org/", "https://bsc-dataseed1.defibit.io/"],
                BSCPAD_ADDRESS: "0x5A3010d4d8D3B5fB49f8B6E57FB9E48063f16700",
                BACKEND_URL: "https://bscpad.com",
                STAKING_CONTRACT_ADDRESS: "0x100e9DFb6F42E19935df75eF616A63FEEC2EF4CF",
                BSC_KYC_ADDRESS: "0xC3E818F91b62Aa54B9a27F0f90721cF73558104E"
            }
        },
        734: function(e, t) {},
        775: function(e, t) {},
        777: function(e, t) {},
        840: function(e, t) {},
        842: function(e, t) {},
        852: function(e, t) {},
        854: function(e, t) {},
        879: function(e, t) {},
        88: function(e) {
            e.exports = JSON.parse('[{"anonymous":false,"inputs":[{"indexed":false,"internalType":"address","name":"account","type":"address"}],"name":"Paused","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"internalType":"uint256","name":"amount","type":"uint256"}],"name":"RewardsDistributed","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"account","type":"address"},{"indexed":false,"internalType":"uint256","name":"reward","type":"uint256"}],"name":"RewardsStaked","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"account","type":"address"},{"indexed":false,"internalType":"uint256","name":"reward","type":"uint256"}],"name":"RewardsWithdrawn","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"bytes32","name":"role","type":"bytes32"},{"indexed":true,"internalType":"address","name":"account","type":"address"},{"indexed":true,"internalType":"address","name":"sender","type":"address"}],"name":"RoleGranted","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"bytes32","name":"role","type":"bytes32"},{"indexed":true,"internalType":"address","name":"account","type":"address"},{"indexed":true,"internalType":"address","name":"sender","type":"address"}],"name":"RoleRevoked","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"account","type":"address"},{"indexed":false,"internalType":"uint256","name":"amount","type":"uint256"}],"name":"Staked","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"internalType":"address","name":"account","type":"address"}],"name":"Unpaused","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"account","type":"address"},{"indexed":false,"internalType":"uint256","name":"amount","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"initiateDate","type":"uint256"}],"name":"Unstaked","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"account","type":"address"},{"indexed":false,"internalType":"uint256","name":"amount","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"reward","type":"uint256"}],"name":"Withdrawn","type":"event"},{"inputs":[],"name":"DEFAULT_ADMIN_ROLE","outputs":[{"internalType":"bytes32","name":"","type":"bytes32"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"MAX_INT","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"apy","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"currentTotalStake","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"_apy","type":"uint256"}],"name":"distributeRewards","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"getRewardsDistributedLastDate","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"bytes32","name":"role","type":"bytes32"}],"name":"getRoleAdmin","outputs":[{"internalType":"bytes32","name":"","type":"bytes32"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"bytes32","name":"role","type":"bytes32"},{"internalType":"uint256","name":"index","type":"uint256"}],"name":"getRoleMember","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"bytes32","name":"role","type":"bytes32"}],"name":"getRoleMemberCount","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"getStakers","outputs":[{"internalType":"address[]","name":"","type":"address[]"},{"internalType":"uint256[]","name":"","type":"uint256[]"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"bytes32","name":"role","type":"bytes32"},{"internalType":"address","name":"account","type":"address"}],"name":"grantRole","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"bytes32","name":"role","type":"bytes32"},{"internalType":"address","name":"account","type":"address"}],"name":"hasRole","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"info","outputs":[{"internalType":"address","name":"","type":"address"},{"internalType":"string","name":"","type":"string"},{"internalType":"uint256","name":"","type":"uint256"},{"internalType":"uint256","name":"","type":"uint256"},{"internalType":"uint256","name":"","type":"uint256"},{"internalType":"uint256","name":"","type":"uint256"},{"internalType":"uint256","name":"","type":"uint256"},{"internalType":"bool","name":"","type":"bool"},{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"account","type":"address"}],"name":"infoWallet","outputs":[{"internalType":"uint256","name":"","type":"uint256"},{"internalType":"uint256","name":"","type":"uint256"},{"internalType":"uint256","name":"","type":"uint256"},{"internalType":"uint256","name":"","type":"uint256"},{"internalType":"uint256","name":"","type":"uint256"},{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"_token","type":"address"},{"internalType":"address","name":"_rewardsAddress","type":"address"},{"internalType":"uint256","name":"_maxStakingAmount","type":"uint256"},{"internalType":"uint256","name":"_apy","type":"uint256"},{"internalType":"uint256","name":"_unstakingPeriod","type":"uint256"}],"name":"initialize","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"maxStakingAmount","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"pause","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"paused","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"bytes32","name":"role","type":"bytes32"},{"internalType":"address","name":"account","type":"address"}],"name":"renounceRole","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"bytes32","name":"role","type":"bytes32"},{"internalType":"address","name":"account","type":"address"}],"name":"revokeRole","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"rewardsAddress","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"rewardsDistributed","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"rewardsDistributedLastDate","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"rewardsWithdrawn","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"_apy","type":"uint256"}],"name":"setAPY","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"_rewardsAddress","type":"address"}],"name":"setRewardAddress","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_rewardsDistributedLastDate","type":"uint256"}],"name":"setRewardsDistributedLastDate","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"_token","type":"address"}],"name":"setTokenAddress","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_unstakingPeriod","type":"uint256"}],"name":"setUnstakingPeriod","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"amount","type":"uint256"}],"name":"stake","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"stakeRewards","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"","type":"uint256"}],"name":"stakerAddresses","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"","type":"uint256"}],"name":"stakerAmounts","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"token","outputs":[{"internalType":"contract IBEP20","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"totalRewardsDistributed","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"amount","type":"uint256"},{"internalType":"address payable","name":"to","type":"address"}],"name":"transferBNB","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"t","type":"address"},{"internalType":"uint256","name":"amount","type":"uint256"},{"internalType":"address","name":"to","type":"address"}],"name":"transferToken","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"unpause","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"unstakeAmount","type":"uint256"}],"name":"unstake","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"unstakingPeriod","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"withdraw","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"withdrawRewards","outputs":[],"stateMutability":"nonpayable","type":"function"}]')
        },
        885: function(e, t) {},
        898: function(e, t) {}
    },
    [
        [466, 1, 2]
    ]
]);
//# sourceMappingURL=main.77f8b7fd.chunk.js.map